if(!TESTING)
{
    System.Link("StyleSheet", "Themes/Default/CHM.css", "text/css");
}

var Controls = null;
var Window = null, Control = null, RichEditor = null;

function init(completeCallback, errorCallback)
{
    function LoadModulesComplete()
    {
        Controls = System.GetModule("Controls.js");
        CommonDialog = System.GetModule("CommonDialog.js");

        Window = System.GetModule("Window.js").Window;
        Control = System.GetModule("Controls.js").Control;
        
        RichEditor = System.GetModule("RichEditor.js").RichEditor;

        _init(completeCallback, errorCallback);
    }

    System.LoadModules(
        LoadModulesComplete,
        errorCallback,
        ["Window.js", "Controls.js", "RichEditor.js"]
    );
}

function _init(completeCallback, errorCallback)
{
    try
    {
        //初始化代码，初始化完成后必须调用completeCallback;
        completeCallback();
    }
    catch (ex)
    {
        errorCallback(new Exception(ex.mame, ex.message));
    }
}



function dispose(completeCallback, errorCallback)
{
    _dispose(completeCallback, errorCallback);
}

function _dispose(completeCallback, errorCallback)
{
    try
    {
        //卸载代码，卸载完成后必须调用completeCallback;
        completeCallback();
    }
    catch (ex)
    {
        errorCallback(new Exception(ex.mame, ex.message));
    }
}

//共享全局变量和函数，在此定义的变量和函数将由该应用程序的所有实例共享

function EmptyCallback()
{

}

function ChmHHC(buffer)
{
    var position = 0;

    var RegxTagName = /(<|<\/)([a-zA-Z]+)(\s[\S\s]*|)>/i;
    var RegxAttrs = /([a-zA-Z1-9]+)\s*=\s*\x22([^\x22]+)\x22/ig;

    function ReadTag()
    {
        var tag = {
            Name: "",
            Type: "",
            Attrs: {}
        };
        var res = null;

        while (res == null)
        {
            if (position >= buffer.length) return null;

            while (position < buffer.length && buffer.charAt(position) != '<') position++;
            if (position >= buffer.length) return null;
            var s = position;

            while (position < buffer.length && buffer.charAt(position) != '>') position++;
            if (position >= buffer.length) return null;
            var e = position;

            position++;

            var tag_str = buffer.substr(s, e - s + 1);
            RegxTagName.lastIndex = 0;
            res = RegxTagName.exec(tag_str);
        }

        tag.Name = res[2].toUpperCase();
        tag.Type = res[1] == '<' ? "Begin": "End";

        if (tag.Type == "Begin" && res.length > 3 && res[3] != "")
        {
            RegxAttrs.lastIndex = 0;
            var atrr = null;
            while ((attr = RegxAttrs.exec(res[3])) != null)
            {
                tag.Attrs[attr[1].toLowerCase()] = attr[2];
            }
        }

        return tag;
    }

    var current = null;

    function IsBeginTag(tag, name)
    {
        return tag.Type == "Begin" && tag.Name == name;
    }

    function IsEndTag(tag, name)
    {
        return tag.Type == "End" && tag.Name == name;
    }

    function RenderTag()
    {
        if (current != null && IsBeginTag(current, "LI"))
        {
            var node = {
                NodeType: "LI",
                SubNodes: []
            };

            current = ReadTag();
            if (current != null && IsBeginTag(current, "OBJECT"))
            {
                node.type = current.Attrs["type"];
                current = ReadTag();
                while (current != null && !IsEndTag(current, "OBJECT"))
                {
                    if (IsBeginTag(current, "PARAM"))
                    {
                        node[current.Attrs["name"]] = current.Attrs["value"];
                    }
                    current = ReadTag();
                }

                if (current != null && IsEndTag(current, "OBJECT")) current = ReadTag();
                if (current != null && IsEndTag(current, "LI")) current = ReadTag();

                while(current != null && IsBeginTag(current, "UL"))
                {
                    var ul = RenderTag();
                    if (ul != null)
                    {
						for(var ul_index in ul.Nodes) node.SubNodes.push(ul.Nodes[ul_index]);
                    }
                }
                
                return node;
            }
        }
        else if (current != null && IsBeginTag(current, "UL"))
        {
            var node = {
                NodeType: "UL",
                Nodes: []
            };

            current = ReadTag();
            while (current != null && !IsEndTag(current, "UL"))
            {
                var subNode = RenderTag();
                if (subNode != null) node.Nodes.push(subNode);
            }

            if (current != null)
            {
                current = ReadTag();
                return node;
            }
        }
        else
        {
            current = ReadTag();
        }
        return null;
    }

    var roots = [];

    this.Render = function()
    {
        position = 0;
        current = ReadTag();

        while (current != null)
        {
            var node = RenderTag();
            if (node != null) roots.push(node);
        }
        current = null;
    }

    this.GetNodes = function()
    {
        return roots;
    }
}

function Application()
{
    var CurrentApplication = this;
    var m_MainForm = null;
    
    //应用程序全局对象;
        

    this.Start = function(baseUrl)
    {
        //应用程序入口;
        if(TESTING)
        {
            var form = new Window(
                {
                    Left: 0, Top: 0, Width: 800, Height: 600,
                    Parent: null,
                    Css: "window", BorderWidth: 6,
                    HasMinButton: true, HasMaxButton: true,
                    Title: {
                        InnerHTML: "调试"
                    }
                }
            );
            
            m_MainForm = new MainWnd(
                {
                    Left: 0, Top: 0, Width: form.GetClientWidth(), Height: form.GetClientHeight(),
                    Parent: form,
                    AnchorStyle: Controls.AnchorStyle.All,
                    Css: "mainwnd"
                }
            );
            
            form.OnClosed.Attach(
                function()
                {
                    CurrentApplication.Dispose();
                }
            );
            
            form.MoveEx("center",0,0);
            form.Show();
            form.Maximun();
        }
        else
        {
            m_MainForm = new MainWnd(
                {
                    Left: 0, Top: 0, Width: Desktop.GetClientWidth(), Height: Desktop.GetClientHeight(),
                    Parent: Desktop,
                    AnchorStyle: Controls.AnchorStyle.All,
                    Css: "mainwnd"
                }
            );
        }
        
        m_MainForm.Load();
        
    }

    this.Terminate = function(completeCallback, errorCallback)
    {
        try
        {
            //应用程序终止，退出系统时用系统调用;
            completeCallback();
        }
        catch (ex)
        {
            errorCallback(new Exception(ex.mame, ex.message));
        }
    }
    

    
    function MainWnd(config)
    {
        var This = this;
        var OwnerForm = this;
        
config.Css = "CHM_MainWnd";
        
        var width = config.Width, height = config.Height;
        config.Width=661;
        config.Height=523;
    
        Control.call(This, config);
    
        var Base = {
            GetType: This.GetType,
            is: This.is
        };
    
        This.GetType = function() { return "MainWnd"; }
        This.is = function(type) { return type == This.GetType() ? true : Base.is(type); }
        
        var m_ContentTree_Config={"Left":7,"Top":8,"Width":267,"Height":508,"AnchorStyle":Controls.AnchorStyle.Left|Controls.AnchorStyle.Top|Controls.AnchorStyle.Bottom,"Parent":This,"Text":"","Css":"CHM_ContentTree"};
        
                m_ContentTree_Config.Css = "CHM_ContentTree";
                m_ContentTree_Config.BorderWidth = 1;
        
        var m_ContentTree = new ContentTree(m_ContentTree_Config);
        
        m_ContentTree.OnClick.Attach(
        function()
        {
            var node = m_ContentTree.GetSelectedNode();
            if (node == null) return;
            var tag = node.GetTag();
            if (tag == null) return null;
            if (tag.Local != undefined)
            {
                m_Browser.Navigate(BaseUrl + "/" + tag.Local);
            }
        });

        
        var m_Browser_Config={"Left":280,"Top":8,"Width":374,"Height":507,"AnchorStyle":Controls.AnchorStyle.Left|Controls.AnchorStyle.Right|Controls.AnchorStyle.Top|Controls.AnchorStyle.Bottom,"Parent":This,"Text":"","Css":"CHM_Browser"};
        
                m_Browser_Config.Css = "CHM_Browser";
                m_Browser_Config.BorderWidth = 1;
        
        var m_Browser = new Browser(m_Browser_Config);
        
        
    
        This.Resize(width,height);
    
        var m_Splitor = Controls.CreateVerticalSplit(m_ContentTree, m_Browser);
        
        function HideContent()
        {
            if (m_ContentTree.GetVisible())
            {
                m_ContentTree.SetVisible(false);
                m_Splitor.SetVisible(false);
                m_Browser.Move(m_Browser.GetLeft() - m_ContentTree.GetWidth() - m_Splitor.GetWidth(), m_Browser.GetTop());
                m_Browser.Resize(m_Browser.GetWidth() + m_ContentTree.GetWidth() + m_Splitor.GetWidth(), m_Browser.GetHeight());
            }
        }
        
        function ShowContent()
        {
            if (!m_ContentTree.GetVisible())
            {
                m_ContentTree.SetVisible(true);
                m_Splitor.SetVisible(true);
                m_Browser.Move(m_Browser.GetLeft() + m_ContentTree.GetWidth() + m_Splitor.GetWidth(), m_Browser.GetTop());
                m_Browser.Resize(m_Browser.GetWidth() - m_ContentTree.GetWidth() - m_Splitor.GetWidth(), m_Browser.GetHeight());
            }
        }
        
        This.Load = function()
        {
            if (HHC == null)
            {
                HideContent();
            }
            else
            {
                ShowContent();
                m_ContentTree.Refresh(EmptyCallback);
            }
        
            m_Browser.Navigate(BaseUrl + "/" + Info.MainPage);
        }
    
    }

}

function ContentTree_DataSource()
{
    var hhc = null;
    if (HHC != null)
    {
        hhc = new ChmHHC(HHC);
        hhc.Render();
    }

    this.GetSubNodes = function(callback, node)
    {
        if (hhc == null)
        {
            callback([]);
            return;
        }
        var roots = hhc.GetNodes();
        if (node == null)
        {
            var nodes = [];
            if (roots[0].NodeType == "UL")
            {
                for (var i in roots[0].Nodes)
                {
                    var hhc_node = roots[0].Nodes[i];
                    if (hhc_node.NodeType == "LI")
                    {
                        hhc_node.Index = i;
                        var new_node = {
                            Name: i,
                            Text: IsNull(hhc_node.Name, ""),
                            Tag: hhc_node,
                            ImageCss: hhc_node.SubNodes.length > 0 ? "CHH_CONTENTTREE_CION_BOOK": "CHH_CONTENTTREE_CION_PAGE",
                            HasChildren: hhc_node.SubNodes.length > 0
                        };
                        nodes.push(new_node);
                    }
                }
            }
            callback(nodes);
        }
        else
        {
            var nodes = [];
            var tag = node.GetTag();
            if (tag.SubNodes != undefined)
            {
                for (var i in tag.SubNodes)
                {
                    var hhc_node = tag.SubNodes[i];
                    if (hhc_node.NodeType == "LI")
                    {
                        hhc_node.Index = i;
                        var new_node = {
                            Name: i,
                            Text: IsNull(hhc_node.Name, ""),
                            Tag: hhc_node,
                            ImageCss: hhc_node.SubNodes.length > 0 ? "CHH_CONTENTTREE_CION_BOOK": "CHH_CONTENTTREE_CION_PAGE",
                            HasChildren: hhc_node.SubNodes.length > 0
                        };
                        nodes.push(new_node);
                    }
                    else if (hhc_node.NodeType == "UL")
                    {
                        for (var k in hhc_node.Nodes)
                        {
                            var ul_subnode = hhc_node.Nodes[k];

                            var new_node = {
                                Name: i,
                                Text: IsNull(ul_subnode.Name, ""),
                                Tag: ul_subnode,
                                ImageCss: ul_subnode.SubNodes.length > 0 ? "CHH_CONTENTTREE_CION_BOOK": "CHH_CONTENTTREE_CION_PAGE",
                                HasChildren: ul_subnode.SubNodes.length > 0
                            };
                            nodes.push(new_node);
                        }
                    }
                }

            }
            callback(nodes);
        }
    }
}

function ContentTree(config)
{
    var This = this;
    var OwnerForm = this;
    
config.DataSource = new ContentTree_DataSource();
    
    var width = config.Width, height = config.Height;
    config.Width=200;
    config.Height=200;

    Controls.TreeView.call(This, config);

    var Base = {
        GetType: This.GetType,
        is: This.is
    };

    This.GetType = function() { return "ContentTree"; }
    This.is = function(type) { return type == This.GetType() ? true : Base.is(type); }
    
    This.Resize(width,height);

    

}




function Browser(config)
{
    var This = this;
    var OwnerForm = this;
    

    
    var width = config.Width, height = config.Height;
    config.Width=200;
    config.Height=200;

    Controls.Frame.call(This, config);

    var Base = {
        GetType: This.GetType,
        is: This.is
    };

    This.GetType = function() { return "Browser"; }
    This.is = function(type) { return type == This.GetType() ? true : Base.is(type); }
    
    This.Resize(width,height);

    

}

