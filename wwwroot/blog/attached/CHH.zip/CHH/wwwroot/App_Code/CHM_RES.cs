﻿using System;
using System.Collections;
using System.Data;
using System.Configuration;
using System.Web;
using System.Xml;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using LUCC;
using System.IO;
using System.Threading;

/// <summary>
///DownloadHandler 的摘要说明
/// </summary>
namespace LUCC
{
	public class CHM_RES : IHttpHandler
	{
		static Hashtable ContentType = new Hashtable();

		static CHM_RES()
		{
			ContentType[".JS"] = "application/x-javascript";
			ContentType[".XML"] = "text/xml";
			ContentType[".HTML"] = "text/html";
			ContentType[".HTM"] = "text/html";
			ContentType[".CSS"] = "text/css";
			ContentType[".TXT"] = "text";
			ContentType[".PNG"] = "image";
			ContentType[".BMP"] = "image";
			ContentType[".GIF"] = "image";
			ContentType[".JPG"] = "image";
			ContentType[".ICO"] = "image";
			ContentType[".CUR"] = "image";
		}

		public CHM_RES()
		{
		}

		void IHttpHandler.ProcessRequest(HttpContext context)
		{
			string file = context.Request.QueryString["file"];
			string res = context.Request.QueryString["res"];

			String path = context.Server.MapPath(String.Format("~/{0}", context.Request.QueryString["file"]));

			using (System.IO.Stream stream = LUCC.Com.CHH.Find(path, res))
			{
				if (stream != null)
				{
					try
					{
						string ext = Path.GetExtension(res).ToUpper();
						if (ContentType.ContainsKey(ext))
						{
							context.Response.ContentType = ContentType[ext] as string;
						}
						else
						{
							context.Response.ContentType = "application/octet-stream";
							context.Response.AppendHeader("Content-Disposition", string.Format("attachment;filename={0}", context.Server.UrlEncode(Path.GetFileName(res))));
						}


						FileInfo fileInfo = new FileInfo(path);
						if (fileInfo != null)
						{
							context.Response.AppendHeader("Last-Modified", String.Format("{0:R}", fileInfo.LastWriteTime));
							context.Response.AppendHeader("Content-Length", stream.Length.ToString());
						}

						byte[] buffer = new byte[4 * 1024];
						while (true)
						{
							int c = stream.Read(buffer, 0, buffer.Length);
							context.Response.OutputStream.Write(buffer, 0, c);
							if (c < buffer.Length) break;
						}
					}
					finally
					{
						stream.Close();
					}
				}
			}
		}

		bool IHttpHandler.IsReusable
		{
			get { return true; }
		}
	}
}