﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using LUCC.Com;
using LUCC;

public partial class CHM_reader : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		Hashtable data = new Hashtable();
		String path = Server.MapPath(String.Format("~/{0}", Request.QueryString["file"]));
		
		data["ApplicationPath"] = Request.ApplicationPath;
		data["FileName"] = Request.QueryString["file"];

		using (Stream sys_stream = CHH.Find(path, "#SYSTEM"))
		{
			if (sys_stream != null)
			{
				try
				{
					byte[] buf = new byte[sys_stream.Length];
					sys_stream.Read(buf, 0, buf.Length);
					data["Info"] = new JsonText(Encoding.UTF8.GetString(buf));
				}
				finally
				{
					sys_stream.Close();
				}
			}
			else
			{
				data["Info"] = new JsonText("null");
			}
		}

		using (Stream sys_stream = LUCC.Com.CHH.Find(path, ".HHC"))
		{
			if (sys_stream != null)
			{
				try
				{
					byte[] buf = new byte[sys_stream.Length];
					sys_stream.Read(buf, 0, buf.Length);
					data["HHC"] = new JsonText(Utility.RenderJson(Encoding.UTF8.GetString(buf), null));
				}
				finally
				{
					sys_stream.Close();
				}
			}
			else
			{
				data["HHC"] = new JsonText("null");
			}
		}
		
		HtmlInputHidden hidden = Page.FindControl("chm_data") as HtmlInputHidden;

		hidden.Value = Utility.RenderJson(data, null);
	}

	String[] Split(String path)
	{
		int index = path.IndexOf(".CHM", StringComparison.CurrentCultureIgnoreCase);

		if ((path.Length >= index + 5 && path[index + 4] == '\\'))
		{
			String[] ps = new String[2];
			ps[0] = path.Substring(0, index + 4);
			ps[1] = path.Substring(index + 5);
			return ps;
		}
		else
		{
			return null;
		}
	}
}
