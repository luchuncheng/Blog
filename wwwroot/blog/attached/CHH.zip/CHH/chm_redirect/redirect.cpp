// isapi_forbidden.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include <string>
using namespace std;


string upper(const string &str)
{
	string temp;
	const char *pc = str.c_str();
	while(*pc)
	{
		char c = (*pc >= 'a' && *pc <= 'z') ? *pc + 'A' - 'a' : *pc;
		temp.append(&c,1);
		pc++;
	}
	return temp;
}

int begin(const string &path, const string &str)
{
	return upper(path).find(upper(str)) == 0;
}

int split_for_chm(const string &path, string &file, string &res)
{
	file = "";
	res = "";

	string path_u = upper(path);

	int index = path_u.find(".CHM");

	if(index < 0) return 0;

	if(path_u[index+4] == 0)
	{
		file = path;
		return 1;
	}
	else if(path_u[index+4] == '/')
	{
		file.append(path.c_str(), 0, index + 4);
		if((int)path.length() > index + 5)
		{
			res.append(path.c_str(), index + 5, path.length() - (index + 5));
		}
		return 1;
	}
	else
	{
		return 0;
	}
}

bool make_chm_url(const string &vp, const string &url, string &out)
{
	if(!begin(url, vp)) return 0;

	string file, res;
	if(!split_for_chm(url.c_str() + vp.length(), file, res)) return 0;

	if(res.empty()) return 0;

	out = "res.aspx?file=/"+file+"&res="+res;

	return 1;
}


BOOL APIENTRY DllMain( HANDLE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
    return TRUE;
}

BOOL WINAPI GetFilterVersion(PHTTP_FILTER_VERSION pVer)
{
	pVer->dwFilterVersion = HTTP_FILTER_REVISION; 
	strcpy(pVer->lpszFilterDesc, "CHM_Redirect"); 
	pVer->dwFlags = SF_NOTIFY_ORDER_DEFAULT | SF_NOTIFY_PREPROC_HEADERS;
	return TRUE; 

}

DWORD WINAPI HttpFilterProc( HTTP_FILTER_CONTEXT * pfc,DWORD NotificationType, VOID * pvData) 
{ 
	switch ( NotificationType ) 
	{ 
	case SF_NOTIFY_PREPROC_HEADERS:
		{
			PHTTP_FILTER_PREPROC_HEADERS pData=(PHTTP_FILTER_PREPROC_HEADERS)pvData;
		
			string vp = "/CHH/__CHM";

			char buffer[2048];
			unsigned long length=2048;
			pData->GetHeader(pfc,"url",buffer,&length);
			string url = buffer;
			string chm_url;
			
			if(make_chm_url(vp, url, chm_url))
			{
				string newUrl = "/CHH/" + chm_url;
				pData->SetHeader(pfc,"url",(char*)newUrl.c_str());
			}

			break;
		}
	} 
	return SF_STATUS_REQ_NEXT_NOTIFICATION; 
} 

BOOL WINAPI TerminateFilter(DWORD dwFlags)
{
	return TRUE;
}
