// Copyright (C) 2007 XtractPro (Data Extraction Magazine)
// http://www.xtractpro.com, support@xtractpro.com
//
// This code is provided AS IS, with NO WARRANTY expressed or implied.
// Any use of this free open source code is at your own risk.
//
// You are hereby granted the right to use it and change it,
// provided that you acknowledge XtractPro somewhere in your
// source files, documentation, web site and application.

using System;
using System.Diagnostics;
using System.Collections;
using System.IO;
using System.Runtime.InteropServices;
using System.Security;

namespace LUCC.Com
{
    // Interop declarations of compound document COM interfaces,
    // classes, enums and structures, required by the application.

    public enum ECompactionLev { COMPACT_DATA, COMPACT_DATA_AND_PATH }

    [StructLayout(LayoutKind.Sequential)]
    public struct ITS_Control_Data
    {
        private int cdwControlData;
        private int adwControlData;
    }

    [ComImport]
    [Guid("0000000a-0000-0000-C000-000000000046")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface ILockBytes
    {
        int ReadAt(long ulOffset, out IntPtr pv, int cb);
        int WriteAt(long ulOffset, IntPtr pv, int cb);
        void Flush();
        void SetSize(long cb);
        void LockRegion(long libOffset, long cb, int dwLockType);
        void UnlockRegion(long libOffset, long cb, int dwLockType);
        void Stat(ref System.Runtime.InteropServices.ComTypes.STATSTG pstatstg, int grfStatFlag);
    }

    [ComImport]
    [Guid("0000000D-0000-0000-C000-000000000046")]
    [SuppressUnmanagedCodeSecurity]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IEnumSTATSTG
    {
        [PreserveSig]
        int Next(int celt, out System.Runtime.InteropServices.ComTypes.STATSTG rgVar, out int pceltFetched);
        [PreserveSig]
        int Skip(int celt);
        [PreserveSig]
        int Reset();
        int Clone(out IEnumSTATSTG newEnum);
    }

    [ComImport]
    [Guid("5D02926A-212E-11D0-9DF9-00A0C922E6EC")]
    public class ITStorageClass { }

    [ComImport]
    [Guid("88CC31DE-27AB-11D0-9DF9-00A0C922E6EC")]
    [SuppressUnmanagedCodeSecurity]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface ITStorage
    {
        [return: MarshalAs(UnmanagedType.Interface)]
        IStorage StgCreateDocfile([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, int grfMode, int reserved);
        [return: MarshalAs(UnmanagedType.Interface)]
        IStorage StgCreateDocfileOnILockBytes(ILockBytes plkbyt, int grfMode, int reserved);
        int StgIsStorageFile([In, MarshalAs(UnmanagedType.BStr)] string pwcsName);
        int StgIsStorageILockBytes(ILockBytes plkbyt);
        [return: MarshalAs(UnmanagedType.Interface)]
        IStorage StgOpenStorage([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, IntPtr pstgPriority, [In, MarshalAs(UnmanagedType.U4)] int grfMode, IntPtr snbExclude, [In, MarshalAs(UnmanagedType.U4)] int reserved);
        [return: MarshalAs(UnmanagedType.Interface)]
        IStorage StgOpenStorageOnILockBytes(ILockBytes plkbyt, IStorage pStgPriority, int grfMode, IntPtr snbExclude, int reserved);
        int StgSetTimes([In, MarshalAs(UnmanagedType.BStr)] string lpszName, System.Runtime.InteropServices.ComTypes.FILETIME pctime, System.Runtime.InteropServices.ComTypes.FILETIME patime, System.Runtime.InteropServices.ComTypes.FILETIME pmtime);
        int SetControlData(ITS_Control_Data pControlData);
        int DefaultControlData(ITS_Control_Data ppControlData);
        int Compact([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, ECompactionLev iLev);
    }

    [ComImport]
    [Guid("0000000B-0000-0000-C000-000000000046")]
    [SuppressUnmanagedCodeSecurity]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IStorage
    {
        [return: MarshalAs(UnmanagedType.Interface)]
        System.Runtime.InteropServices.ComTypes.IStream CreateStream([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, [In, MarshalAs(UnmanagedType.U4)] int grfMode, [In, MarshalAs(UnmanagedType.U4)] int reserved1, [In, MarshalAs(UnmanagedType.U4)] int reserved2);
        [return: MarshalAs(UnmanagedType.Interface)]
        System.Runtime.InteropServices.ComTypes.IStream OpenStream([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, IntPtr reserved1, [In, MarshalAs(UnmanagedType.U4)] int grfMode, [In, MarshalAs(UnmanagedType.U4)] int reserved2);
        [return: MarshalAs(UnmanagedType.Interface)]
        IStorage CreateStorage([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, [In, MarshalAs(UnmanagedType.U4)] int grfMode, [In, MarshalAs(UnmanagedType.U4)] int reserved1, [In, MarshalAs(UnmanagedType.U4)] int reserved2);
        [return: MarshalAs(UnmanagedType.Interface)]
        IStorage OpenStorage([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, IntPtr pstgPriority, [In, MarshalAs(UnmanagedType.U4)] int grfMode, IntPtr snbExclude, [In, MarshalAs(UnmanagedType.U4)] int reserved);
        void CopyTo(int ciidExclude, [In, MarshalAs(UnmanagedType.LPArray)] Guid[] rgiidExclude, IntPtr snbExclude, [In, MarshalAs(UnmanagedType.Interface)] IStorage pstgDest);
        void MoveElementTo([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, [In, MarshalAs(UnmanagedType.Interface)] IStorage pstgDest, [In, MarshalAs(UnmanagedType.BStr)] string pwcsNewName, [In, MarshalAs(UnmanagedType.U4)] int grfFlags);
        void Commit(int grfCommitFlags);
        void Revert();
        int EnumElements([In, MarshalAs(UnmanagedType.U4)] int reserved1, IntPtr reserved2, [In, MarshalAs(UnmanagedType.U4)] int reserved3, [MarshalAs(UnmanagedType.Interface)] out IEnumSTATSTG ppenum);
        void DestroyElement([In, MarshalAs(UnmanagedType.BStr)] string pwcsName);
        void RenameElement([In, MarshalAs(UnmanagedType.BStr)] string pwcsOldName, [In, MarshalAs(UnmanagedType.BStr)] string pwcsNewName);
        void SetElementTimes([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, [In] System.Runtime.InteropServices.ComTypes.FILETIME pctime, [In] System.Runtime.InteropServices.ComTypes.FILETIME patime, [In] System.Runtime.InteropServices.ComTypes.FILETIME pmtime);
        void SetClass(ref Guid clsid);
        void SetStateBits(int grfStateBits, int grfMask);
        int Stat(out System.Runtime.InteropServices.ComTypes.STATSTG pStatStg, int grfStatFlag);
    }
}