// Copyright (C) 2007 XtractPro (Data Extraction Magazine)
// http://www.xtractpro.com, support@xtractpro.com
//
// This code is provided AS IS, with NO WARRANTY expressed or implied.
// Any use of this free open source code is at your own risk.
//
// You are hereby granted the right to use it and change it,
// provided that you acknowledge XtractPro somewhere in your
// source files, documentation, web site and application.

using System;
using System.Diagnostics;
using System.Collections;
using System.IO;
using System.Runtime.InteropServices;

namespace LUCC.Com
{
    /// <summary>
    /// Wrapper for .NET Stream from COM IStream,
    /// with implementation of all Stream's abstract methods
    /// </summary>
    public class ComStream : Stream
    {
        private System.Runtime.InteropServices.ComTypes.IStream _stream;

        public ComStream(System.Runtime.InteropServices.ComTypes.IStream stream)
        {
            _stream = stream;
            if (_stream==null)
                throw new ArgumentNullException("IStream");
        }
        ~ComStream() { Close(); }

        protected System.Runtime.InteropServices.ComTypes.IStream IStream { get { return _stream; } }
        
        public override bool CanRead { get { return (_stream != null); } }
        public override bool CanSeek { get { return true; } }
        public override bool CanWrite { get { return true; } }

        public override long Length
        {
            get
            {
                if (_stream == null)
                    throw new ObjectDisposedException("IStream");

                System.Runtime.InteropServices.ComTypes.STATSTG stats;
                _stream.Stat(out stats, 1);
                return stats.cbSize;
            }
        }
        public override void SetLength(long Value)
        {
            if (_stream == null)
                throw new ObjectDisposedException("IStream");

            _stream.SetSize(Value);
        }

        public override long Position
        {
            get { return Seek((long)0, SeekOrigin.Current); }
            set { Seek(value, SeekOrigin.Begin); }
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            if (_stream == null)
                throw new ObjectDisposedException("IStream");

            long i = 0;
            object obj = i;
            GCHandle handle = new GCHandle();

            try
            {
                handle = GCHandle.Alloc(obj, GCHandleType.Pinned);
                IntPtr plibNewPosition = handle.AddrOfPinnedObject();
                _stream.Seek(offset, (int)origin, plibNewPosition);
                i = (long)obj;
            }
            finally
            {
                if (handle.IsAllocated)
                    handle.Free();
            }
            return i;
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            if (_stream == null)
                throw new ObjectDisposedException("IStream");

            int length = 0;
            object obj = length;
            GCHandle handle = new GCHandle();

            try
            {
                handle = GCHandle.Alloc(obj, GCHandleType.Pinned);
                IntPtr pcbRead = handle.AddrOfPinnedObject();
                if (offset != 0)
                {
                    byte[] pv = new byte[count - 1];
                    _stream.Read(pv, count, pcbRead);
                    length = (int)obj;
                    Array.Copy(pv, 0, buffer, offset, length);
                    return length;
                }
                _stream.Read(buffer, count, pcbRead);
                length = (int)obj;
            }
            finally
            {
                if (handle.IsAllocated)
                    handle.Free();
            }
            return length;
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            if (_stream == null)
                throw new ObjectDisposedException("IStream");

            if (offset == 0)
                _stream.Write(buffer, count, IntPtr.Zero);
            else
            {
                int i = buffer.Length - offset;
                byte[] target = new byte[i];
                Array.Copy(buffer, offset, target, 0, i);
                _stream.Write(target, i, IntPtr.Zero);
            }
        }

        public override void Close()
        {
            if (_stream != null)
            {
                _stream.Commit(0);
                Marshal.ReleaseComObject(_stream);
                _stream = null;
                GC.SuppressFinalize(this);
            }
        }

        public override void Flush()
        {
            if (_stream == null)
                throw new ObjectDisposedException("IStream");

            _stream.Commit(0);
        }
    }
}