﻿using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.IO;

namespace LUCC.Com
{
	class ChmInfo
	{
		const UInt16 ID_HHC = 0x0000;
		const UInt16 ID_MAIN = 0x0002;
		const UInt16 ID_Version = 0x0009;
		const UInt16 ID_TITLE = 0x0003;
		const UInt16 ID_PRJNAME = 0x0006;
		const UInt16 ID_LAN = 0x0004;

		public String MainPage = String.Empty, PrjName = String.Empty, Title = String.Empty, HHA_Version = String.Empty, HHC = String.Empty;
		public Encoding Encoding = null;
		Hashtable _session = new Hashtable();

		private bool ReadSession(BinaryReader reader)
		{
			if (reader.BaseStream.Position >= reader.BaseStream.Length) return false;

			UInt16 id = reader.ReadUInt16();
			UInt16 count = reader.ReadUInt16();
			if (count + reader.BaseStream.Position <= reader.BaseStream.Length)
			{
				if (count > 0)
				{
					_session[id] = reader.ReadBytes(count);
				}
				return true;
			}
			else
			{
				return false;
			}
		}

		public ChmInfo(Stream stream)
		{
			BinaryReader reader = new BinaryReader(stream);

			while (ReadSession(reader)) ;

			try
			{
				if (_session.ContainsKey(ID_LAN))
				{
					Byte[] data = _session[ID_LAN] as Byte[];
					CultureInfo info = new CultureInfo(data[1] * 0x100 + data[0]);
					Encoding = Encoding.GetEncoding(info.TextInfo.ANSICodePage);
				}
			}
			catch
			{
			}
			if (Encoding == null) Encoding = Encoding.GetEncoding("GB2312");

			if (_session.ContainsKey(ID_MAIN))
			{
				Byte[] data = _session[ID_MAIN] as Byte[];
				MainPage = Encoding.GetString(data, 0, data.Length - 1);
			}

			if (_session.ContainsKey(ID_TITLE))
			{
				Byte[] data = _session[ID_TITLE] as Byte[];
				Title = Encoding.GetString(data, 0, data.Length - 1);
			}

			if (_session.ContainsKey(ID_PRJNAME))
			{
				Byte[] data = _session[ID_PRJNAME] as Byte[];
				PrjName = Encoding.GetString(data, 0, data.Length - 1);
			}

			if (_session.ContainsKey(ID_Version))
			{
				Byte[] data = _session[ID_Version] as Byte[];
				HHA_Version = Encoding.GetString(data, 0, data.Length - 1);
			}

			if (_session.ContainsKey(ID_HHC))
			{
				Byte[] data = _session[ID_HHC] as Byte[];
				HHC = Encoding.GetString(data, 0, data.Length - 1);
			}
		}

		public Stream MakeStream()
		{
			String json = String.Format(
				"{{\"MainPage\":\"{0}\",\"Title\":\"{1}\",\"HHC\":\"{2}\",\"Encoding\":\"{3}\"}}",
				CHH.TransferCharJavascript(MainPage),
				CHH.TransferCharJavascript(Title),
				CHH.TransferCharJavascript(HHC),
				CHH.TransferCharJavascript(Encoding.HeaderName)
			);

			Byte[] buffer = Encoding.UTF8.GetBytes(json);
			Stream stream = new MemoryStream(buffer.Length);
			stream.Write(buffer, 0, buffer.Length);
			stream.Seek(0, SeekOrigin.Begin);
			return stream;
		}
	}
    public class CHH
    {
        public static Stream Find(string chm, string res)
        {
            IStorage storage = ((ITStorage)new ITStorageClass()).StgOpenStorage(chm, IntPtr.Zero, 0x20, IntPtr.Zero, 0);
            try
            {
				DateTime s = DateTime.Now;
				IStream stream = Find(storage, res.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries), 0);
				double e = (DateTime.Now - s).TotalMilliseconds;
				if (stream == null) return null;
				if (res.ToUpper() == "#SYSTEM")
				{
					using (Stream cs = new ComStream(stream))
					{
						try
						{
							return (new ChmInfo(cs)).MakeStream();
						}
						finally
						{
							cs.Close();
						}
					}
				}
				else
				{
					return new ComStream(stream);
				}
            }
            finally
            {
                Marshal.ReleaseComObject(storage);
            }
        }

        static IStream Find(IStorage storage, string[] res, int first)
		{
			if (first == res.Length - 1)
			{
				IStream stream = null;
				try
				{
					stream = storage.OpenStream(res[first], IntPtr.Zero, 0x20, 0);
				}
				catch
				{
				}

				if (stream == null && res[first].ToUpper() == ".HHC")
				{
					System.Runtime.InteropServices.ComTypes.STATSTG stats;
					IEnumSTATSTG enumStats;
					int i = 0;

					storage.EnumElements(0, IntPtr.Zero, 0, out enumStats);

					try
					{
						enumStats.Reset();

						while (enumStats.Next(1, out stats, out i) == 0)
						{
							if (System.IO.Path.GetExtension(stats.pwcsName).ToUpper() == ".HHC" && stats.type == 2)
							{
								stream = storage.OpenStream(stats.pwcsName, IntPtr.Zero, 0x20, 0);
								return stream;
							}
						}
					}
					finally
					{
						Marshal.ReleaseComObject(enumStats);
					}
				}

				return stream;
			}
			else
			{
				IStorage next = storage.OpenStorage(res[first], IntPtr.Zero, 0x20, IntPtr.Zero, 0);
				try
				{
					return Find(next, res, first + 1);
				}
				finally
				{
					Marshal.ReleaseComObject(next);
				}
			}
			//System.Runtime.InteropServices.ComTypes.STATSTG stats;
			//IEnumSTATSTG enumStats;
			//int i = 0;

			//storage.EnumElements(0, IntPtr.Zero, 0, out enumStats);

			//try
			//{
			//    enumStats.Reset();

			//    while (enumStats.Next(1, out stats, out i) == 0)
			//    {
			//        string name = stats.pwcsName.ToUpper();
			//        if (name == res[first] || (res[first] == ".HHC" && System.IO.Path.GetExtension(name) == ".HHC"))
			//        {
			//            if (stats.type == 1)
			//            {
			//                IStorage next = storage.OpenStorage(stats.pwcsName, IntPtr.Zero, 0x10, IntPtr.Zero, 0);
			//                try
			//                {
			//                    return Find(next, res, first + 1);
			//                }
			//                finally
			//                {
			//                    Marshal.ReleaseComObject(next);
			//                }
			//            }
			//            else if (stats.type == 2)
			//            {
			//                return storage.OpenStream(name, IntPtr.Zero, 0x10, 0);
			//            }
			//        }
			//    }
			//}
			//finally
			//{
			//    Marshal.ReleaseComObject(enumStats);
			//}
		}

		public static string TransferCharJavascript(string s)
		{
			StringBuilder ret = new StringBuilder();
			foreach (char c in s)
			{
				switch (c)
				{
				case '\r':
				case '\t':
				case '\n':
				case '\f':
				case '\v':
				case '\"':
				case '\\':
				case '\'':
				case '<':
				case '>':
				case '\0':
					ret.AppendFormat("\\u{0:X4}", (int)c);
					break;
				default:
					ret.Append(c);
					break;
				}
			}
			return ret.ToString();
		}
    }
}
