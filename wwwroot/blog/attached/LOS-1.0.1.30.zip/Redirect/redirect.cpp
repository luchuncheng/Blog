// isapi_forbidden.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include <string>
using namespace std;

BOOL BeginWith(const char *str,const char *begin)
{
	while(*str && *begin && ((*str==*begin) || (*str>='a' && *str<='z' && *str==*begin+32) || (*str>='A' && *str<='Z' && *str==*begin-32))) 
	{
		str++;
		begin++;
	}
	return *begin==0;
}

BOOL SplitUrl(const char *pUrl,string &file,string &query)
{
	file="";
	query="";

	const char *pStr=pUrl;
	while(*pStr!='\0' && *pStr!='?')
	{
		file.append(pStr,1);
		pStr++;
	}

	if(*pStr=='?')
	{
		pStr++;
		while(*pStr!='\0')
		{
			query.append(pStr,1);
			pStr++;
		}
	}

	return true;
}

BOOL APIENTRY DllMain( HANDLE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
    return TRUE;
}

BOOL WINAPI GetFilterVersion(PHTTP_FILTER_VERSION pVer)
{
	pVer->dwFilterVersion = HTTP_FILTER_REVISION; 
	strcpy(pVer->lpszFilterDesc, "Redirect"); 
	pVer->dwFlags = SF_NOTIFY_ORDER_DEFAULT | SF_NOTIFY_PREPROC_HEADERS;
	return TRUE; 

}

DWORD WINAPI HttpFilterProc( HTTP_FILTER_CONTEXT * pfc,DWORD NotificationType, VOID * pvData) 
{ 
	switch ( NotificationType ) 
	{ 
	case SF_NOTIFY_PREPROC_HEADERS:
		{
			PHTTP_FILTER_PREPROC_HEADERS pData=(PHTTP_FILTER_PREPROC_HEADERS)pvData;
		
			const char *flag="/LOS/Users/";

			char buffer[2048];
			unsigned long length=2048;
			pData->GetHeader(pfc,"url",buffer,&length);
			
			if(BeginWith(buffer,flag))
			{
				string path,query;

				string sUrl(buffer);
				string sRelUrl = sUrl.substr(strlen(flag)-1,sUrl.length()-1);
				
				SplitUrl(sRelUrl.c_str(),path,query);

				string newUrl;
				newUrl.append("/LOS/download.aspx?FileName=");
				newUrl.append(path);
				newUrl.append("&");
				newUrl.append(query);

				pData->SetHeader(pfc,"url",(char*)newUrl.c_str());
			}

			break;
		}
	} 
	return SF_STATUS_REQ_NEXT_NOTIFICATION; 
} 

BOOL WINAPI TerminateFilter(DWORD dwFlags)
{
	return TRUE;
}
