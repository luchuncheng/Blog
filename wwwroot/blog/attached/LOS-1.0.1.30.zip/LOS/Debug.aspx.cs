﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Debug : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		//LOS.UserManager.Instance.Register("test_user", "测试", "aaaa");
	}
}
