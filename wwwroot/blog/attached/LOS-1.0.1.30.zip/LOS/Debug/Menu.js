﻿
function Menu_Debug()
{
    var Menu=System.GetModule("Controls.js").Menu;
	var config={
		Items:[
			{ID:"Menu1",Text:"Menu1"},
			{ID:"Menu2",Text:"Menu2"},
			{
				ID:"Menu3",
				Text:"Menu3",
				SubMenu:{
					Items:[
						{ID:"Menu",Text:"Menu"},
						{ID:"Menu",Text:"Menu"},
						{
							ID:"Menu",
							Text:"Menu",
							SubMenu:{
								Items:[
									{ID:"Menu",Text:"Menu"},
									{ID:"Menu",Text:"Menu"},
									{ID:"Menu",Text:"Menu"}
								]
							}
						}
					]
				}
			},
			{
				ID:"Menu4",
				Text:"Menu4",
				SubMenu:{
					Items:[
						{ID:"Menu",Text:"Menu"},
						{ID:"Menu",Text:"Menu"},
						{ID:"Menu",Text:"Menu"}
					]
				}
			}
		]
	}
	var menu=new Menu(config);
	
	Desktop.ContextMenu=menu;
}