﻿
function ListView_Debug()
{
    System.Link("StyleSheet","Debug/ListView.css","text/css");
    var Window=System.GetModule("Window.js").Window;
	var config={
		Width:600,
		Height:450,
		Left:0,
		Top:0,
		Css:'window',
		BorderWidth:6,
		Resizable:true,
		HasMinButton:false,
		Title:{
			Height:18,
			InnerHTML:'测试'
		},
		Content:{
			InnerHTML:''
		}
	}
	var form=new Window(config);
			
    var Control=System.GetModule("Controls.js").Control;
    var AnchorStyle=System.GetModule("Controls.js").AnchorStyle;
    var ListView=System.GetModule("Controls.js").ListView;
    
    var lv=new ListView(
        {
            Left:0,
            Top:0,
            Width:form.GetClientWidth(),
            Height:form.GetClientHeight(),
	        Parent:form,
	        AnchorStyle:AnchorStyle.All,
	        BorderWidth:1,
	        Columns:[
	            {Name:"COL1",Text:"COL1_TEXT",Width:200,Css:"td_header_default"},
	            {Name:"COL2",Text:"COL2_TEXT",Width:250,Css:"td_header_default"}
	        ],
	        ListMode:{
	        },
	        EnableMultiSelect:true
        }
    );
    
    lv.AppendItem({COL1:"AFDAF",COL2:"99999"});
    lv.AppendItem({COL1:"AFDAF",COL2:"99999"});
    lv.AppendItem({COL1:"AFDAF",COL2:"99999"});
    lv.AppendItem({COL1:"AFDAF",COL2:"99999"});
    lv.AppendItem({COL1:"AFDAF",COL2:"99999"});
    lv.AppendItem({COL1:"AFDAF",COL2:"99999"});
	
	form.MoveEx('center',0,0);
	form.Show(true);
}