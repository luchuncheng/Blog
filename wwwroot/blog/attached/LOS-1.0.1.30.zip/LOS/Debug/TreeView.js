﻿
function TreeView_Debug()
{
    var Window=System.GetModule("Window.js").Window;
	var config={
		Width:600,
		Height:450,
		Left:0,
		Top:0,
		Css:'window',
		BorderWidth:6,
		Resizable:true,
		HasMinButton:false,
		Title:{
			Height:18,
			InnerHTML:'测试'
		},
		Content:{
			InnerHTML:''
		}
	}
	var form=new Window(config);
			
    var Control=System.GetModule("Controls.js").Control;
    var AnchorStyle=System.GetModule("Controls.js").AnchorStyle;
    var TreeView=System.GetModule("Controls.js").TreeView;
    
    var ds_asyn={
        IsAsyn:function(){return true;},
        GetSubNodes:function(path,completedCallback,errorCallback)
        {
	        var nodes=null;
	        if(path=="")
	        {
		        nodes=[{Name:"节点1",Text:"节点1"},{Name:"节点2",Text:"节点2"}];
	        }
	        else if(path=="节点1")
	        {
		        nodes=[{Name:"节点11",Text:"节点11"},{Name:"节点12",Text:"节点12"}]
	        }
	        else if(path=="节点2")
	        {
		        nodes=[{Name:"节点21",Text:"节点21"},{Name:"节点22",Text:"节点22"}]
	        }
	        else if(path=="节点1/节点12")
	        {
		        nodes=[{Name:"节点121",Text:"节点121"},{Name:"节点122",Text:"节点122"}]
	        }
	        else
	        {
		        nodes=[]
	        }
	        completedCallback(nodes);
        }
    }
    
    var ds={
        GetSubNodes:function(path)
        {
	        var nodes=null;
	        if(path=="")
	        {
		        nodes=[{Name:"节点1",Text:"节点1"},{Name:"节点2",Text:"节点2"}];
	        }
	        else if(path=="节点1")
	        {
		        nodes=[{Name:"节点11",Text:"节点11"},{Name:"节点12",Text:"节点12"}]
	        }
	        else if(path=="节点2")
	        {
		        nodes=[{Name:"节点21",Text:"节点21"},{Name:"节点22",Text:"节点22"}]
	        }
	        else if(path=="节点1/节点12")
	        {
		        nodes=[{Name:"节点121",Text:"节点121"},{Name:"节点122",Text:"节点122"}]
	        }
	        else
	        {
		        nodes=[]
	        }
	        return nodes;
        }
    }
    var tv=new TreeView(
        {
            Left:10,
            Top:10,
            Width:form.GetClientWidth()-20,
            Height:form.GetClientHeight()-20,
	        Parent:form,
	        AnchorStyle:AnchorStyle.All,
	        DataSource:ds,
	        BorderWidth:1
        }
    );
	
	form.MoveEx('center',0,0);
	form.Show(true);
}