﻿
//DebugFunc.Attach(TreeView_Debug);

//DebugFunc.Attach(Window_Debug);

//DebugFunc.Attach(FileBrowser_Debug);

//DebugFunc.Attach(ListView_Debug);

//DebugFunc.Attach(FolderBrowser_Debug);

//DebugFunc.Attach(Menu_Debug);

//DebugFunc.Attach(RichEditor_Debug);

DebugFunc.Attach(
	function()
	{
		var request=new XMLHttpRequest();
	}
);