﻿function CreateWindow(left,top,parent,hasMin)
{
    var Window=System.GetModule("Window.js").Window;
    
	var config={
		Width:600,
		Height:450,
		Left:left,
		Top:top,
		Css:'window',
		BorderWidth:6,
		Resizable:true,
		HasMinButton:hasMin,
		Title:{
			Height:18,
			InnerHTML:'测试'
		},
		Content:{
			InnerHTML:''
		},
		Parent:parent
	}
	
	var form=new Window(config);
	form.Show(true);
	
	return form;
}

function Window_Debug()
{
    var wnd11=CreateWindow(0,0,null,true);
    var wnd12=CreateWindow(50*1,50*1,wnd11,true);
    var wnd13=CreateWindow(50*2,50*2,wnd12,true);
    
    var wnd21=CreateWindow(100+50*3,100+50*3,null,true);
    var wnd22=CreateWindow(100+50*4,100+50*4,wnd21,true);
    var wnd23=CreateWindow(100+50*5,100+50*5,wnd21,true);
    
    var wnd31=CreateWindow(250+50*3,0+50*3,null,true);
    var wnd32=CreateWindow(250+50*4,0+50*4,wnd31,true);
    
    Taskbar.AddTask(wnd11);
    Taskbar.AddTask(wnd13);
}