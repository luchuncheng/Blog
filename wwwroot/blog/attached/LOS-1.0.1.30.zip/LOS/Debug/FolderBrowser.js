﻿
function FolderBrowser_Debug()
{
    var Window=System.GetModule("Window.js").Window;
	var config={
		Width:600,
		Height:450,
		Left:0,
		Top:0,
		Css:'window',
		BorderWidth:6,
		Resizable:true,
		HasMinButton:false,
		Title:{
			Height:18,
			InnerHTML:'测试'
		},
		Content:{
			InnerHTML:''
		}
	}
	var form=new Window(config);
			
    var Control=System.GetModule("Controls.js").Control;
    var AnchorStyle=System.GetModule("Controls.js").AnchorStyle;
    var FolderBrowser=System.GetModule("CommonDialog.js").FolderBrowser;
    
    var fb=new FolderBrowser(
        {
            Left:10,
            Top:10,
            Width:form.GetClientWidth()-20,
            Height:form.GetClientHeight()-20,
	        Parent:form,
	        AnchorStyle:AnchorStyle.All,
	        BorderWidth:1,
	        Root:"/lucc/Home",
	        InitPath:"/lucc/Home1/doc"
        }
    );
	
	form.MoveEx('center',0,0);
	form.Show(true);
}