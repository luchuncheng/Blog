﻿
function FileBrowser_Debug()
{
    var Window=System.GetModule("Window.js").Window;
	var config={
		Width:800,
		Height:600,
		Left:0,
		Top:0,
		Css:'window',
		BorderWidth:6,
		Resizable:true,
		HasMinButton:true,
		Title:{
			Height:18,
			InnerHTML:'测试'
		},
		Content:{
			InnerHTML:''
		}
	}
	var form=new Window(config);
			
    var Control=System.GetModule("Controls.js").Control;
    var AnchorStyle=System.GetModule("Controls.js").AnchorStyle;
    
    var FileBrowser=System.GetModule("CommonDialog.js").FileBrowser;
    
    var lv=new FileBrowser(
        {
            Left:0,
            Top:0,
            Width:form.GetClientWidth(),
            Height:form.GetClientHeight(),
	        Parent:form,
	        AnchorStyle:AnchorStyle.All,
	        EnableMultiSelect:true,
	        Root:"/"+System.GetUser(),
	        InitPath:"/"+System.GetUser()+"/Home"
        }
    );
    
    var task=Taskbar.AddTask(form,"测试");
    form.OnClosed.Attach(
		function()
		{
			Taskbar.RemoveTask(task);
		}
    );
	
	form.MoveEx('center',0,0);
	form.Show(true);
}