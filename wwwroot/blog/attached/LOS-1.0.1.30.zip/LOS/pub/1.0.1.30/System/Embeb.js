﻿
var Control=null;
var AnchorStyle=null;
var Window = null;
var Controls=null;

var Config = { };

function init(completeCallback,errorCallback)
{
	System.LoadModules(
		function()
		{
			Controls = System.GetModule("Controls.js");

			Window = System.GetModule("Window.js").Window;

			Control = System.GetModule("Controls.js").Control;
			AnchorStyle = System.GetModule("Controls.js").AnchorStyle;

			DocumentPanel = new DocumentPanelCtor();
			Module.Desktop = new DesktopCtor();
			Module.Taskbar = new TaskbarCtor();

			completeCallback();
		},
		errorCallback,
		["Controls.js", "Window.js"]
	);
}

function dispose(competeCallback,errorCallback)
{
	try
	{
		competeCallback();
	}
	catch(ex)
	{
		errorCallback(ex);
	}
}

function TransferCharForJavascript(s)
{
	newStr=s.replace(
		/[\x26\x27\x3C\x3E\x0D\x0A]/g,
		function(c)
		{
			ascii=c.charCodeAt(0);
			return '\\u00'+(ascii<16?'0'+ascii.toString(16):ascii.toString(16));
		}
	);
	return newStr;
}

function DocumentPanelCtor()
{
    var This=this;
    var config={
        Parent:null,
        Left:0,
        Top:0,
        Width:document.documentElement.clientWidth,
        Height:document.documentElement.clientHeight,
        Css:"",
        IsAbstract: true
    }
    
    Control.call(This,config);
    
    var Base={
        GetType:This.GetType,
        is:This.is
    }
    
    This.is=function(type){return type==this.GetType()?true:Base.is(type);}
    This.GetType = function() { return "DocumentPanel"; }

    window.onresize = function()
    {
    	var width = (document.documentElement.clientWidth > 300) ? document.documentElement.clientWidth : 300;
    	var height = (document.documentElement.clientHeight > 200) ? document.documentElement.clientHeight : 200;
    	This.Resize(width, height);
    }

    document.documentElement.onscroll = function(evt)
    {
		This.Move(document.documentElement.scrollLeft,document.documentElement.scrollTop);
    }
    
    document.body.appendChild(This.GetDom());
}

function DesktopCtor()
{
	var This = this;

	var config = {
		Parent: DocumentPanel,
		Left: 0,
		Top: 0,
		Width: DocumentPanel.GetWidth(),
		Height: DocumentPanel.GetHeight(),
		Css: "desktop",
		AnchorStyle: AnchorStyle.All,
		IsAbstract: true
	}

	Control.call(This, config);
	var Base = {
		GetType: This.GetType,
		is: This.is
	}

	This.is = function(type) { return type == this.GetType() ? true : Base.is(type); }
	This.GetType = function() { return "Desktop"; }

	This.GetDom().style.position = "fixed";

	var m_MoveDiv = document.createElement("DIV");
	m_MoveDiv.style.position = "absolute";
	m_MoveDiv.style.display = 'none';
	m_MoveDiv.style.zIndex = '100000';
	m_MoveDiv.style.left = '0px';
	m_MoveDiv.style.top = '0px';
	m_MoveDiv.className = 'moveBackground';
	m_MoveDiv.setAttribute("unselectable", "on");

	var m_DisableDiv = new Control(
		{
			Left: 0, Top: 0, Width: This.GetClientWidth(), Height: This.GetClientHeight(),
			AnchorStyle: Controls.AnchorStyle.All,
			Parent: This, Css: "desktop_disabled"
		}
    );

	m_DisableDiv.SetVisible(false);

	This.SetEnable = function(enable)
	{
		m_DisableDiv.SetVisible(!enable);
	}

	This.GetDom().appendChild(m_MoveDiv);

	This.GetDom().onscroll = function()
	{
		var dom = This.GetDom();
		if (dom.scrollLeft > 0 || dom.scrollTop > 0)
		{
			dom.scrollLeft = 0;
			dom.scrollTop = 0;
		}
	}

	var m_Items = {};

	This.EnterMove = function(cursor)
	{
		m_MoveDiv.style.width = This.GetWidth() + 'px';
		m_MoveDiv.style.height = This.GetHeight() + 'px';
		m_MoveDiv.style.display = 'block';
		System.DisableSelect(m_MoveDiv, true);
		m_MoveDiv.style.cursor = (cursor == undefined ? "default" : cursor);
	}

	This.LeaveMove = function()
	{
		m_MoveDiv.style.display = 'none';
	}

	var m_AllWin = [];

	This.AddWindow = function(wnd)
	{
		This.AddControl(wnd);
		m_AllWin.push(wnd);
	}

	This.RemoveWindow = function(wnd)
	{
		This.RemoveControl(wnd);

		var i = 0;
		while (m_AllWin[i] != wnd) i++;
		if (i < m_AllWin.length) m_AllWin.splice(i, 1);
	}

	This.CloseAllWindow = function()
	{
		var temp = [];

		for (var i in m_AllWin) temp.push(m_AllWin[i]);

		for (var i in temp) temp[i].Close();

		m_AllWin = [];
	}
}

function TaskbarItem(dialog, title)
{
	var This = this;

	this.title = function(newTitle)
	{
	}

	this.SetText = function(text)
	{
	}

	this.Shine = function(highlight)
	{
	}
}

function TaskbarCtor()
{      
    var This=this;

    var items = {};
	
	this.AddTask=function(dialog,title)
	{
		var item = new TaskbarItem();
		items[System.GenerateUniqueId()] = item;
		return item;
	}
	
	this.RemoveTask=function(item)
	{
		for(var k in items)
		{
			if(items[k]==item)
			{
				delete items[k];
				break;
			}
		}
	}
}

/*
function TaskbarItem(dialog, title)
{
	var This = this;
	if (title == undefined) title = "";
	this.Item = document.createElement("DIV");
	this.Item.className = "item";
	this.Item.innerHTML = title;
	this.Item.title = title;

	this.Item.onclick = function()
	{
		if (dialog == null) return;
		if (dialog.IsVisible())
		{
			if (dialog.IsTop())
				dialog.Hide();
			else
				dialog.BringToTop();
		}
		else
			dialog.Show(true);
		if (This.Item.className == "item_shine") This.Item.className = "item";
	}

	this.Dialog = dialog;

	this.title = function(newTitle)
	{
		if (newTitle != undefined) this.Item.innerHTML = System.ReplaceHtml(newTitle);
		This.Item.title = newTitle;
		return this.Item.innerHTML;
	}

	this.SetText = function(text)
	{
		This.Item.innerHTML = System.ReplaceHtml(text);
	}

	this.Shine = function(highlight)
	{
		if (highlight == undefined) highlight = false;
		var count = 8;
		var interval = setInterval(
			function()
			{
				if (count > 0)
				{
					if (count % 2 == 1)
					{
						This.Item.className = "item";
					}
					else
					{
						This.Item.className = "item_shine";
					}
					count--;
				}
				else
				{
					This.Item.className = (highlight ? "item_shine" : "item");
					clearInterval(interval);
				}
			},
			200
		);
	}
}

function TaskbarCtor()
{
	var This = this;

	var config = {
		Parent: DocumentPanel,
		Left: 0,
		Top: 0,
		Width: DocumentPanel.GetWidth(),
		Height: 28,
		Css: "taskbar",
		AnchorStyle: AnchorStyle.Top | AnchorStyle.Left | AnchorStyle.Right
	};

	Control.call(This, config);
	
	var Base = {
		GetType: This.GetType,
		is: This.is
	}
	This.is = function(type) { return type == this.GetType() ? true : Base.is(type); }
	This.GetType = function() { return "Taskbar"; }

	This.GetDom().style.position = "fixed";

	var m_HGuide = new Controls.GuideLine(This.GetClientWidth(), [140, 4, 13, 4, 0, 4, 13, 2]);

	var m_BtnLogout = new Control(
		{
			Parent: This,
			Left: 0, Top: 2, Width: 60, Height: 26,
			Css: 'logoutButton',
			AnchorStyle: AnchorStyle.Left | AnchorStyle.Top
		}
    );

	var menuConfig = {
		Items: [
			{ Text: "我的网盘", ID: "FileBrowser.js" },
			{ ID: "" },
			{ Text: "记事本", ID: "Notepad/Notepad.js" },
			{ Text: "电子书", ID: "CHH/CHH.js" },
			{ Text: "在线理财", ID: "Finance/Finance.js" },
			{ Text: "图片浏览", ID: "ImageBrowser.js" },
			{ Text: "即时通讯", ID: "IM/IM.js" },
			{ ID: "" },
			{ Text: "系统设置", ID: "Setting/Setting.js" }
		]
	};

	var m_AppMenu = new Controls.Menu(menuConfig);

	m_AppMenu.OnCommand.Attach(
		function(id)
		{
			System.Exec(function() { }, alert, id);
		}
	);

	var m_Toolbar = new Controls.Toolbar(
		{
			Parent: This,
			Left: 70, Top: 2, Width: 80, Height: Controls.Toolbar.PredefineHeight,
			AnchorStyle: AnchorStyle.Left | AnchorStyle.Top,
			Css: "toolbar",
			Items: [
				{ Css: "Image22_Folder", Text: "主文件夹", Command: "Home" }
            ]
		}
    );

	m_Toolbar.OnCommand.Attach(
		function(cmd)
		{
			if (cmd == "Home")
			{
				System.Exec(function() { }, alert, "FileBrowser.js");
			}
		}
    );

	m_BtnLogout.GetDom().innerHTML = "<div style='margin-top:6px; margin-left:10px;'>[退出]</div>";

	m_BtnLogout.GetDom().firstChild.onclick = function()
	{
		return System.Shutdown();
	}

	var m_BtnLeft = new Control(
		{
			Parent: This,
			Left: m_HGuide.Get(1), Top: 2, Width: m_HGuide.GetWidth(2), Height: 24,
			Css: 'btnLeft',
			AnchorStyle: AnchorStyle.Left | AnchorStyle.Top
		}
    );

	var m_BtnRight = new Control(
		{
			Parent: This,
			Left: m_HGuide.Get(5), Top: 2, Width: m_HGuide.GetWidth(6), Height: 24,
			Css: 'btnRight',
			AnchorStyle: AnchorStyle.Right | AnchorStyle.Top
		}
    );

	var m_ItemPanel = new Control(
		{
			Parent: This,
			Left: m_HGuide.Get(3), Top: 2, Width: m_HGuide.GetWidth(4), Height: 26,
			Css: 'itemPanel',
			AnchorStyle: AnchorStyle.All
		}
    );

	m_ItemPanel.GetDom().innerHTML = "<div class='itemContainer'></div>";

	var m_ItemContainer = m_ItemPanel.GetDom().firstChild;

	m_ItemContainer.style.width = '10px';
	m_ItemContainer.style.height = '26px';

	m_BtnLeft.GetDom().onclick = function()
	{
		m_ItemPanel.GetDom().scrollLeft -= m_ScrollUnit;
	}

	m_BtnRight.GetDom().onclick = function()
	{
		m_ItemPanel.GetDom().scrollLeft += m_ScrollUnit;
	}

	m_ItemPanel.OnResized.Attach(
		function()
		{
			ResizeContainer();
			CalcScrollUnit();
		}
	);

	m_ItemContainer.onmousedown = function(evt)
	{
		var width = GetContainerWidth();
		m_ItemContainer.style.width = width;

		if (m_ItemPanel.GetClientWidth() < width)
		{
			if (evt == undefined) evt = event;

			MoveVar = {
				PreClientX: evt.clientX,
				PreScrollLeft: m_ItemPanel.GetDom().scrollLeft,
				Object: m_ItemPanel.GetDom()
			}
		}
	}

	function GetContainerWidth()
	{
		return m_Count >= 0 ? m_Count * m_ItemWidth + 8 : 10;
	}

	function ResizeContainer()
	{
		var width = GetContainerWidth();
		m_ItemContainer.style.width = width + 'px';

		if (m_ItemPanel.GetClientWidth() < width)
		{
			m_BtnLeft.SetVisible(true);
			m_BtnRight.SetVisible(true);
		}
		else
		{
			m_BtnLeft.SetVisible(false);
			m_BtnRight.SetVisible(false);
		}
		m_ItemPanel.GetDom().scrollLeft = m_ItemPanel.GetDom().scrollLeft;
	}

	function CalcScrollUnit()
	{
		var width = m_ItemPanel.GetClientWidth();
		var temp = Math.round(width / m_ItemWidth - 0.5);
		m_ScrollUnit = ((width % m_ItemWidth == 0) ? width : (Math.round(width / m_ItemWidth - 0.5) * m_ItemWidth));
	}


	var items = {};
	var m_Count = 0;
	var m_ItemWidth = 110;
	var m_ScrollUnit = 0;

	this.AddTask = function(dialog, title)
	{
		var item = new TaskbarItem(dialog, title);
		items[System.GenerateUniqueId()] = item;
		m_ItemContainer.appendChild(item.Item);
		m_Count++;
		ResizeContainer();

		return item;
	}

	this.RemoveTask = function(item)
	{
		for (var k in items)
		{
			if (items[k] == item)
			{
				m_ItemContainer.removeChild(items[k].Item);
				delete items[k];
				m_Count--;
				ResizeContainer();
				break;
			}
		}
	}

	m_BtnLeft.SetVisible(false);
	m_BtnRight.SetVisible(false);

	CalcScrollUnit();
}
*/
	
var MoveVar=null;

function body_onmousemove(evt)
{
	if(MoveVar!=null)
	{
		if(evt==undefined) evt=event;
		MoveVar.Object.scrollLeft=MoveVar.PreScrollLeft-(evt.clientX-MoveVar.PreClientX);
	}
}

function body_onmouseup(evt)
{
	MoveVar=null;
}

if(document.attachEvent)
{
	document.attachEvent(
		"onmousemove",
		function(evt)
		{
			if(evt==null) evt=window.event;
			body_onmousemove(evt);
		}
	);
	document.attachEvent(
		"onmouseup",
		function(evt)
		{
			if(evt==null) evt=window.event;
			body_onmouseup(evt);
		}
	);
}
else if(document.addEventListener)
{
	document.addEventListener(
		"mousemove",
		function(evt)
		{
			if(evt==null) evt=window.event;
			return body_onmousemove(evt);
		},
		false
	)
	document.addEventListener(
		"mouseup",
		function(evt)
		{
			if(evt==null) evt=window.event;
			return body_onmouseup(evt);
		},
		false
	)
}