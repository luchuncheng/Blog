﻿
var DEBUG = false;
var DesktopModlue = "Embeb.js";
var Start = null;
var BaseDirectory = "Lesktop";

function window_onload()
{
	System.Initialize();
}

if (document.attachEvent)
{
	window.attachEvent("onload", window_onload);
}
else if (document.addEventListener)
{
	window.addEventListener("load", window_onload, false);
}