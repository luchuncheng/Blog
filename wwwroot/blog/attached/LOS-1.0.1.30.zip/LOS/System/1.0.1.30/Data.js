﻿
function init(completeCallback,errorCallback)
{
	completeCallback();
}

function dispose(completeCallback,errorCallback)
{
	completeCallback();
}

Module.SQLite = {};

Module.SQLite.ExecuteNonQuery = function(callback, errorCallback, path, cmdText)
{
	var data = System.CreateServiceData(
		"SQLiteService", "ExecuteNonQuery", { Path: path, CommandText: cmdText }
	);
	
	System.SendCommand(
		function(ret)
		{
			try
			{
				if(callback != undefined && callback != null) callback(ret);
			}
			catch(ex)
			{
			}
		},
		function(error)
		{
			try
			{
				if(errorCallback != undefined && errorCallback != null) errorCallback(error);
			}
			catch(ex)
			{
			}
		},
		data
	);
}

Module.SQLite.ExecuteQuery = function(callback, errorCallback, path, cmdText)
{
	var data = System.CreateServiceData(
		"SQLiteService", "ExecuteQuery", { Path: path, CommandText: cmdText }
	);
	
	System.SendCommand(
		function(ret)
		{
			try
			{
				if(callback != undefined && callback != null) callback(ret);
			}
			catch(ex)
			{
			}
		},
		function(error)
		{
			try
			{
				if(errorCallback != undefined && errorCallback != null) errorCallback(error);
			}
			catch(ex)
			{
			}
		},
		data
	);
}

Module.SQLite.Create = function(callback, errorCallback, path, ddl, raiseError)
{
	var data = System.CreateServiceData(
		"SQLiteService", "Create", { Path: path, DDL: ddl, RaiseError: raiseError.toString() }
	);
	
	System.SendCommand(
		function(ret)
		{
			try
			{
				if(callback != undefined && callback != null) callback(ret);
			}
			catch(ex)
			{
			}
		},
		function(error)
		{
			try
			{
				if(errorCallback != undefined && errorCallback != null) errorCallback(error);
			}
			catch(ex)
			{
			}
		},
		data
	);
}