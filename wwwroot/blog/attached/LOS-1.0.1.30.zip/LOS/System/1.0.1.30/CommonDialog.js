﻿
var Control=null;
var AnchorStyle=null;
var ListView=null;
var TreeView=null;
var Window=null;
var Directory=null;
var File=null;
var Button=null;
var Menu=null;
var Label=null;
var TextBox=null;

var Controls=null;
var IO=null;

function init(completeCallback,errorCallback)
{
	System.LoadModules(
		function()
		{
			Controls=System.GetModule("Controls.js");
			
			Control=System.GetModule("Controls.js").Control;
			Button=System.GetModule("Controls.js").Button;
			Label=System.GetModule("Controls.js").Label;
			TextBox=System.GetModule("Controls.js").TextBox;
			Menu=System.GetModule("Controls.js").Menu;
			AnchorStyle=System.GetModule("Controls.js").AnchorStyle;
			ListView=System.GetModule("Controls.js").ListView;
			TreeView=System.GetModule("Controls.js").TreeView;
			Menu=System.GetModule("Controls.js").Menu;
			Window=System.GetModule("Window.js").Window;
			Directory=System.GetModule("IO.js").Directory;
			File=System.GetModule("IO.js").File;
			
			IO=System.GetModule("IO.js");

			IO.FileSystem.OnRefresh.Attach(
				function(path,infos)
				{
					delete ThumbnailImageCache[path.toUpperCase()];
				}
			);
			
			completeCallback();
		},
		errorCallback,
		["Window.js","Controls.js","IO.js"]
	);
}

function Match(reg,str)
{
	reg.lastIndex = 0;
	var res = reg.exec(str);
	return (res != null && res[0].length == str.length);
}

function GetFileName(fullName)
{
	var index=fullName.lastIndexOf("/")
	return index==-1?fullName:fullName.substring(index+1,fullName.length);
}

function GetFileNameNoExtention(fullName)
{
	var index=fullName.lastIndexOf("/")
	var name=(index==-1?fullName:fullName.substring(index+1,fullName.length));
	index=name.lastIndexOf(".");
	return index==-1?name:name.substring(0,index);
}

function GetDirectoryName(fullName)
{
	var index=fullName.lastIndexOf("/")
	switch(index)
	{
	case -1:
	    return null;
	case 0:
	    return "/";
	default:
	    return fullName.substring(0,index);
	}
}

function Compare(obj1,obj2)
{
	if((obj1==undefined || obj1==null) || (obj2==undefined || obj2==null)) return 0;
	if(obj1>obj2) return 1;
	else if(obj1<obj2) return -1;
	else return 0;
}

function FormatInt(val,len)
{
    var s=val.toString();
    for(var i=0;i<len-s.length;i++)
    {
        s='0'+s;
    }
    return s;
}

function GetParentPath(path)
{
	var index=path.lastIndexOf('/')
	if(index!=-1) 
	{
		var parent=path.substring(0,index);
		return parent;
	}
}

var SelectedItems=[];
var DeleteSelectedItems;

/*
config={
    ...:继承Control
    Root:
    InitPath:
    EnableMultiSelect
}
*/
function FileBrowser(config)
{
	var This = this;
	var fileBrowser = this;

	Control.call(This, config);

	var Base = {
		GetType: This.GetType,
		is: This.is
	}

	This.is = function(type) { return type == This.GetType() ? true : Base.is(type); }
	This.GetType = function() { return "FileBrowser"; }

	var m_SortType = 'ASC', m_SortColumn = 'Name';

	This.AfterChange = new Delegate();
	This.OnBeginRequest = new Delegate();
	This.OnEndRequest = new Delegate();
	This.OnFileItemDblClick = new Delegate();

	var root = IsNull(config.Root, System.GetFullPath("Home"));
	var current = IsNull(config.InitPath, config.Root);

	var filter = IsNull(config.Filter, null);

	function BeginRequest()
	{
		This.OnBeginRequest.Call(This);
	}
	function EndRequest()
	{
		This.OnEndRequest.Call(This);
	}

	var toolbar = new Controls.Toolbar(
		{
			Left: 0, Top: 0, Width: fileBrowser.GetClientWidth(), Height: 24,
			AnchorStyle: AnchorStyle.Left | AnchorStyle.Right,
			Parent: fileBrowser,
			Css: "toolbar",
			Items: [
				{ Css: "Image22_Upward", Text: "上一级", Command: "Upward" },
				{ Css: "Image22_Refresh", Text: "刷新", Command: "Refresh" },
				{ Css: "Image22_MoveTo", Text: "移动到", Command: "MoveTo" },
				{ Css: "Image22_CopyTo", Text: "复制到", Command: "CopyTo" },
				{ Css: "Image22_Upload", Text: "上传", Command: "Upload" }
            ]
		}
    );

	toolbar.OnCommand.Attach(OnCommand);

	var m_Columns = [
        { Name: "Name", Text: "名称", Width: 200, Css: "td_header_Name" },
        { Name: "Type", Text: "类型", Width: 60, Css: "td_header_Type" },
        { Name: "Size", Text: "大小", Width: 80, Css: "td_header_Size", RowCss: "col_Size" },
        { Name: "LastModifiedTime", Text: "修改时间", Width: 140, Css: "td_header_LastModifiedTime", RowCss: "col_LastModifiedTime" },
        { Name: "Operation", Text: "&nbsp;", Width: 60, Css: "td_header_Size" }
    ];
    
    var m_FolderBrowser=new Module.FolderBrowser(
		{
            Left:0,Top:25,Width:180,Height:This.GetClientHeight()-24-1,
            AnchorStyle:AnchorStyle.Left | AnchorStyle.Top | AnchorStyle.Bottom,
            Parent:This,
	        BorderWidth:1,
	        Roots:[
				{Path:root,HasChildren:true}
	        ],
	        OnBeginRequest:BeginRequest,
	        OnEndRequest:EndRequest
		}
    );
    
    var listview=new ListView(
        {
            Left:186,Top:25,Width:This.GetClientWidth()-186,Height:This.GetClientHeight()-24-1,
            AnchorStyle:AnchorStyle.All,
            Parent:This,
	        BorderWidth:1,
	        Columns:m_Columns,
	        ListMode:{
	        },
	        EnableMultiSelect:IsNull(config.EnableMultiSelect,true)
        }
    );
    
    var m_VectialSplit=new Controls.VerticalSplit(
		{
            Left:180,Top:25,Width:6,Height:This.GetClientHeight()-24-1,
            AnchorStyle:AnchorStyle.Left | AnchorStyle.Top | AnchorStyle.Bottom,
            Parent:This,
            LeftControl:m_FolderBrowser,
            RightControl:listview
		}
    );
    
    listview.CompareItem=function(item1,item2,param)
    {
		var ret=0;
		if(item1.GetFileInfo("Type")==item2.GetFileInfo("Type"))
		{
			switch(param.Column)
			{
			case "Type":
			case "LastModifiedTime":
				{
					ret=Compare(item1.GetFileInfo(param.Column),item2.GetFileInfo(param.Column));
					break;
				}
			case "Size":
				{
					ret=Compare(IsNull(item1.GetFileInfo(param.Column),0),IsNull(item2.GetFileInfo(param.Column),0));
					break;
				}
			case "Name":
				{
					ret=Compare(item1.GetFileInfo(param.Column).toUpperCase(),item2.GetFileInfo(param.Column).toUpperCase());
					break;
				}
			}
		}
		else
		{
			ret=item1.GetFileInfo("Type")>item2.GetFileInfo("Type")
		}
		if(param.SortType=='DESC') ret*=-1;
		return ret;
    }
    
    listview.OnItemDblClick.Attach(
        function(item)
        {
            if(item.GetFileInfo("Type")=='D' || item.GetFileInfo("Type")=='E')
            {
                This.SetCurrentPath(current=='/'?current+item.GetFileInfo("Name"):current+'/'+item.GetFileInfo("Name"));
            }
            else
            {
                This.OnFileItemDblClick.Call(item);
            }
        }
    );
    listview.OnColumnClick.Attach(
		function(index)
		{
			if(m_SortType=='DESC') m_SortType="ASC";else m_SortType='DESC';
			m_SortColumn=m_Columns[index].Name;
            listview.Sort({Column:m_SortColumn,SortType:m_SortType});
		}
    );
    
	var menuConfig={
		Items:[
			{Text:"打开方式...",ID:"OpenWith"},
			{ID:""},
			{Text:"复制",ID:"Copy"},
			{Text:"剪切",ID:"Move"},
			{Text:"粘帖",ID:"Paste"},
			{ID:""},
			{Text:"重命名...",ID:"Rename"},
			{Text:"删除",ID:"Delete"},
			{ID:""},
			{Text:"全选",ID:"SelectAll"},
			{Text:"刷新",ID:"Refresh"},
			{Text:"新建文件夹...",ID:"NewFolder"},
			{Text:"新建文件...",ID:"NewFile"},
			{ID:""},
			{Text:"压缩",ID:"Zip"},
			{Text:"解压",ID:"Unzip"}
		]
	};
	
	listview.ContextMenu=new Menu(menuConfig);
    listview.ContextMenu.OnCommand.Attach(OnCommand);
    
    m_FolderBrowser.OnClick.Attach(
		function(node)
		{
			This.SetCurrentPath(node.GetTag().FullName);
		}
	);
    
    This.Select=function(callback,path)
    {
		m_FolderBrowser.Select(callback,path);
    }
    
    This.Expand=function(callback,path)
    {
		m_FolderBrowser.Expand(callback,path);
    }
     
    function Go(path,competeCallback,errorCallback)
    {
		
        if(path==undefined || path==null) path=current;
        
		IO.Directory.GetSubItems(complete,error,path);
        
        function complete(infos)
        {
			current=path;
			listview.Clear();
			_items = [];
			for(var i in infos)
			{
				if(filter == null || infos[i].Type != 'F' || Match(filter, infos[i].Name))
				{
					var newItem=new ListItem(infos[i])
					_items.push(newItem);
					listview.AppendItem(newItem);
				}
			}
			listview.Sort({Column:m_SortColumn,SortType:m_SortType});
			This.Select(
				function()
				{
					if(competeCallback!=undefined) competeCallback();
					This.AfterChange.Call(This);
				},
				current
			)
        }
        
        function error(msg)
        {
			This.Select(
				function()
				{
					if(errorCallback!=undefined) errorCallback(msg);else System.HandleException(msg);
				},
				current
			)
        }
    }
    This.GetCurrentPath=function()
    {
		return current;
    }
    This.SetCurrentPath=function(path,completeCallback,errorCallback)
    {
		BeginRequest();
		try
		{
			Go(	
				path,
				function()
				{
					EndRequest();
					if(completeCallback!=null) completeCallback();
				},
				function(e)
				{
					EndRequest();
					if(errorCallback!=undefined) errorCallback(e);else System.HandleException(e);
				}
			);
		}
		catch(ex)
		{
			EndRequest();
			if(errorCallback!=undefined) errorCallback(ex);
			else System.HandleException(new Exception(ex.name,ex.message));
		}
    }
    This.GetSelectedItems=function()
    {
		return listview.GetSelectedItems();
    }
    This.GetSelectedItemsPath=function()
    {
		var items=listview.GetSelectedItems();
		var files=[];
		for(var i in items)
		{
			var item=items[i];
			files.push(current+"/"+item.GetFileInfo("Name"));
		}
		return files;
    }
    This.Refresh=function(completeCallback,errorCallback)
    {        
		if(completeCallback==undefined) completeCallback=function(){};
		
		IO.Directory.Refresh(completeCallback,error,current,false);
        
        function error(msg)
        {
			if(errorCallback!=undefined) errorCallback();else System.HandleException(msg);
        }
    }
    This.Upward=function()
    {
        if(current!=root)
        {
            This.SetCurrentPath(GetParentPath(current));
        }
    }

    var _items = [];

    This.Exists = function(fileName)
    {
    	for (var i = 0; i < _items.length; i++)
    	{
    		if (_items[i].GetFileInfo("Name").toUpperCase() == fileName.toUpperCase())
    		{
    			return true;
    		}
    	}
    	return false;
    }
    
    m_FolderBrowser.OnRefresh.Attach(
		function(node)
		{
			This.SetCurrentPath(node.GetTag().FullName);
		}
    );
    
    This.SetCss("fileBrowser");
    
    if(config.OnBeginRequest!=undefined) This.OnBeginRequest.Attach(config.OnBeginRequest);
    if(config.OnEndRequest!=undefined) This.OnEndRequest.Attach(config.OnEndRequest);
    
    function ListItem(values)
    {
        this.GetFileInfo=function(name){return values[name];}
        
        this.GetText=function(columnName)
        {
            switch(columnName)
            {
            case "Name":
				{
					var icon = "";
										
					if (values.Type == "F")
					{
						if (System.Path.GetFileExtension(values.Name).toLowerCase() == ".run") icon = String.format("<div style='float:left; width:16px; height:16px; margin-left:4px; background: url({0})'></div>", System.GetUrl(current + "/" + values.Name + "/app.png"));
						else icon = "<div class='Image16_File' style='float:left; width:16px; height:16px; margin-left:4px;'></div>";
					}
					else if (values.Type == "D") 
					{
						icon = "<div class='Image16_Folder' style='float:left; width:16px; height:16px; margin-left:4px;'></div>";
					}
					else 
					{
						if (values.Type == "E") icon = "<div class='Image16_Zip' style='float:left; width:16px; height:16px; margin-left:4px;'></div>";
					}
					content = String.format("{0}<div class='td_name'>{1}</div>", icon, values.Name);
					
					return content;
				}
            case "Size":
				if(values.Type != 'D')
				{
				    var data=values.Size;
					var size;
					if(data<1024) size=data+' B';
					else if(data<1024*1024) size=Math.round(data*100/1024)/100+' KB';
					else if(data<1024*1024*1024) size=Math.round(data*100/(1024*1024))/100+' MB'
					else size=Math.round(data*100/(1024*1024*1024))/100+' GB'
					content=String.format(
						"<span>{0}</span>",
						size
					);
					return content;
				}
				else
				{
					return "<span>-</span>";
				}
            case "LastModifiedTime":
                var data=values.LastModifiedTime;
				content=String.format(
					"<span>{0}-{1}-{2} {3}:{4}:{5}</span>",
					FormatInt(data.getFullYear(),4),
					FormatInt(data.getMonth()+1,2),
					FormatInt(data.getDate(),2),
					FormatInt(data.getHours(),2),
					FormatInt(data.getMinutes(),2),
					FormatInt(data.getSeconds(),2)
				);
				return content;
			case "Type":
				content = String.format(
					"<span>{0}</span>",
					values.Type == 'E' ? "压缩文件" : (values.Type == 'D' ? "文件夹" : "文件")
				);
				return content;
			case "Operation":
				if(values.Type=='F' || values.Type=='E')
				{
					content=String.format(
						"<a href='{0}' target='_blank'>下载</a>",System.GetUrl(current+"/"+values.Name)
					);
				}
				else
					content="&nbsp;";
				return content;
            }
        }
    }
    
    function OnCommand(command)
    {
        switch(command)
        {
        case "Upward":
            This.Upward();
            break;
        case "Refresh":
			{
				BeginRequest();
				This.Refresh(EndRequest,EndRequest);
				break;
			}
        case "Upload":
			{
				Module.Upload(current,This.GetTopContainer(),function(){This.Refresh();});
				break;
			}
        case "NewFolder":
			{
				Module.Prompt(
					"请输入文件夹名称:","",This.GetTopContainer(),
					function(name)
					{
						if(name!=null && name!="")
						{
							BeginRequest();
							Directory.Create(
								EndRequest,
								function(msg)
								{
									System.HandleException(msg);
									EndRequest();
								},
								current+"/"+name
							)
						}
					}
				);
				break;
			}
        case "NewFile":
			{
				Module.Prompt(
					"请输入文件名称:","",This.GetTopContainer(),
					function(name)
					{
						if(name!=null && name!="")
						{
							BeginRequest();
							File.Create(
								function()
								{
									EndRequest();
								},
								function(msg)
								{
									System.HandleException(msg);
									EndRequest();
								},
								current+"/"+name
							)
						}
					}
				);
				break;
			}
        case "Rename":
			{
				var items=listview.GetSelectedItems();
				if(items.length>0)
				{
					var item=items[0];
					Module.Prompt(
						String.format('请输入"{0}"的新名称:',item.GetFileInfo("Name")),
						item.GetFileInfo("Name"),
						This.GetTopContainer(),
						function(name)
						{
							if(name!=null && name!="")
							{
								BeginRequest();
								File.Rename(
									function()
									{
										EndRequest();
									},
									function(msg)
									{
										System.HandleException(msg);
										EndRequest();
									},
									current+"/"+item.GetFileInfo("Name"),
									name
								)
							}
						}
					);
				}
				break;
			}
        case "Delete":
			{
				var files=This.GetSelectedItemsPath();
				if(files.length>0)
				{
					Module.Confirm(
						"您确定要删除选中的项目吗？",This.GetTopContainer(),
						function()
						{
							BeginRequest();
							Directory.DeleteItems(
								function()
								{
									EndRequest();
								},
								function(msg)
								{
									System.HandleException(msg);
									EndRequest();
								},
								files
							)
						}
					);
				}
				break;
			}
        case "MoveTo":
			{
				var items=listview.GetSelectedItems();
				if(items.length>0)
				{
					var folderBrowser=new Module.FolderBrowserDialog(
						{
							Left:0,Top:0,Width:400,Height:400,
							Css:'window',
							BorderWidth:6,
							Resizable:true,
							HasMinButton:false,
							Title:{
								Height:18,
								InnerHTML:'文件夹浏览'
							},
							Desription:"请选择要移动到的文件夹:",
							Root:"/"+System.GetUser()+"/Home"
						}
					);
					folderBrowser.OnSelected.Attach(
						function(fb)
						{
							var path=fb.GetSelectedFolderPath();
							if(path!=null)
							{
								var files=[];
								for(var i in items)
								{
									var item=items[i];
									files.push(current+"/"+item.GetFileInfo("Name"));
								}
								
								BeginRequest();
								
								File.Move(
									function()
									{
										EndRequest();
									},
									function(msg)
									{
										alert(msg);
										EndRequest();
									},
									files,
									path
								);
							}
						}
					);
					folderBrowser.ShowDialog(This.GetTopContainer(),'center',0,0);
					folderBrowser.Focus();
				}
				break;
            }
        case "CopyTo":
			{
				var items=listview.GetSelectedItems();
				if(items.length>0)
				{
					var folderBrowser=new Module.FolderBrowserDialog(
						{
							Left:0,Top:0,Width:400,Height:400,
							Css:'window',
							BorderWidth:6,
							Resizable:true,
							HasMinButton:false,
							Title:{
								Height:18,
								InnerHTML:'文件夹浏览'
							},
							Desription:"请选择要复制到的文件夹:",
							Root:"/"+System.GetUser()+"/Home"
						}
					);
					folderBrowser.OnSelected.Attach(
						function(fb)
						{
							var path=fb.GetSelectedFolderPath();
							if(path!=null)
							{
								var files=[];
								for(var i in items)
								{
									var item=items[i];
									files.push(current+"/"+item.GetFileInfo("Name"));
								}
								
								BeginRequest();
								
								File.Copy(
									function()
									{
										EndRequest();
									},
									function(msg)
									{
										alert(msg);
										EndRequest();
									},
									files,
									path
								);
							}
						}
					);
					folderBrowser.ShowDialog(This.GetTopContainer(),'center',0,0);
					folderBrowser.Focus();
				}
				break;
            }
        case "Copy":
			{
				var items=listview.GetSelectedItems();
				SelectedItems=[];
				for(var i in items)
				{
					var item=items[i];
					SelectedItems.push(fileBrowser.GetCurrentPath()+"/"+item.GetFileInfo("Name"));
				}
				break;
            }
        case "Move":
			{
				var items=listview.GetSelectedItems();
				SelectedItems=[];
				for(var i in items)
				{
					var item=items[i];
					SelectedItems.push(fileBrowser.GetCurrentPath()+"/"+item.GetFileInfo("Name"));
				}
				DeleteSelectedItems=true;
				break;
            }
       case "Paste":
            {
				if(SelectedItems!=null && SelectedItems.length>0)
				{
					BeginRequest();
					if(DeleteSelectedItems)
					{	
						File.Move(
							function()
							{
								EndRequest();
							},
							function(msg)
							{
								alert(msg);
								EndRequest();
								SelectedItems=null;
							},
							SelectedItems,
							fileBrowser.GetCurrentPath()
						);
					}
					else
					{
						File.Copy(
							function()
							{
								EndRequest();
							},
							function(msg)
							{
								alert(msg);
								EndRequest();
							},
							SelectedItems,
							fileBrowser.GetCurrentPath()
						);
					}
				}
				break;
            }
        case "OpenWith":
            {
				var items=listview.GetSelectedItems();
				if(items.length>0)
				{
					var item=items[0];
					if(item.GetFileInfo("Type")=='F')
						System.Exec(function(){},alert,"OpenWith.js",current+"/"+item.GetFileInfo("Name"),true);
				}
				break;
            }
        case "SelectAll":
			{
				listview.SelectAll();
				break;
			}
		case "Zip":
			{
				var files=This.GetSelectedItemsPath();
				if(files.length>0)
				{
					Module.Prompt(
						"请输入压缩文件名：",
						files.length==1?GetFileNameNoExtention(files[0])+".zip":GetFileNameNoExtention(current)+".zip",
						This.GetTopContainer(),
						function(name)
						{
							if(name==null) return;
							
							BeginRequest();
							File.Zip(
								function()
								{
									EndRequest();
								},
								function(msg)
								{
									System.HandleException(msg);
									EndRequest();
								},
								files,
								current+"/"+name
							)
						}
					);
				}
				break;
			}
		case "Unzip":
			{
				var items=This.GetSelectedItems();
				var item=null;
				for(var i in items) 
				{
					if(items[i].GetFileInfo("Type")=='F')
					{
						item=items[i];break;
					}
				}
				if(item!=null)
				{
					BeginRequest();
					File.UnZip(
						function()
						{
							EndRequest();
						},
						function(msg)
						{
							System.HandleException(msg);
							EndRequest();
						},
						current+"/"+item.GetFileInfo("Name"),
						current+"/"+IO.Path.GetFileNameNoExtention(item.GetFileInfo("Name"))
					)
				}
				break;
			}
        }
    }
}

Module.FileBrowser=FileBrowser;

function OpenFileDialog(config)
{
	var wndConfig = {
		Width: 780, Height: IsNull(config.Height, 580), Left: 0, Top: 0,
		Css: 'window', BorderWidth: 6,
		Resizable: true, HasMinButton: false,
		Title: { Height: 18, InnerHTML: IsNull(config.Title, "打开文件") }
	};
	
    var This=this;
    
    Window.call(This,wndConfig);
    
    var Base={
        GetType:This.GetType,
        is:This.is
    }
    
    This.is=function(type){return type==This.GetType()?true:Base.is(type);}
    This.GetType=function(){return "OpenFileDialog";}
    
    var m_FileBrowser=new FileBrowser(
		{
            Left:8,Top:4,Width:This.GetClientWidth()-8*2,Height:This.GetClientHeight()-4-8-Button.Height-8,
	        Parent:This,
	        AnchorStyle:AnchorStyle.All,
	        EnableMultiSelect:IsNull(config.EnableMultiSelect,false),
	        Root:IsNull(config.Root,System.GetFullPath("Home")),
	        Filter: IsNull(config.Filter, null),
	        OnBeginRequest:function()
			{
				This.Waiting();
			},
			OnEndRequest:function()
			{
				This.Completed();
			}
		}
    );
    
    var m_BtnOK=new Button(
		{
			Left:This.GetClientWidth()-64-8-64-8,Top:This.GetClientHeight()-Button.Height-8,Width:64,Height:Button.Height,
			AnchorStyle:AnchorStyle.Bottom | AnchorStyle.Right,
			Text:"打 开",
			Css:"button_default",
			Parent:This
		}
    );
    
    var m_BtnCancel=new Button(
		{
			Left:This.GetClientWidth()-64-8,Top:This.GetClientHeight()-Button.Height-8,Width:64,Height:Button.Height,
			AnchorStyle:AnchorStyle.Bottom | AnchorStyle.Right,
			Text:"取 消",
			Parent:This
		}
    );
    
    var m_Result="None";
    This.GetResult=function(){return m_Result;}
    
    This.GetCurrentPath=function(){return m_FileBrowser.GetCurrentPath();}
    This.SelectedItems=function(){return m_FileBrowser.GetSelectedItems();}
    This.SelectedItemsPath=function(){return m_FileBrowser.GetSelectedItemsPath();}
    
    m_BtnOK.OnClick.Attach(OnClose);
    m_BtnCancel.OnClick.Attach(function(){This.Close();});
    m_FileBrowser.OnFileItemDblClick.Attach(OnClose);
    
	function OnClose()
	{
		var items=m_FileBrowser.GetSelectedItems();
		if(items.length>0 && (config.EnableMultiSelect || items[0].GetFileInfo("Type")=="F"|| items[0].GetFileInfo("Type")=="E"))
		{
			m_Result="OK";
			This.Close();
		}
		else
		{
			Module.Alert("请选择一个文件!",This,function(){This.Focus()});
		}
	}
	
	This.SetAcceptButton(m_BtnOK);
	This.SetCancelButton(m_BtnCancel);
    
    m_FileBrowser.Expand(
		function()
		{
			m_FileBrowser.SetCurrentPath(IsNull(config.InitPath,System.GetFullPath("Home")));
		},
		IsNull(config.Root,System.GetFullPath("Home"))
	);
}

Module.OpenFile=function(config,parent,completeCallback)
{
	if(config.Height == undefined && parent != null)
	{
		config.Height = parent.GetHeight() - 60;
	}
	
	var openDlg=new OpenFileDialog(config);
	openDlg.ShowDialog(
		parent,'center',0,0,
		function(wnd)
		{
			parent.Focus();
			if(wnd.GetResult()=="OK") completeCallback(wnd.SelectedItemsPath());
		}
	);
	openDlg.Focus();
};

function SaveFileDialog(config)
{
	var wndConfig = {
		Width: 780, Height: IsNull(config.Height, 580), Left: 0, Top: 0,
		Css: 'window', BorderWidth: 6,
		Resizable: true, HasMinButton: false,
		Title: { Height: 18, InnerHTML: IsNull(config.Title, "保存文件") }
	};
	
    var This=this;
    
    Window.call(This,wndConfig);
    
    var Base={
        GetType:This.GetType,
        is:This.is
    }
    
    This.is=function(type){return type==This.GetType()?true:Base.is(type);}
    This.GetType=function(){return "SaveFileDialog";}
    
    var m_FileBrowser=new FileBrowser(
		{
            Left:8,Top:4,Width:This.GetClientWidth()-8*2,Height:This.GetClientHeight()-4-8-Button.Height-8,
	        Parent:This,
	        AnchorStyle:AnchorStyle.All,
	        EnableMultiSelect:IsNull(config.EnableMultiSelect,false),
	        Root:IsNull(config.Root,System.GetFullPath("Home")),
	        InitPath:IsNull(config.InitPath,System.GetFullPath("Home")),
	        OnBeginRequest:function()
			{
				This.Waiting();
			},
			OnEndRequest:function()
			{
				This.Completed();
			}
		}
    );
    
    var m_BtnOK=new Button(
		{
			Left:This.GetClientWidth()-64-8-64-8,Top:This.GetClientHeight()-Button.Height-8,Width:64,Height:Button.Height,
			AnchorStyle:AnchorStyle.Bottom | AnchorStyle.Right,
			Text:"保 存",
			Css:"button_default",
			Parent:This
		}
    );
    
    var m_BtnCancel=new Button(
		{
			Left:This.GetClientWidth()-64-8,Top:This.GetClientHeight()-Button.Height-8,Width:64,Height:Button.Height,
			AnchorStyle:AnchorStyle.Bottom | AnchorStyle.Right,
			Text:"取 消",
			Parent:This
		}
    );
    
    var m_Label1=new Label(
		{
			Left:8,Top:This.GetClientHeight()-12-(Button.Height-12)/2-8,Width:64,Height:12,
			AnchorStyle:AnchorStyle.Bottom | AnchorStyle.Right,
			Text:"文件名称:",
			Parent:This
		}
    );
    
    var m_EditFileName=new TextBox(
		{
			Left:8+64,Top:This.GetClientHeight()-22-(Button.Height-22)/2-8,Width:This.GetClientWidth()-64-8*2-8-64-64-8,Height:22,
			AnchorStyle:AnchorStyle.Left | AnchorStyle.Right | AnchorStyle.Bottom,
			Parent:This
		}
    );
    
    var m_Result="None";
    This.GetResult=function(){return m_Result;}
    
    var m_FileName="";
    This.GetFileName=function(){return m_FileName;}

    m_BtnOK.OnClick.Attach(
		function()
		{
			m_FileName = m_EditFileName.GetText();
			if (m_FileName != "")
			{
				if (m_FileBrowser.Exists(m_FileName))
				{
					Module.Confirm(
						String.format("{0} 已存在，是否覆盖？", m_FileName), This,
						function()
						{
							m_FileName = m_FileBrowser.GetCurrentPath() + "/" + m_FileName;
							m_Result = "OK";
							This.Close();
						}
					);
				}
				else
				{
					m_FileName = m_FileBrowser.GetCurrentPath() + "/" + m_FileName;
					m_Result = "OK";
					This.Close();
				}
			}
		}
	);
    m_BtnCancel.OnClick.Attach(function(){This.Close();});
    m_FileBrowser.OnFileItemDblClick.Attach(
		function()
		{
			var paths = m_FileBrowser.GetSelectedItemsPath();
			if (paths.length > 0)
			{
				m_FileName = paths[0];
				Module.Confirm(
					String.format("{0} 已存在，是否覆盖？", System.Path.GetFileName(m_FileName)), This,
					function()
					{
						m_Result = "OK";
						This.Close();
					}
				);
			}
		}
    );
	
	This.SetAcceptButton(m_BtnOK);
	This.SetCancelButton(m_BtnCancel);
    
    m_FileBrowser.Expand(
		function()
		{
			m_FileBrowser.SetCurrentPath(IsNull(config.InitPath,System.GetFullPath("Home")));
		},
		IsNull(config.Root,System.GetFullPath("Home"))
	);
}

Module.SaveFile=function(config,parent,completeCallback)
{
	if(config.Height == undefined && parent != null)
	{
		config.Height = parent.GetHeight() - 60;
	}
	
	var saveDlg=new SaveFileDialog(config);
	saveDlg.ShowDialog(
		parent,'center',0,0,
		function(wnd)
		{
			parent.Focus();
			if(wnd.GetResult()=="OK") completeCallback(wnd.GetFileName());
		}
	);
	saveDlg.Focus();
};

(function(){
	
function FolderBrowserDataSource(roots)
{
	var rootNodes=[];
	var nodeIndex={};
	for(var i=0;i<roots.length;i++)
	{
		var root=roots[i];
		var dir=System.Path.GetDirectoryName(root.Path);
		var name=System.Path.GetFileName(root.Path);
		var node={
			Name:IsNull(root.Name,name),
			Parent:dir,
			Path:root.Path,
			Text:IsNull(root.Text,name)
		};
		rootNodes.push(node);
		nodeIndex[name]=node;
	}
	
	this.GetSubNodes=function(callback,item)
	{
		try
		{
			var nodes=null;
			if(item==null)
			{
				nodes=[];
				for(var i in rootNodes)
				{
					var item=rootNodes[i];
					nodes.push(
						{
							Name:item.Name,
							Text:item.Text,
							Tag:{
								Name:item.Name,
								FullName:item.Path
							},
							ImageCss:"Image16_Folder",
							HasChildren:item.HasChildren
						}
					);
				}
				callback(nodes);
			}
			else
			{
				IO.Directory.GetSubDirectories(
					function(dirs)
					{
						nodes=[];
						for(var i in dirs)
						{
							nodes.push(
								{
									Name: dirs[i].Name,
									Text: dirs[i].Name,
									Tag: dirs[i],
									ImageCss: dirs[i].Type == "D" ? "Image16_Folder" : "Image16_Zip"
								}
							)
						}
						callback(nodes);
					},
					function(error)
					{
						callback(null,error);
					},
					item.GetTag().FullName
				);
			}
		}
		catch(ex)
		{
			callback(null,new Exception(ex.name,ex.message));
		}
	}
}

Module.FolderBrowserDataSource=FolderBrowserDataSource;

/*
config={
    ...:继承TreeView(不需设置DataSource,HasImage)
    Root:
    InitPath:
}
*/

function FolderBrowser(config)
{   
    var root=IsNull(config.Root,"/"+System.GetUser());
    if(config.Roots==undefined) config.Roots=[{Path:System.GetFullPath("Home")}];
    var dataSource=new FolderBrowserDataSource(config.Roots);
    config.DataSource=dataSource;
    config.HasImage=true;
    
    var This=this;
        
    TreeView.call(This,config);

    var Base={
		Select:This.Select,
		Expand:This.Expand,
        GetType:This.GetType,
        is:This.is
    }
    
    This.is=function(type){return type==This.GetType()?true:Base.is(type);}
    This.GetType=function(){return "FolderBrowser";}
	
	function MapTreePath(path)
	{
		var ps=[];
		for(var i = 0;i<config.Roots.length;i++)
		{
			var root = config.Roots[i];
			var rname=IsNull(root.Name,System.Path.GetFileName(root.Path));
			var relPath=System.Path.GetRelativePath(root.Path,path);
			if(relPath!=null)
			{
				var treePath = relPath=="" ? ("/"+rname):("/"+rname+"/"+relPath);
				ps.push(treePath);
			}
		}
		return ps;
	}
		
	This.OnRefresh=new Delegate();
	
	This.Select=function(callback,path)
	{
		var treePaths=MapTreePath(path);
		if(treePaths.length>0)
		{
			Base.Select(callback,treePaths[0]);
		}
		else
		{
			callback(null);
		}
	}
	
	This.Expand=function(callback,path)
	{
		var treePaths=MapTreePath(path);
		if(treePaths.length>0)
		{
			Base.Expand(callback,treePaths[0]);
		}
		else
		{
			callback(null);
		}
	}
	
	function RefreshOne(paths,index,callback)
	{
		if(index<paths.length)
		{
			var treePath=paths[index];
			var node=This.GetExistingNode(treePath);
			if(node!=null)
			{
				node.Refresh(
					function()
					{
						RefreshOne(paths,index+1,callback);
					}
				);
			}
		}
		else
		{
			callback();
		}
	}
	
    function Refresh(path,infos)
	{
		try
		{
			var paths=MapTreePath(path);
			if(This.GetSelectedNode()==null) return;
			var current=This.GetSelectedNode().GetFullPath();
			if(paths.length>0)
			{
				RefreshOne(
					paths,0,
					function()
					{
						Base.Select(
							function(selectedNode)
							{
								if(selectedNode==null)
								{
									Base.Select(
										function(n)
										{
											This.OnRefresh.Call(n,path);
										},
										paths[0]
									);
								}
								else
								{
									This.OnRefresh.Call(selectedNode,path);
								}
							},
							current
						);
					}
				);
			}
		}
		catch(ex)
		{
		}
	}
	
    IO.FileSystem.OnRefresh.Attach(Refresh);
    
    This.OnDispose.Attach(
		function()
		{
			IO.FileSystem.OnRefresh.Detach(Refresh);
		}
    );
    
    if(config.OnBeginRequest!=undefined) This.OnBeginRequest.Attach(config.OnBeginRequest);
    if(config.OnEndRequest!=undefined) This.OnEndRequest.Attach(config.OnEndRequest);
}

Module.FolderBrowser=FolderBrowser;

/*
config=
{
	...:继承Window
	Desription:
	Root,
	InitPath
}
*/
function FolderBrowserDialog(config)
{
    var This=this;
    config.ClientCss='folderBrowserDialog';
    
    Window.call(This,config);
    
    var Base={
        GetType:This.GetType,
        is:This.is
    }
    
    This.is=function(type){return type==This.GetType()?true:Base.is(type);}
    This.GetType=function(){return "FolderBrowserDialog";}
        
    var m_TitlePanel=new Control(
		{
			Left:8,Top:8,
			Width:This.GetClientWidth()-8*2,
			Height:30,
			Parent:This,
			AnchorStyle:AnchorStyle.Left | AnchorStyle.Right,
			BorderWidth:0,
			Css:"description"
		}
    );
    
    m_TitlePanel.GetDom().innerHTML=IsNull(config.Desription,"请选择一个文件夹:");
    
    var m_Root=IsNull(config.Root,System.GetFullPath("Home"));
    
    var m_FolderBrowser=new FolderBrowser(
        {
            Left:8,
            Top:8+30,
            Width:This.GetClientWidth()-8*2,
            Height:This.GetClientHeight()-8*2-30-Button.Height-4,
	        Parent:This,
	        AnchorStyle:AnchorStyle.All,
	        BorderWidth:1,
	        Roots:[{Path:m_Root}],
	        InitPath:IsNull(config.InitPath,null),
	        OnBeginRequest:function()
			{
				This.Waiting("正在读取目录...");
			},
			OnEndRequest:function()
			{
				This.Completed();
			}
        }
    );
    
    var m_BtnOK=new Button(
		{
			Left:This.GetClientWidth()-64-8-64-8,
			Top:This.GetClientHeight()-8-Button.Height,
			Width:64,
			Height:Button.Height,
			Parent:This,
			AnchorStyle:AnchorStyle.Bottom | AnchorStyle.Right,
			Css:"button_default",
			Text:"确 定"
		}
    );
    
    var m_BtnCancel=new Button(
		{
			Left:This.GetClientWidth()-64-8,
			Top:This.GetClientHeight()-8-Button.Height,
			Width:64,
			Height:Button.Height,
			Parent:This,
			AnchorStyle:AnchorStyle.Bottom | AnchorStyle.Right,
			Text:"取 消"
		}
    );
    
    m_BtnOK.OnClick.Attach(
		function()
		{
			This.Close();
			This.OnSelected.Call(This);
		}
	);
    
    m_BtnCancel.OnClick.Attach(
		function()
		{
			This.Close();
		}
	);
	
	This.OnSelected=new Delegate();
	
	This.GetSelectedFolderPath=function()
	{
        var selectedNode=m_FolderBrowser.GetSelectedNode();
        return selectedNode==null?null:selectedNode.GetTag().FullName;
	}
	
	This.Select=function(callback,path)
	{
		m_FolderBrowser.Select(callback,path);
	}
	
	This.Expand=function(callback,path)
	{
		m_FolderBrowser.Expand(callback,path);
	}
	
	This.SetAcceptButton(m_BtnOK);
	This.SetCancelButton(m_BtnCancel);
    
    m_FolderBrowser.Refresh(
		function()
		{
			This.Expand(
				function()
				{
					var initPath=IsNull(config.InitPath,m_Root);
					This.Select(
						function()
						{
						},
						initPath
					);
				},
				m_Root
			);
		}
	);
}

Module.FolderBrowserDialog=FolderBrowserDialog;

})();

/*
config={
	Information:
	DefaultValue:
}
*/
function PromptDialog(config)
{
	var wndConfig={
		Left:0,Top:0,Width:450,Height:140,
		BorderWidth:6,Css:"window",
		HasMinButton:false,Resizable:false,
		Title:{Height:18,InnerHTML:"提示"},
		ClientCss:'promtpDialog'
	}
	
    var This=this;
    
    Window.call(This,wndConfig);
    
    var Base={
        GetType:This.GetType,
        is:This.is,
		Focus:This.Focus
    }
    
    This.is=function(type){return type==This.GetType()?true:Base.is(type);}
    This.GetType=function(){return "PromptDialog";}
    
    var m_Padding=12;
    
    var m_LabelInfo=new Label(
		{
			Left:m_Padding,Top:m_Padding,Width:This.GetClientWidth()-m_Padding*2-64-8,Height:Button.Height*2+8,
			AnchorStyle:AnchorStyle.Left | AnchorStyle.Right,
			Text:IsNull(config.Tip,""),
			Parent:This
		}
    );
    
    var m_BtnOK=new Button(
		{
			Left:This.GetClientWidth()-m_Padding-64,Top:m_Padding,Width:64,Height:Button.Height,
			AnchorStyle:AnchorStyle.Top | AnchorStyle.Right,
			Text:"确 定",
			Css:"button_default",
			Parent:This
		}
    );
    
    var m_BtnCancel=new Button(
		{
			Left:This.GetClientWidth()-m_Padding-64,Top:m_Padding+Button.Height+4,Width:64,Height:Button.Height,
			AnchorStyle:AnchorStyle.Top | AnchorStyle.Right,
			Text:"取 消",
			Parent:This
		}
    );
    
    var m_EditPrompt=new TextBox(
		{
			Left:m_Padding,Top:This.GetClientHeight()-m_Padding-22,Width:This.GetClientWidth()-m_Padding*2,Height:22,
			AnchorStyle:AnchorStyle.Left | AnchorStyle.Right | AnchorStyle.Bottom,
			Text:IsNull(config.DefaultValue,""),
			Parent:This
		}
    );
    
    var m_Result=null;
    
    m_BtnOK.OnClick.Attach(
		function()
		{
			m_Result=m_EditPrompt.GetText();
			This.Close();
		}
    );
    
    m_BtnCancel.OnClick.Attach(
		function()
		{
			m_Result=null;
			This.Close();
		}
    );
    
    This.GetResult=function()
    {
		return m_Result;
    }
    
    This.Focus=function()
    {
		m_EditPrompt.Focus();
    }
	
	This.SetAcceptButton(m_BtnOK);
	This.SetCancelButton(m_BtnCancel);
}

Module.Prompt=function(tip,def,parent,completeCallback)
{
	var promptDlg=new PromptDialog({Tip:tip,DefaultValue:def});
	promptDlg.ShowDialog(
		parent,'center',0,-20,
		function(wnd)
		{
			if(parent!=undefined && parent!=null) parent.Focus();
			completeCallback(wnd.GetResult());
		}
	);
	promptDlg.Focus();
}

function ConfirmDialog(config)
{
	var wndConfig={
		Left:0,Top:0,Width:360,Height:140,
		BorderWidth:6,Css:"window",
		HasMinButton:false,Resizable:false,
		Title:{Height:18,InnerHTML:"消息"}
	}
	
    var This=this;
    
    Window.call(This,wndConfig);
    
    var Base={
        GetType:This.GetType,
        is:This.is
    }
    
    This.is=function(type){return type==This.GetType()?true:Base.is(type);}
    This.GetType=function(){return "ConfirmDialog";}
    
    var m_LabelInfo=new Label(
		{
			Left:8,Top:8,Width:This.GetClientWidth()-8*2,Height:This.GetClientHeight()-8*2-Button.Height-8,
			AnchorStyle:AnchorStyle.All,
			Text:IsNull(config.Tip,""),
			Parent:This
		}
    );
    
    var m_BtnOK=new Button(
		{
			Left:This.GetClientWidth()-8-64-8-64,Top:This.GetClientHeight()-8-Button.Height,Width:64,Height:Button.Height,
			AnchorStyle:AnchorStyle.Bottom | AnchorStyle.Right,
			Text:"确 定",
			Css:"button_default",
			Parent:This
		}
    );
    
    var m_BtnCancel=new Button(
		{
			Left:This.GetClientWidth()-8-64,Top:This.GetClientHeight()-8-Button.Height,Width:64,Height:Button.Height,
			AnchorStyle:AnchorStyle.Bottom | AnchorStyle.Right,
			Text:"取 消",
			Parent:This
		}
    );
    
    var m_Result=null;
    This.GetResult=function()
    {
		return m_Result;
    }
    
    m_BtnOK.OnClick.Attach(
		function()
		{
			m_Result="OK";
			This.Close();
		}
	);
    
    m_BtnCancel.OnClick.Attach(
		function()
		{
			m_Result="None";
			This.Close();
		}
	);
	
	This.SetAcceptButton(m_BtnOK);
	This.SetCancelButton(m_BtnCancel);
}

Module.Confirm=function(tip,parent,completeCallback,cancelCallback)
{
	var confirmDlg=new ConfirmDialog({Tip:tip});
	confirmDlg.ShowDialog(
		parent,'center',0,-20,
		function(wnd)
		{
			if(parent!=undefined && parent!=null) parent.Focus();
			if(wnd.GetResult()=="OK")
			{
				if(completeCallback!=undefined) completeCallback();
			}
			else
			{
				if(cancelCallback!=undefined) cancelCallback();
			}
		}
	);
	confirmDlg.Focus();
};

function AlertDialog(config)
{
	var wndConfig={
		Left:0,Top:0,Width:360,Height:120,
		BorderWidth:6,Css:"window",
		HasMinButton:false,Resizable:false,
		Title:{Height:18,InnerHTML:"消息"}
	}
	
    var This=this;
    
    Window.call(This,wndConfig);
    
    var Base={
        GetType:This.GetType,
        is:This.is
    }
    
    This.is=function(type){return type==This.GetType()?true:Base.is(type);}
    This.GetType=function(){return "AlertDialog";}
    
    var m_LabelInfo=new Label(
		{
			Left:8,Top:8,Width:This.GetClientWidth()-8*2,Height:This.GetClientHeight()-8*2-Button.Height-8,
			AnchorStyle:AnchorStyle.Left | AnchorStyle.Right,
			Text:IsNull(config.Tip,""),
			Parent:This
		}
    );
    
    var m_BtnOK=new Button(
		{
			Left:This.GetClientWidth()-8-64,Top:This.GetClientHeight()-8-Button.Height,Width:64,Height:Button.Height,
			AnchorStyle:AnchorStyle.Bottom | AnchorStyle.Right,
			Text:"确 定",
			Css:"button_default",
			Parent:This
		}
    );
    
    m_BtnOK.OnClick.Attach(
		function()
		{
			This.Close();
		}
	);
	
	This.SetAcceptButton(m_BtnOK);
	This.SetCancelButton(m_BtnOK);
}

Module.Alert=function(tip,parent,completeCallback)
{
	var alertDlg=new AlertDialog({Tip:tip});
	alertDlg.ShowDialog(
		parent,'center',0,-20,
		function(wnd)
		{
			parent.Focus();
			if(completeCallback!=undefined) completeCallback();
		}
	);
	alertDlg.Focus();
};

function UploadDialog(path)
{
	var wndConfig={
		Left:0,Top:0,Width:400,Height:200,
		BorderWidth:6,Css:"window",
		Resizable:false,HasMinButton:false,
		Title:{InnerHTML:"上传文件"}
	}
	
    var This=this;
    
    Window.call(This,wndConfig);
    
    var Base={
        GetType:This.GetType,
        is:This.is
    }
    
    This.is=function(type){return type==This.GetType()?true:Base.is(type);}
    This.GetType=function(){return "UploadForm";}
    
    var m_VGuide=new Controls.GuideLine(This.GetClientHeight(),[16,26,12,22,0,12,Controls.Button.Height,8]);
    var m_HGuide1=new Controls.GuideLine(This.GetClientWidth(),[8,50,0,8]);
    var m_HGuide2=new Controls.GuideLine(This.GetClientWidth(),[8,0,100,8,64,8]);
    
    var m_Label1=new Controls.Label(
		{
			Left:m_HGuide1.Get(0),Top:m_VGuide.Get(0)+(m_VGuide.GetWidth(1)-12)/2,Width:m_HGuide1.GetWidth(1),Height:12,
			AnchorStyle:Controls.AnchorStyle.Left | Controls.AnchorStyle.Top,
			Parent:This,
			Text:"源文件:"
		}
    );
    
    var m_Frame=new Controls.Frame(
		{
			Left:m_HGuide1.Get(1),Top:m_VGuide.Get(0),Width:m_HGuide1.GetWidth(2),Height:m_VGuide.GetWidth(1),
			AnchorStyle:Controls.AnchorStyle.Left | Controls.AnchorStyle.Right | Controls.AnchorStyle.Buttom,
			Parent:This,
			BorderWidth:0
		}
    );
    
    var m_LabelTip=new Controls.Label(
		{
			Left:m_HGuide1.Get(0),Top:m_VGuide.Get(2)+(m_VGuide.GetWidth(3)-12)/2,Width:m_HGuide1.GetWidth(1),Height:12,
			AnchorStyle:Controls.AnchorStyle.Left | Controls.AnchorStyle.Top,
			Parent:This,
			Text:"上传到:"
		}
    );
    
    var m_EditPath=new Controls.TextBox(
		{
			Left:m_HGuide1.Get(1),Top:m_VGuide.Get(2),Width:m_HGuide1.GetWidth(2),Height:m_VGuide.GetWidth(3),
			AnchorStyle:Controls.AnchorStyle.Left | Controls.AnchorStyle.Right | Controls.AnchorStyle.Buttom,
			Parent:This,
			BorderWidth:1,
			Text:path
		}
    );
    
    var m_BtnUpload=new Controls.Button(
		{
			Left:m_HGuide2.Get(3),
			Top:m_VGuide.Get(5),
			Width:m_HGuide2.GetWidth(4),
			Height:m_VGuide.GetWidth(6),
			AnchorStyle:Controls.AnchorStyle.Bottom | Controls.AnchorStyle.Right,
			Parent:This,
			BorderWidth:0,Css:"button_default",
			Text:"上 传"
		}
    );
    
    var m_BtnUploadAndDecompress=new Controls.Button(
		{
			Left:m_HGuide2.Get(1),
			Top:m_VGuide.Get(5),
			Width:m_HGuide2.GetWidth(2),
			Height:m_VGuide.GetWidth(6),
			AnchorStyle:Controls.AnchorStyle.Bottom | Controls.AnchorStyle.Right,
			Parent:This,
			BorderWidth:0,
			Text:"上传并解压"
		}
    );
    
    m_BtnUpload.OnClick.Attach(
		function()
		{
			This.Waiting("正在上传文件...");
			m_Frame.GetFrame().contentWindow.Upload(m_EditPath.GetText());
		}
    );
    
    m_BtnUploadAndDecompress.OnClick.Attach(
		function()
		{			
			This.Waiting("正在上传文件...");
			m_Frame.GetFrame().contentWindow.Upload(m_EditPath.GetText(),true);
		}
    );
    
    System.AttachEvent(
		m_Frame.GetFrame(),
		"load",
		function()
		{
			m_Frame.GetWindow().ShowMessage=function(msg)
			{
				This.Completed();
				Module.Alert(msg,This);
			}
			
			This.Completed();
			
			var errorMsg=m_Frame.GetWindow().GetErrorMsg();
			if(errorMsg!="")
			{
				Module.Alert(errorMsg,This);
			}
		}
    );
    
	This.Waiting();
    m_Frame.GetFrame().src='Upload.aspx';
    m_Frame.GetFrame().style.overflow='hidden';
    m_Frame.GetFrame().style.padding='0px';
    m_Frame.GetFrame().allowTransparency="true";
    
    This.SetAcceptButton(m_BtnUpload);
}

Module.Upload=function(path,parent,completeCallback)
{
	var uploadDlg=new UploadDialog(path);
	uploadDlg.ShowDialog(
		parent,'center',0,-20,
		function(wnd)
		{
			parent.Focus();
			if(completeCallback!=undefined) completeCallback();
		}
	);
	uploadDlg.Focus();
}

var ThumbnailImageCache={};
		
function ImageBrowser(config)
{ 
	var This=this;
	var browser=this;
	if(config.Css==undefined) config.Css='imageBrowser';
	var m_Root=IsNull(config.Root,String.format("/{0}/Home",System.GetUser()));
        
	Control.call(This,config);

	var Base={
		GetType:This.GetType,
		is:This.is
	}
    
	This.is=function(type){return type==This.GetType()?true:Base.is(type);}
	This.GetType=function(){return "ImageBrowser";}	
	
	This.OnClick=new Delegate();
	This.OnDblClick=new Delegate();
	
	var m_ImagePath=String.format("/{0}/Public/Images",System.GetUser());
    
    var toolbar=new Controls.Toolbar(
		{
            Left:0,Top:0,Width:This.GetClientWidth(),Height:Controls.Toolbar.PredefineHeight,
            AnchorStyle:AnchorStyle.Left | AnchorStyle.Right,
            Parent:This,
            Css:"toolbar",
            Items:[
				{Css:"Image22_Refresh",Text:"刷新",Command:"Refresh"},
				{Css:"Image22_MoveTo",Text:"移动到",Command:"MoveTo"},
				{Css:"Image22_CopyTo",Text:"复制到",Command:"CopyTo"},
				{Css:"Image22_Delete",Text:"删除",Command:"Delete"},
				{Css:"Image22_Upload",Text:"上传",Command:"Upload"}
            ]
		}
    );
	
	var m_FolderTree=new Module.FolderBrowser(
		{
			Left:0,Top:Controls.Toolbar.PredefineHeight+1,
			Width:200,Height:This.GetClientHeight()-Controls.Toolbar.PredefineHeight-1,
			Parent:This,
			AnchorStyle:AnchorStyle.Top|AnchorStyle.Bottom,
			Refresh:false,
			BorderWidth:1,Css:'imageBrowser_Tree',
			Roots:[
				{Path:m_ImagePath,Text:"共享图片",Name:"PublicImages"},
				{Path:System.GetFullPath("Share"),Text:"群共享"},
				{Path:m_Root,Text:"主文件夹"}
			],
			OnBeginRequest:function()
			{
				This.GetTopContainer().Waiting("正在读取目录...");
			},
			OnEndRequest:function()
			{
				This.GetTopContainer().Completed();
			}
		}
	);
	var m_ImageBrowserPanel=new ImageBrowserPanel(
		{
			Left:206,Top:Controls.Toolbar.PredefineHeight+1,
			Width:This.GetClientWidth()-206,Height:This.GetClientHeight()-Controls.Toolbar.PredefineHeight-1,
			Parent:This,
			AnchorStyle:AnchorStyle.All,
			BorderWidth:1,Css:'imageBrowserPanel',
			OnBeginRequest:function()
			{
				This.GetTopContainer().Waiting("正在读取目录...");
			},
			OnEndRequest:function()
			{
				This.GetTopContainer().Completed();
			}
		}
	);
	var m_Split=new Controls.VerticalSplit(
		{
			Left:200,Top:Controls.Toolbar.PredefineHeight+1,
			Width:6,Height:This.GetClientHeight()-Controls.Toolbar.PredefineHeight-1,
			Parent:This,
			AnchorStyle:AnchorStyle.Top|AnchorStyle.Bottom,
			LeftControl:m_FolderTree,RightControl:m_ImageBrowserPanel
		}
	);

	m_FolderTree.OnClick.Attach(
		function(node)
		{
			m_ImageBrowserPanel.Load(function(){},node.GetTag().FullName);
		}
	);
    
    function OnCommand(command)
    {
        switch(command)
        {
        case "Refresh":
			{
				m_ImageBrowserPanel.Load(function(){},m_Current,false,false);
				break;
			}
        case "Upload":
			{
				Module.Upload(m_Current,This.GetTopContainer(),function(){m_ImageBrowserPanel.Load(function(){},m_Current,false,false);});
				break;
			}
        case "Rename":
			{
				var items=listview.GetSelectedItems();
				if(items.length>0)
				{
					var item=items[0];
					Module.Prompt(
						String.format('请输入"{0}"的新名称:',item.GetFileInfo("Name")),
						item.GetFileInfo("Name"),
						This.GetTopContainer(),
						function(name)
						{
							if(name!=null && name!="")
							{
								BeginRequest();
								File.Rename(
									function()
									{
										EndRequest();
									},
									function(msg)
									{
										System.HandleException(msg);
										EndRequest();
									},
									current+"/"+item.GetFileInfo("Name"),
									name
								)
							}
						}
					);
				}
				break;
			}
        case "Delete":
			{
				var items=m_ImageBrowserPanel.GetSelectedItems();
				
				if(items.length>0)
				{
					var files=[];
					for(var i in items)
					{
						var item=items[i];
						files.push(System.GetFullPath(item.GetImageInfo().Path));
					}
					Module.Confirm(
						"您确定要删除选中的项目吗？",This.GetTopContainer(),
						function()
						{
							This.GetTopContainer().Waiting("正在复制文件...");
							Directory.DeleteItems(
								function()
								{
									This.GetTopContainer().Completed();
								},
								function(msg)
								{
									System.HandleException(msg);
									This.GetTopContainer().Completed();
								},
								files
							)
						}
					);
				}
				break;
			}
        case "MoveTo":
			{
				var items=m_ImageBrowserPanel.GetSelectedItems();
				if(items.length>0)
				{
					var folderBrowser=new Module.FolderBrowserDialog(
						{
							Left:0,Top:0,Width:400,Height:400,
							Css:'window',
							BorderWidth:6,
							Resizable:true,
							HasMinButton:false,
							Title:{
								Height:18,
								InnerHTML:'文件夹浏览'
							},
							Desription:"请选择要移动到的文件夹:",
							Root:System.GetFullPath("Home")
						}
					);
					folderBrowser.OnSelected.Attach(
						function(fb)
						{
							var path=fb.GetSelectedFolderPath();
							if(path!=null)
							{
								var files=[];
								for(var i in items)
								{
									var item=items[i];
									files.push(System.GetFullPath(item.GetImageInfo().Path));
								}
								
								This.GetTopContainer().Waiting("正在移动文件...");
								
								File.Move(
									function()
									{
										This.GetTopContainer().Completed();
									},
									function(msg)
									{
										alert(msg);
										This.GetTopContainer().Completed();
									},
									files,
									path
								);
							}
						}
					);
					folderBrowser.ShowDialog(This.GetTopContainer(),'center',0,0);
					folderBrowser.Focus();
				}
				break;
            }
        case "CopyTo":
			{
				var items=m_ImageBrowserPanel.GetSelectedItems();
				if(items.length>0)
				{
					var folderBrowser=new Module.FolderBrowserDialog(
						{
							Left:0,Top:0,Width:400,Height:400,
							Css:'window',
							BorderWidth:6,
							Resizable:true,
							HasMinButton:false,
							Title:{
								Height:18,
								InnerHTML:'文件夹浏览'
							},
							Desription:"请选择要复制到的文件夹:",
							Root:System.GetFullPath("Home")
						}
					);
					folderBrowser.OnSelected.Attach(
						function(fb)
						{
							var path=fb.GetSelectedFolderPath();
							if(path!=null)
							{
								var files=[];
								for(var i in items)
								{
									var item=items[i];
									files.push(System.GetFullPath(item.GetImageInfo().Path));
								}
								
								This.GetTopContainer().Waiting("正在复制文件...");
								
								File.Copy(
									function()
									{
										This.GetTopContainer().Completed();
									},
									function(msg)
									{
										alert(msg);
										This.GetTopContainer().Completed();
									},
									files,
									path
								);
							}
						}
					);
					folderBrowser.ShowDialog(This.GetTopContainer(),'center',0,0);
					folderBrowser.Focus();
				}
				break;
            }
        case "SelectAll":
			{
				m_ImageBrowserPanel.SelectAll();
				break;
			}
        }
    }
    
    toolbar.OnCommand.Attach(OnCommand);
	
	This.Select=function(callback,path)
	{
		m_FolderTree.Select(
			function(node)
			{
				if(node!=null) m_ImageBrowserPanel.Load(function(){callback(node)},node.GetTag().FullName);
				else callback(null);
			},
			path
		);
	}
	
	This.Expand=function(callback,path)
	{
		m_FolderTree.Expand(callback,path);
	}
	
	var m_ThumbInfo=null;
	
	This.GetAllImages=function()
	{
		return m_ThumbInfo.ThumbnailImageInfos;
	}
	
	m_FolderTree.OnRefresh.Attach(
		function(node,path)
		{			
			if(node.GetTag().FullName != m_Current || path == m_Current)
			{
				m_ImageBrowserPanel.Load(function(){},node.GetTag().FullName,false);
			}
		}
	);
	
	var m_Current="";
	
	function ImageBrowserPanel(panelConfig)
	{
		var panel=this;

		Control.call(panel,panelConfig);

		var Base={
			GetType:panel.GetType,
			is:panel.is
		}
	    
		panel.is=function(type){return type==panel.GetType()?true:Base.is(type);}
		panel.GetType = function() { return "ImageBrowser.ImageBrowserPanel"; }

		panel.GetDom().style.overflow = "auto";
		
		panel.Load=function(callback,dir,useCache,useDirCache)
		{
			if(useCache==undefined) useCache=true;
			if(useDirCache==undefined) useDirCache=true;
			if(useCache && ThumbnailImageCache[dir.toUpperCase()]!=undefined)
			{
				var info=ThumbnailImageCache[dir.toUpperCase()];
				m_ThumbInfo=info;
				info.ThumbnailImageInfos.sort(
					function(item1,item2)
					{
						if(item1.Name>item2.Name) return 1;
						if(item1.Name<item2.Name) return -1;
						return 0;
					}
				);
				for(var i =0;i<info.ThumbnailImageInfos.length;i++)
				{
					info.ThumbnailImageInfos[i].Index=i;
				}
				panel.ShowImages(info.ThumbnailImagePath,info.ThumbnailImageInfos,info.LastModifiedTime.getTime().toString());
				callback(true);
				m_Current=dir;
			}
			else
			{
				panelConfig.OnBeginRequest();
				//读取子项，以便触发刷新
				IO.Directory.GetSubItems(
					function()
					{
						Directory.CreateThumbnailImage(
							function(info)
							{
								m_ThumbInfo=info;
								ThumbnailImageCache[dir.toUpperCase()]=info;
								info.ThumbnailImageInfos.sort(
									function(item1,item2)
									{
										if(item1.Name>item2.Name) return 1;
										if(item1.Name<item2.Name) return -1;
										return 0;
									}
								);
								for(var i =0;i<info.ThumbnailImageInfos.length;i++)
								{
									info.ThumbnailImageInfos[i].Index=i;
								}
								panel.ShowImages(info.ThumbnailImagePath,info.ThumbnailImageInfos,info.LastModifiedTime.getTime().toString());
								callback(true);
								panelConfig.OnEndRequest();
								m_Current=dir;
							},
							function(error)
							{
								callback(false);
								panelConfig.OnEndRequest();
							},
							dir
						);	
					},
					function()
					{
						callback(false);
						panelConfig.OnEndRequest();
					},
					dir,
					useDirCache
				);
			}
		}
		
		panel.ShowImages=function(url,images,sid)
		{
			panel.GetDom().innerHTML="";
			m_ImagePanels = [];
			for(var i in images)
			{
				var img = new ImagePanel(url,images[i],sid);
				m_ImagePanels.push(img);
			}
		}
    
		panel.ClearSelect=function()
		{
			for(var i in m_ImagePanels)
			{
				if(m_ImagePanels[i].IsSelected()) m_ImagePanels[i].Deselect();
			}
		}
	    
		panel.IndexOf=function(item)
		{
			for(var i=0;i<m_ImagePanels.length;i++)
			{
				if(m_ImagePanels[i]==item) return i;
			}
			return -1;
		}
    
		panel.SelectRange=function(start,end)
		{		
			if(start>end){var temp=start;start=end;end=temp;}
			
			for(var i=start;i<=end;i++)
			{
				m_ImagePanels[i].Select();
			}
		}
    
		panel.SelectAll=function(start,end)
		{		
			for(var i=0;i<=m_ImagePanels.length;i++)
			{
				m_ImagePanels[i].Select();
			}
		}
	    
		panel.GetSelectedItems=function()
		{
			var items=[];
			for(var i in m_ImagePanels)
			{
				if(m_ImagePanels[i].IsSelected()) items.push(m_ImagePanels[i]);
			}
			return items;
		}
        
        panel.GetDom().onmousedown=function(evt)
        {
			if(evt==undefined) evt=event;
			var target
			if(evt.target!=undefined) target=evt.target;
			if(evt.srcElement!=undefined) target=evt.srcElement;
			if(target==this)
			{
				panel.ClearSelect();
			}
        }
			
		var m_ImagePanels=[];
		var _latestItem=null;
		
		function ImagePanel(url,info,sid)
		{
			var This=this;
			
			var dom=document.createElement("DIV");
			dom.innerHTML="<div class='imagePanel_image'></div><div class='imagePanel_text'><div>"
			dom.firstChild.style.background=String.format(
				"url({0}) no-repeat {1}px {2}px",
				sid==undefined?System.GetUrl(url):System.GetUrl(url)+"?"+sid,
				-info.Position.Left,-info.Position.Top
			);
			dom.childNodes[1].innerHTML=info.Name;
			dom.className='imagePanel';
			panel.GetDom().appendChild(dom);
			dom.ondblclick=function()
			{
				browser.OnDblClick.Call(System.GetFullPath(info.Path),info);
			}
			
			var m_IsSelected=false;
			
			This.GetImageInfo=function()
			{
				return info;
			}
			
			This.Select=function()
			{
				m_IsSelected=true;
				dom.firstChild.className="imagePanel_image_select";
			}
			
			This.Deselect=function()
			{
				m_IsSelected=false;
				dom.firstChild.className="imagePanel_image";
			}
        
			This.IsSelected=function()
			{
				return m_IsSelected;
			}
        
			dom.firstChild.onclick=function(evt)
			{
				if(evt==undefined) evt=event;
				if(!evt.ctrlKey && !evt.shiftKey)
				{
					panel.ClearSelect();
					This.Select();
					_latestItem=This;
				}

				browser.OnClick.Call(System.GetFullPath(info.Path), info);
			}
	        
			dom.firstChild.onmousedown=function(evt)
			{
				if(evt==undefined) evt=event;

				if(GetButton(evt)=="Right")
				{
					if(!This.IsSelected())
					{
						panel.ClearSelect();
						This.Select();
					}
					_latestItem=This;
				}
				else if(GetButton(evt)=="Left")
				{
					if(evt.ctrlKey)
					{
						if(evt.shiftKey)
						{
							if(_latestItem!=null)
							{
								panel.SelectRange(panel.IndexOf(This),panel.IndexOf(_latestItem));
							}
							_latestItem=This;
						}
						else
						{
							if(This.IsSelected()) 
							{
								This.Deselect();
								_latestItem=null;
							}
							else 
							{
								This.Select();
								_latestItem=This;
							}
						}
					}
					else
					{
						if(evt.shiftKey)
						{
							if(_latestItem!=null)
							{
								panel.ClearSelect();
								panel.SelectRange(panel.IndexOf(This),panel.IndexOf(_latestItem));
							}
						}
					}
				}
			}
		}
	}
	
}

Module.ImageBrowser=ImageBrowser;

function GetButton(evt)
{
	if((evt.which!=undefined && evt.which==1) || evt.button==1)
		return "Left";
	else if((evt.which!=undefined && evt.which==3) || evt.button==2)
		return "Right"
}

function ImageBrowserDialog(config)
{
	var This=this;

	var winConfig = {
		Width: 730, Height: IsNull(config.Height,550), Left: 0, Top: 0,
		Css: 'window', BorderWidth: 6,
		Resizable: true, HasMinButton: false,
		Title: {
			Height: 18,
			InnerHTML: '打开图片'
		}
	}
	
	Window.call(this,winConfig);
	    
	var Base={
		GetType:this.GetType,
		is:this.is
	}
    
	this.is=function(type){return type==this.GetType()?true:Base.is(type);}
	this.GetType=function(){return "ImageBrowserDialog";}
	   
	var	m_ImageBrowser=new ImageBrowser(
		{
			Left:1,Top:1,Width:This.GetClientWidth()-2,Height:This.GetClientHeight()-2,
			Parent:This,
			AnchorStyle:AnchorStyle.All,
			EnableMultiSelect:true
		}
	);
	
	var m_SelectPath=null;
	This.GetSelectedPath=function(){return m_SelectPath;}
	
	This.Select=m_ImageBrowser.Select;
	This.Expand=m_ImageBrowser.Expand;
	This.SelectPublic=m_ImageBrowser.SelectPublic;
	
	m_ImageBrowser.OnClick.Attach(
		function(path)
		{
			m_SelectPath=path;
			This.Close();
		}
	);
	
	This.Select(
		function()
		{
			This.Expand(
				function()
				{
				},
				IsNull(config.InitPath,System.GetFullPath("Home"))
			);
		},
		IsNull(config.InitPath,System.GetFullPath("Home"))
	);
}

Module.ImageBrowserDialog=ImageBrowserDialog;

Module.OpenImage=function(config,parent,completeCallback,cancelCallback)
{
	if(config.Height == undefined && parent != null)
	{
		config.Height = parent.GetHeight() - 60;
	}
	var openDlg = new ImageBrowserDialog(config);
	openDlg.ShowDialog(
		parent,'center',0,0,
		function(wnd)
		{
			parent.Focus();
			var path=wnd.GetSelectedPath();
			if(path!=null)
			{
				completeCallback(path);
			}
			else
			{
				if(cancelCallback!=undefined) cancelCallback();
			}
		}
	);
	openDlg.Focus();
};