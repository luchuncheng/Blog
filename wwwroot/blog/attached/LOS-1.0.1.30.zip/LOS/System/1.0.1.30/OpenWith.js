﻿
var GUID='C28F54F6-D3BD-4C82-9B84-D0617E059F13';
var ConfigFileName=System.GetSpecialDirectory("Config")+"/"+GUID+".conf";
var Config=null;
var IsConfigChange=false;

var CommonDialog=null;
var Controls=null;
var IO=null;

var Window=null;
var Control=null;
var File=null;

function init(completeCallback,errorCallback)
{
	System.LoadModules(loadComplete,errorCallback,["Window.js","Controls.js","CommonDialog.js","IO.js"]);
	
	function loadComplete()
	{
		File=System.GetModule("IO.js").File;
		Window=System.GetModule("Window.js").Window;
		Control=System.GetModule("Controls.js").Control;
		
		CommonDialog=System.GetModule("CommonDialog.js");
		Controls=System.GetModule("Controls.js");
		IO=System.GetModule("IO.js");
		
		File.Open(openFileCallback,errorCallback,ConfigFileName,true);
	}
	
	function openFileCallback(configFile)
	{
		var configFileContent=configFile.Content;
		if(configFileContent!="")
		{
			Config = System.ParseJson(configFileContent)
		}
		else
		{
			Config={};
			Config.Applications={
				"文本编辑器":{
					Path:"Notepad/Notepad.js"
				},
				"图片查看器":{
					Path:"ImageBrowser.js"
				}
			}
			Config.Mappings={
				".txt":"Notepad/Notepad.js",
				".chm":"CHH/CHH.js",
				".html":"CHH/CHH.js",
				".htm":"CHH/CHH.js",
				".bmp":"ImageBrowser.js",
				".jpg":"ImageBrowser.js",
				".png":"ImageBrowser.js",
				".gif":"ImageBrowser.js",
				".jpeg":"ImageBrowser.js",
				".zip":"FileBrowser.js"
			}
		}
		completeCallback();
	}
}

function dispose(competeCallback,errorCallback)
{
	if(IsConfigChange)
	{
		var content=System.RenderJson(Config);
		
		File.Create(competeCallback,errorCallback,ConfigFileName,content);
	}
	else
	{
		competeCallback();
	}
}

function exists(objSelect, objItemValue) 
{        
	var isExit = false;
	for (var i = 0; i < objSelect.options.length; i++) 
	{
		if (objSelect.options[i].value == objItemValue) 
		{
			isExit = true;
			break;
		}
	}
	return isExit;
}
		
function openWith(path,fileName)
{
	System.Exec(function(){},alert,path,fileName);
}

function generateConfigFileContent(config)
{
	var builder=[];
	builder.push("({");
	builder.push("\r\n\tMappings:{");
	var count=0;
	for(var key in config.Mappings)
	{
		if(count>0) builder.push(",");
		builder.push(String.format("\r\n\t\t\"{0}\":\"{1}\"",key,config.Mappings[key]));
		count++;
	}
	builder.push("\r\n\t},");
	builder.push("\r\n\tApplications:{");
	count=0;
	for(var key in config.Applications)
	{
		var app=config.Applications[key];
		if(count>0) builder.push(",");
		builder.push(String.format('\r\n\t\t"{0}":{{Path:"{1}"}',key,app.Path));
		count++;
	}
	builder.push("\r\n\t}");
	builder.push("\r\n})");
	return builder.join("");
}

function addApps(objSelect,config)
{
	for(var key in config.Applications)
	{
		var app=config.Applications[key];
		var opt=new Option(key,app.Path);
		objSelect.options.add(opt);
	}
}

function Application()
{
	var This=this;
	var task=null;
	var mainForm=null;
	
	this.Start=function()
	{
		var baseUrl=arguments[0];
		var fileName=arguments[1];
		var showAlways=(arguments[2]==undefined?false:arguments[2]);
		
		if(fileName!=undefined)
		{
			var fileExt=IO.Path.GetFileExtension(fileName).toLowerCase();
			if(Config.Mappings[fileExt]==null || showAlways)
			{
				var mainForm=new OpenWithDialog(fileName);
				
				mainForm.MoveEx('center',0,-40);
				mainForm.Show(true);
				mainForm.Focus();
				mainForm.OnClosed.Attach(
					function(){This.Dispose();}
				);
				
			}
			else
			{
				This.Dispose();
				openWith(Config.Mappings[fileExt],fileName);
			}
		}
		else
		{
			This.Dispose();
		}
	}
	
	this.Terminate=function(completeCallback,errorCallback)
	{
		mainForm.Close();
		completeCallback();
	}
	
	function dispose()
	{
		if(Taskbar!=null) Taskbar.removeTask(task);
		This.Dispose();
	}
}


var OpenWithDataSource = {

	GetSubNodes: function(callback, node)
	{
		var nodes = null;
		if (node == null)
		{
			nodes = [{ Name: "所有程序", Text: "所有程序", Tag: null, ImageCss: "Image16_Folder"}];
			callback(nodes);
		}
		else
		{
			nodes = [];
			path = node.GetFullPath();
			if (path == "/所有程序")
			{
				for (var name in Config.Applications)
				{
					var app = Config.Applications[name];
					nodes.push({ Name: name, Text: name, Tag: { Path: app.Path }, ImageCss: "Image16_Application", HasChildren: false });
				}
			}
			callback(nodes);
		}
	}
};

function OpenWithDialog(filename)
{
	var wndConfig = {
		Left: 0, Top: 0, Width: 400, Height: 400,
		BorderWidth: 6, Css: "window",
		Resizable: false, HasMinButton: false,
		Title: { InnerHTML: "打开文件" }
	}
	
    var This=this;
    
    Window.call(This,wndConfig);
    
    var Base={
        GetType:This.GetType,
        is:This.is
    }
    
    This.is=function(type){return type==This.GetType()?true:Base.is(type);}
    This.GetType=function(){return "OpenWithDialog";}
    
    var m_LabelTip=new Controls.Label(
		{
			Left:8,Top:16,Width:This.GetClientWidth()-8-8,Height:12,
			AnchorStyle:Controls.AnchorStyle.Left | Controls.AnchorStyle.Right,
			Text:"选择您想要用来打开此文件的应用程序...",
			Parent:This
		}
    );
    
    var m_LabelFileName=new Controls.Label(
		{
			Left:8,Top:16+12+12,Width:This.GetClientWidth()-8-8,Height:12,
			AnchorStyle:Controls.AnchorStyle.Left | Controls.AnchorStyle.Right,
			Text:String.format("文件名: {0}",IO.Path.GetFileName(filename)),
			Parent:This
		}
    );
    
    var m_ProgramTree=new Controls.TreeView(
		{
			Left:8,Top:16+12+12+12+8,
			Width:This.GetClientWidth()-8-8,
			Height:This.GetClientHeight()-16-12-12-12-8-8-Controls.Button.Height-8,
			AnchorStyle:Controls.AnchorStyle.All,
			DataSource:OpenWithDataSource,
			BorderWidth:1,
			Parent:This
		}
    );

	var m_BtnOK=new Controls.Button(
		{
			Left:This.GetClientWidth()-64-8-64-8,
			Top:This.GetClientHeight()-Controls.Button.Height-8,
			//Left:This.GetClientWidth()-64-8-64-8-64-8,
			//Top:This.GetClientHeight()-Controls.Button.Height-8,
			Width:64,
			Height:Controls.Button.Height,
			AnchorStyle:Controls.AnchorStyle.Bottom | Controls.AnchorStyle.Right,
			Text:"打 开",
			Css:"button_default",
			Parent:This
		}
	);

	var m_BtnExec = new Controls.Button(
		{
			Left: This.GetClientWidth() - 64 - 8 - 64 - 8 - 64 - 8,
			Top: This.GetClientHeight() - Controls.Button.Height - 8,
			Width: 64,
			Height: Controls.Button.Height,
			AnchorStyle: Controls.AnchorStyle.Bottom | Controls.AnchorStyle.Right,
			Text: "运 行",
			Css: "button",
			Parent: This
		}
	);
	
	m_BtnExec.SetVisible(AllowExec);
	
	var m_BtnCancel=new Controls.Button(
		{
			Left:This.GetClientWidth()-64-8,
			Top:This.GetClientHeight()-Controls.Button.Height-8,
			Width:64,
			Height:Controls.Button.Height,
			AnchorStyle:Controls.AnchorStyle.Bottom | Controls.AnchorStyle.Right,
			Text:"取 消",
			Parent:This
		}
	);
	
	m_BtnOK.OnClick.Attach(
		function()
		{
			var node=m_ProgramTree.GetSelectedNode();
			if(node!=null)
			{
				var info=node.GetTag();
				if(info!=null)
				{
					openWith(info.Path,filename);
					This.Close();
				}
			}
		}
	);
	
	m_BtnExec.OnClick.Attach(
		function()
		{
			System.Exec(null,alert,filename);
			This.Close();
		}
	);
	
	
	m_BtnCancel.OnClick.Attach(
		function()
		{
			This.Close();
		}
	);

	This.SetAcceptButton(m_BtnOK);
	This.SetCancelButton(m_BtnCancel);
	
	m_ProgramTree.Expand(
		function(node,error)
		{
			if(node!=null)
			{
				m_ProgramTree.Select(
					function(node,error)
					{
					},
					"/所有程序"
				);
			}
		},
		"/所有程序"
	);
}