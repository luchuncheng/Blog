﻿
var Communication = null;
var MessageListener = null;
var SystemMessageCache = null;
var Window, Controls, IO;
var GUID = "951AABD2-4AAC-4382-A502-71A57FC7F90D";

var ConfigFilePath = System.GetSpecialDirectory("Config") + "/" + GUID + ".conf";
var Config = {};

function init(completeCallback, errorCallback)
{
    function LoadModulesComplete()
    {
        Communication = System.GetModule("Communication.js").Communication;
        MessageListener = System.GetModule("Communication.js").MessageListener;
        
        IO = System.GetModule("IO.js");
        
        System.RegisterCommandHandler("ManagementCommand",ManagementCommandHandler);

        //IO.File.Open(LoadConfigCompleted, errorCallback, ConfigFilePath, true, "utf-8");
        LoadConfigCompleted();
    }

    function LoadConfigCompleted(file)
    {
        /*var content = file.Content;
        if (content != "")
        {
            Config = System.ParseJson(content);
        }
        else
        {
            Config = {};
        }*/

        Config = {};
            
        System.OnLoad.Attach(
			function()
			{
			    SystemMessageCache = new MessageCacheCtor();
			    SystemMessageCache.Start();
			}
		);

        completeCallback();
    }
    System.LoadModules(
		LoadModulesComplete,
		errorCallback,
		["Communication.js", "IO.js"]
	);

}

function dispose(completeCallback, errorCallback)
{
    SystemMessageCache.Stop();
    //IO.File.Create(completeCallback, errorCallback, ConfigFilePath, System.RenderJson(Config), "utf-8");
    completeCallback();
}


function FormatNumber(num,length,radix)
{
	if(radix==undefined) radix=10;
	var s=num.toString(radix);
	var zero="";
	for(var i=0;i<length-s.length;i++) zero+="0";
	return zero+s;
}

function Management()
{
}

function FriendDataCahce_Ctor()
{
    var m_FriendInfo = null;
    var This = this;

    this.Refresh = function(callback, errorCallback)
    {
        var data = System.CreateServiceData(
			"ManagementService", "GetUserInfo", {Name: System.GetUser()}
		);
        System.SendCommand(
			function(ret)
			{
			    if (ret.Result == "OK")
			    {
			        m_FriendInfo = ret.Return.Friends;
			        callback(m_FriendInfo);
			    }
			    else
			        errorCallback(ret.Message);
			},
			function(error)
			{
			    errorCallback(error)
			},
			data
		)
    }

    this.IsEmpty = function()
    {
        return m_FriendInfo == null;
    }

    this.GetFriends = function()
    {
        return System.Clone(m_FriendInfo);
    }

    this.Reset = function(newInfo)
    {
        m_FriendInfo = newInfo;
        This.Notify();
    }

    this.Notify = function()
    {
        Management.OnChanged.Call("FriendInfo", System.Clone(m_FriendInfo));
    }
    
    this.Exists=function(name)
    {
		for(var i in m_FriendInfo)
		{
			if(m_FriendInfo[i].Name.toUpperCase()==name.toUpperCase())
			{
				return true;
			}
		}
		return false;
    }
}

var FriendDataCahce = new FriendDataCahce_Ctor();

Management.OnChanged = new Delegate();

Management.GetUserInfo = function(callback, errorCallback, user)
{
    var data = System.CreateServiceData(
		"ManagementService", "GetUserInfo", { Name:user }
	);

    System.SendCommand(
		function(ret)
		{
		    if (ret.Result == "OK")
		    {
		        callback(ret.Return);
		    }
		    else
		    {
		        errorCallback(ret.Return);
		    }
		},
		function(error)
		{
		    errorCallback(error)
		},
		data
	)
}

Management.CreateGroup = function(callback, errorCallback,name,nickname)
{
	var data = System.CreateServiceData(
		"ManagementService", "CreateGroup", { Name: name, Nickname: nickname }
	);

    System.SendCommand(
		function(ret)
		{
		    if (ret.Result == "OK")
		    {
		        callback(ret.Return);
		    }
		    else
		    {
		        errorCallback(ret.Return);
		    }
		},
		function(error)
		{
		    errorCallback(error)
		},
		data
	)
}

Management.UpdateInviteCode = function(callback, errorCallback,name)
{
	var data = System.CreateServiceData(
		"ManagementService", "UpdateInviteCode", { Name: (name == undefined ? System.GetUser() : name) }
	);

    System.SendCommand(
		function(ret)
		{
		    if (ret.Result == "OK")
		    {
		        callback(ret.Return);
		    }
		    else
		    {
		        errorCallback(ret.Return);
		    }
		},
		function(error)
		{
		    errorCallback(error)
		},
		data
	)
}

Management.ChangePassword = function(callback, errorCallback, password, newPassword)
{
    var data = System.CreateServiceData(
		"ManagementService", "ChangePassword", { PrePassword: password, NewPassword: newPassword }
	);

    System.SendCommand(
		function(ret)
		{
		    if (ret.Result == "OK")
		    {
		        callback()
		    }
		    else
		        errorCallback(ret.Message);
		},
		function(error)
		{
		    errorCallback(error)
		},
		data
	)
}

Management.SendAddFriendRequest = function(callback, errorCallback, peer, info)
{
	var data = System.CreateServiceData(
		"ManagementService", "SendAddFriendRequest", { Peer: peer, VerifyInfo:EncodeParam(info) }
	);

    System.SendCommand(
		function(ret)
		{
		    if (ret.Result == "OK")
		    {
		        callback()
		    }
		    else
		        errorCallback(ret.Message);
		},
		function(error)
		{
		    errorCallback(error)
		},
		data
	)
}

Management.GetFriends = function(callback, errorCallback)
{
    if (FriendDataCahce.IsEmpty())
    {
        FriendDataCahce.Refresh(callback, errorCallback);
    }
    else
    {
        callback(FriendDataCahce.GetFriends());
    }
}

function AddFriend(callback, errorCallback, peer, msgId)
{
    var data = System.CreateServiceData(
		"ManagementService", "AddFriend", { Peer: peer, MessageID: msgId }
	);

    System.SendCommand(
		function(ret)
		{
		    if (ret.Result == "OK")
		    {
		        FriendDataCahce.Reset(ret.Return);
		        callback()
		    }
		    else
		        errorCallback(ret.Message);
		},
		function(error)
		{
		    errorCallback(error)
		},
		data
	)
}

function AddToGroup(callback, errorCallback, peer, group, msgId)
{
    var data = System.CreateServiceData(
		"ManagementService", "AddToGroup", { Peer: peer, Group: group, MessageID: msgId }
	);

    System.SendCommand(
		function(ret)
		{
		    if (ret.Result == "OK")
		    {
		        FriendDataCahce.Reset(ret.Return);
		        callback()
		    }
		    else
		        errorCallback(ret.Message);
		},
		function(error)
		{
		    errorCallback(error)
		},
		data
	)
}

Management.RemoveFromGroup = function(callback, errorCallback, member, group)
{
    var data = System.CreateServiceData(
		"ManagementService", "RemoveFromGroup", { Member: member, Group: group}
	);

    System.SendCommand(
		function(ret)
		{
		    if (ret.Result == "OK")
		    {
		        callback()
		    }
		    else
		        errorCallback(ret.Message);
		},
		function(error)
		{
		    errorCallback(error)
		},
		data
	)
}

Management.DeleteFriend = function(callback, errorCallback, peer)
{
    var data = System.CreateServiceData(
		"ManagementService", "DeleteFriend", { Peer: peer }
	);

    System.SendCommand(
		function(ret)
		{
		    if (ret.Result == "OK")
		    {
		        FriendDataCahce.Reset(ret.Return);
		        callback()
		    }
		    else
		        errorCallback(ret.Message);
		},
		function(error)
		{
		    errorCallback(error)
		},
		data
	)
}

Management.DeleteGroup = function(callback, errorCallback, name)
{
    var data = System.CreateServiceData(
		"ManagementService", "DeleteGroup", { Name: name }
	);

    System.SendCommand(
		function(ret)
		{
		    if (ret.Result == "OK")
		    {
		        FriendDataCahce.Reset(ret.Return);
		        callback()
		    }
		    else
		        errorCallback(ret.Message);
		},
		function(error)
		{
		    errorCallback(error)
		},
		data
	)
}

Management.UpdateUserInfo = function(callback, errorCallback, name, values)
{
    var data = System.CreateServiceData(
		"ManagementService", "UpdateUserInfo", { Name: name, Values: System.RenderJson(values) }
	);

    System.SendCommand(
		function(ret)
		{
		    if (ret.Result == "OK")
		    {
		        callback(ret.Return);
		    }
		    else
		        errorCallback(ret.Message);
		},
		function(error)
		{
		    errorCallback(error)
		},
		data
	)
}

Module.Management = Management;

function EncodeParam(s)
{
	var newStr=s.replace(
		/[#,\x00-\x1F]/g,
		function(c)
		{
			var ascii=c.charCodeAt(0)
			return "#"+FormatNumber(ascii,4,16).toUpperCase();
		}
	);
	return newStr;
}

function DecodeParam(s)
{
	var newStr=s.replace(
		/#[0-9A-Z][0-9A-Z][0-9A-Z][0-9A-Z]/g,
		function(s)
		{
			var ascii=parseInt(s.substr(1,s.length-1),16);
			return String.fromCharCode(ascii);
		}
	);
	return newStr;
}

function GetParams(data)
{
	var ps=data.split(",");
	var res=[];
	for(var i in ps)
	{
		res.push(DecodeParam(ps[i]));
	}
	return res;
}

function GetCommand(msg)
{
    var params = msg.split(":");
    if (params.length >= 2)
    {
        return {
            Name: params[0],
            Data: params[1],
            Params:GetParams(params[1])
        }
    }
    else
        return null;
}

function AddFriendConfirmDialog(name,info, msg)
{
    var Button = Controls.Button;
    var Label = Controls.Label;
    var AnchorStyle = Controls.AnchorStyle;

    var wndConfig = {
        Left: 0, Top: 0, Width: 250, Height: 180,
        BorderWidth: 6, Css: "window",
        HasMinButton: false, Resizable: false,
        Title: { Height: 18, InnerHTML: "消息" },
        AnchorStyle: Controls.AnchorStyle.Right | Controls.AnchorStyle.Bottom
    }

    var This = this;

    Window.call(This, wndConfig);

    var Base = {
        GetType: This.GetType,
        is: This.is
    }

    This.is = function(type) { return type == This.GetType() ? true : Base.is(type); }
    This.GetType = function() { return "ConfirmDialog"; }

    var m_LabelInfo = new Controls.Label(
		{
		    Left: 8, Top: 8, Width: This.GetClientWidth() - 8 * 2, Height: This.GetClientHeight() - 8 * 2 - Button.Height - 8,
		    AnchorStyle: AnchorStyle.Left | AnchorStyle.Right,
		    Text: String.format("{0} 请求添加您为好友?<br/><br/>验证信息:<br/><br/>{1}", name,System.ReplaceHtml(info)),
		    Parent: This
		}
    );

    var m_BtnOK = new Button(
		{
		    Left: This.GetClientWidth() - 8 - 64 - 8 - 64, Top: This.GetClientHeight() - 8 - Button.Height, Width: 64, Height: Button.Height,
		    AnchorStyle: AnchorStyle.Bottom | AnchorStyle.Right,
		    Text: "同 意",
		    Css: "button_default",
		    Parent: This
		}
    );

    var m_BtnCancel = new Button(
		{
		    Left: This.GetClientWidth() - 8 - 64, Top: This.GetClientHeight() - 8 - Button.Height, Width: 64, Height: Button.Height,
		    AnchorStyle: AnchorStyle.Bottom | AnchorStyle.Right,
		    Text: "拒 绝",
		    Parent: This
		}
    );

    m_BtnOK.OnClick.Attach(
		function()
		{
		    AddFriend(
				function()
				{
				},
				System.HandleException,
				name,
				msg.ID
			);
		    This.Close();
		}
	);

    m_BtnCancel.OnClick.Attach(
		function()
		{
		    This.Close();
		}
	);

    This.SetAcceptButton(m_BtnOK);
    This.SetCancelButton(m_BtnCancel);
}

function AddToGroupConfirmDialog(guest,info, group, groupDesc, msgId)
{
    var Button = Controls.Button;
    var Label = Controls.Label;
    var AnchorStyle = Controls.AnchorStyle;

    var wndConfig = {
        Left: 0, Top: 0, Width: 250, Height: 180,
        BorderWidth: 6, Css: "window",
        HasMinButton: false, Resizable: false,
        Title: { Height: 18, InnerHTML: "消息" },
        AnchorStyle: Controls.AnchorStyle.Right | Controls.AnchorStyle.Bottom
    }

    var This = this;

    Window.call(This, wndConfig);

    var Base = {
        GetType: This.GetType,
        is: This.is
    }

    This.is = function(type) { return type == This.GetType() ? true : Base.is(type); }
    This.GetType = function() { return "ConfirmDialog"; }

    var m_LabelInfo = new Controls.Label(
		{
		    Left: 8, Top: 8, Width: This.GetClientWidth() - 8 * 2, Height: This.GetClientHeight() - 8 * 2 - Button.Height - 8,
		    AnchorStyle: AnchorStyle.Left | AnchorStyle.Right,
		    Text: String.format("\"{0}\"请求加入群\"{1}\"。<br/><br/>验证信息:<br/><br/>{2}", guest, groupDesc,info.replace(/</ig,function(){return "&lt;";})),
		    Parent: This
		}
    );

    var m_BtnOK = new Button(
		{
		    Left: This.GetClientWidth() - 8 - 64 - 8 - 64, Top: This.GetClientHeight() - 8 - Button.Height, Width: 64, Height: Button.Height,
		    AnchorStyle: AnchorStyle.Bottom | AnchorStyle.Right,
		    Text: "同 意",
		    Css: "button_default",
		    Parent: This
		}
    );

    var m_BtnCancel = new Button(
		{
		    Left: This.GetClientWidth() - 8 - 64, Top: This.GetClientHeight() - 8 - Button.Height, Width: 64, Height: Button.Height,
		    AnchorStyle: AnchorStyle.Bottom | AnchorStyle.Right,
		    Text: "拒 绝",
		    Parent: This
		}
    );

    m_BtnOK.OnClick.Attach(
		function()
		{
		    AddToGroup(
				function()
				{
				},
				System.HandleException,
				guest,
				group,
				msg.ID
			);
		    This.Close();
		}
	);

    m_BtnCancel.OnClick.Attach(
		function()
		{
		    This.Close();
		}
	);

    This.SetAcceptButton(m_BtnOK);
    This.SetCancelButton(m_BtnCancel);
}

function NotifyDialog(text, callback)
{
    var Button = Controls.Button;
    var Label = Controls.Label;
    var AnchorStyle = Controls.AnchorStyle;

    var wndConfig = {
        Left: 0, Top: 0, Width: 250, Height: 180,
        BorderWidth: 6, Css: "window",
        HasMinButton: false, Resizable: false,
        Title: { Height: 18, InnerHTML: "消息" },
        AnchorStyle: Controls.AnchorStyle.Right | Controls.AnchorStyle.Bottom
    }

    var This = this;

    Window.call(This, wndConfig);

    var Base = {
        GetType: This.GetType,
        is: This.is
    }

    This.is = function(type) { return type == This.GetType() ? true : Base.is(type); }
    This.GetType = function() { return "ConfirmDialog"; }

    var m_LabelInfo = new Controls.Label(
		{
		    Left: 8, Top: 8, Width: This.GetClientWidth() - 8 * 2, Height: This.GetClientHeight() - 8 * 2 - Button.Height - 8,
		    AnchorStyle: AnchorStyle.Left | AnchorStyle.Right,
		    Text: text,
		    Parent: This
		}
    );

    var m_BtnOK = new Button(
		{
		    Left: This.GetClientWidth() - 8 - 64, Top: This.GetClientHeight() - 8 - Button.Height, Width: 64, Height: Button.Height,
		    AnchorStyle: AnchorStyle.Bottom | AnchorStyle.Right,
		    Text: "确 定",
		    Css: "button_default",
		    Parent: This
		}
    );

    m_BtnOK.OnClick.Attach(
		function()
		{
		    if(callback!=undefined) callback();
		    This.Close();
		}
	);

    This.SetAcceptButton(m_BtnOK);
}

function NotifyHandler(data, msg)
{
    System.LoadModules(
		function()
		{			
		    Window = System.GetModule("Window.js").Window;
		    Controls = System.GetModule("Controls.js");

		    var dlg = new NotifyDialog(data);

		    dlg.MoveEx("RIGHT|BOTTOM", 0, 0);
		    dlg.Show(false);
		},
		System.HandleException,
		["Window.js", "Controls.js"]
	);
}

function AddFriendHandler(data, msg)
{
    var params = GetParams(data);
    System.LoadModules(
		function()
		{
		    Window = System.GetModule("Window.js").Window;
		    Controls = System.GetModule("Controls.js");

		    var confirmDialog = new AddFriendConfirmDialog(params[0], params[1], msg);

		    confirmDialog.MoveEx("RIGHT|BOTTOM", 0, 0);
		    confirmDialog.Show(false);
		},
		alert,
		["Window.js", "Controls.js"]
	);
}

function AddToGroupHandler(data, msg)
{
    var params = GetParams(data);

    System.LoadModules(
		function()
		{
		    Window = System.GetModule("Window.js").Window;
		    Controls = System.GetModule("Controls.js");

		    var confirmDialog = new AddToGroupConfirmDialog(params[2], params[3], params[0], params[1], msg.ID);

		    confirmDialog.MoveEx("RIGHT|BOTTOM", 0, 0);
		    confirmDialog.Show(false);
		},
		alert,
		["Window.js", "Controls.js"]
	);
}


function MessageHandler(msgs)
{
    for (var i = 0; i < msgs.length; i++)
    {
        msg = msgs[i];
                
        var cmd = GetCommand(msg.Content);
        if (cmd != null)
        {
            switch (cmd.Name)
            {
            case "ADDFRIEND":
                {
                    AddFriendHandler(cmd.Data, msg);
                    break;
                }
            case "ADDTOGROUP":
                {
                    AddToGroupHandler(cmd.Data, msg);
                    break;
                }
            case "NOTIFY":
                {
                    NotifyHandler(cmd.Data, msg);
                    break;
                }
            }
        }
    }
}

function MessageCacheCtor()
{
	var This = this;
	var m_Msgs = [];
	var m_Listener = {};
	
	function AddListener(owner)
	{
		var key = owner.toUpperCase();
		if (Config[key] == undefined) Config[key] = {};
		if (Config[key].LastReceiveTime == undefined)
		{
			Config[key].LastReceiveTime = new Date(2009, 1, 1);
		}
		var listener = new MessageListener(owner, 1, 0/*Config[key].LastReceiveTime*/, MessageListenerHandler);
		m_Listener[key] = listener;
		listener.Start();
	}
	
	This.Start = function()
	{
		AddListener(System.GetUser());
		
		Management.GetFriends(
			function(friends)
			{
				for(var key in friends)
				{
					var friend=friends[key];
					if(friend.Type==1)
					{
						AddListener(friend.Name);
					}
				}
			},
			function(){}
		);
	}
	
	This.Stop = function()
	{
		for(var key in m_Listener)
		{
			 m_Listener[key].Stop();
		}
		m_Listener={};
	}
	
	Management.OnChanged.Attach(
		function(type,friends)
		{
			if(type!="FriendInfo") return;
			
			var friendIndex={};
			for(var i in friends)
			{
				friendIndex[friends[i].Name.toUpperCase()]=friends[i];
			}
			//删除非好友的消息监听
			var removeKeys=[];
			for(var key in m_Listener)
			{
				if(friendIndex[key]==undefined && key!=System.GetUser().toUpperCase())
				{
					m_Listener[key].Stop();
					removeKeys.push(key);
				}
			}
			for(var i in removeKeys)
			{
				delete m_Listener[removeKeys[i]];
			}
			//监听新增好友消息
			for(var key in friendIndex)
			{
				if(friendIndex[key].Type==1 && m_Listener[key]==undefined)
				{
					AddListener(key);
				}
			}
		}
	);

	function MessageListenerHandler(ret)
	{
		if(m_Listener[ret.Owner.toUpperCase()] == undefined) return;
		
		ret.Messages.sort(
			function(item1, item2)
			{
				if (item1.CreatedTime > item2.CreatedTime) return 1;
				if (item1.CreatedTime < item2.CreatedTime) return -1;
				return 0;
			}
		);
		if (ret.Messages.length > 0) 
		{
			Config[ret.Owner.toUpperCase()].LastReceiveTime = ret.Messages[ret.Messages.length - 1].CreatedTime;
		}
		MessageHandler(ret.Messages);
	}
}

function ManagementCommandHandler(data)
{
	switch(data.Action)
	{
	case "RefreshFriends":
		{
		    FriendDataCahce.Refresh(
				function()
				{
				    FriendDataCahce.Notify();
				},
				function() { }
			);
			break;
		}
	}
}