﻿
var FileBrowser=null;
var Window=null;
var AnchorStyle=null;

function init(completeCallback,errorCallback)
{
	System.LoadModules(
		function()
		{
			FileBrowser=System.GetModule("CommonDialog.js").FileBrowser;
			Window=System.GetModule("Window.js").Window;
			AnchorStyle=System.GetModule("Controls.js").AnchorStyle;
			completeCallback();
		},
		errorCallback,
		["Window.js","Controls.js","CommonDialog.js"]
	);
}

function Application()
{
	var This=this;
	var m_Task=null;
	var m_FileBrowserWindow=null;
	var m_FileBrowser=null;
	
	this.Start=function(baseUrl)
	{
		var rootPath, initPath;
		if (arguments.length == 1)
		{
			rootPath = System.GetFullPath("");
			initPath = System.GetFullPath("Home");
		}
		else if (arguments.length == 2)
		{
			rootPath = System.GetFullPath("");
			initPath = arguments[1];
		}
		else
		{
			rootPath = arguments[1];
			initPath = arguments[2];
		}
		
		var config={
			Width:800,Height:600,Left:0,Top:0,
			Css:'window',BorderWidth:6,
			Resizable:true,HasMinButton:true,
			Title:{
				Height:18,
				InnerHTML:'文件浏览器'
			}
		}
		m_FileBrowserWindow=new Window(config);
	    
		m_FileBrowser=new FileBrowser(
			{
				Left:1,Top:1,Width:m_FileBrowserWindow.GetClientWidth()-2,Height:m_FileBrowserWindow.GetClientHeight()-2,
				Parent:m_FileBrowserWindow,
				AnchorStyle:AnchorStyle.All,
				EnableMultiSelect:true,
				Root: rootPath,
				OnBeginRequest:function()
				{
					m_FileBrowserWindow.Waiting();
				},
				OnEndRequest:function()
				{
					m_FileBrowserWindow.Completed();
				}
			}
		);
		
		m_FileBrowser.OnFileItemDblClick.Attach(
			function(item)
			{
				System.Exec(function(){},alert,"OpenWith.js",m_FileBrowser.GetCurrentPath()+'/'+item.GetFileInfo("Name"),false);
			}
		);
	    
		m_Task=Taskbar.AddTask(m_FileBrowserWindow,"文件浏览器");
		
		m_FileBrowserWindow.OnClosed.Attach(
			function()
			{
				if(Taskbar!=null) Taskbar.RemoveTask(m_Task);
				This.Dispose();
			}
		);
		
		m_FileBrowserWindow.MoveEx('center',0,0);
		m_FileBrowserWindow.Show(true);
    
		m_FileBrowser.Expand(
			function()
			{
				m_FileBrowser.SetCurrentPath(initPath);
			},
			rootPath
		);
	}
	
	this.Terminate=function(completeCallback,errorCallback)
	{
		m_FileBrowserWindow.Close();
		completeCallback();
	}
}