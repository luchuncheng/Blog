﻿System.Link("StyleSheet", Module.GetResourceUrl("ie6_tip.css"), "text/css");

var Controls = null, CommonDialog = null, IO = null, Communication = null, Management = null;
var Window = null, Control = null, RichEditor = null;

function init(completeCallback, errorCallback)
{
    function LoadModulesComplete()
    {
        IO = System.GetModule("IO.js");
        Communication = System.GetModule("Communication.js");
        Management = System.GetModule("Management.js");
        Controls = System.GetModule("Controls.js");
        CommonDialog = System.GetModule("CommonDialog.js");

        Window = System.GetModule("Window.js").Window;
        Control = System.GetModule("Controls.js").Control;
        
        RichEditor = System.GetModule("RichEditor.js").RichEditor;

        _init(completeCallback, errorCallback);
    }

    System.LoadModules(
        LoadModulesComplete,
        errorCallback,
        ["IO.js", "Communication.js", "Management.js", "Window.js", "Controls.js", "CommonDialog.js", "RichEditor.js"]
    );
}

function _init(completeCallback, errorCallback)
{
    try
    {
        //初始化代码，初始化完成后必须调用completeCallback;
        completeCallback();
    }
    catch (ex)
    {
        errorCallback(new Exception(ex.mame, ex.message));
    }
}



function dispose(completeCallback, errorCallback)
{
    _dispose(completeCallback, errorCallback);
}

function _dispose(completeCallback, errorCallback)
{
    try
    {
        //卸载代码，卸载完成后必须调用completeCallback;
        completeCallback();
    }
    catch (ex)
    {
        errorCallback(new Exception(ex.mame, ex.message));
    }
}

//共享全局变量和函数，在此定义的变量和函数将由该应用程序的所有实例共享


function Application()
{
    var CurrentApplication = this;
    var m_MainForm = null;
    
    //应用程序全局对象;
        

    this.Start = function(baseUrl)
    {
        //应用程序入口;
        m_MainForm = new MainForm();
        m_MainForm.OnClosed.Attach(
            function()
            {
                CurrentApplication.Dispose();
            }
        );
        m_MainForm.MoveEx("center", 0, -100);
        m_MainForm.Show(true);
        
    }

    this.Terminate = function(completeCallback, errorCallback)
    {
        try
        {
            //应用程序终止，退出系统时用系统调用;
            completeCallback();
        }
        catch (ex)
        {
            errorCallback(new Exception(ex.mame, ex.message));
        }
    }
    function MainForm()
    {
        var This = this;
        var OwnerForm = this;
        
        var config = {"Left":95,"Top":25,"Width":464,"Height":282,"AnchorStyle":Controls.AnchorStyle.Left | Controls.AnchorStyle.Top,"Parent":null,"Css":"window","BorderWidth":6,"HasMinButton":false,"HasMaxButton":false,"Resizable":false,"Title":{"InnerHTML":"提示"}};
        
    
        Window.call(This, config);
    
        var Base = {
            GetType: This.GetType,
            is: This.is
        };
    
        This.GetType = function() { return "MainForm"; }
        This.is = function(type) { return type == This.GetType() ? true : Base.is(type); }
        
        var customcontrol5_Config={"Left":1,"Top":1,"Width":450,"Height":250,"AnchorStyle":Controls.AnchorStyle.Left|Controls.AnchorStyle.Top,"Parent":This,"Text":"","Css":"control"};
        
                
        
        var customcontrol5 = new IE6_TIP(customcontrol5_Config);
        
        
    
    
        var m_Task = null;
        if(config.HasMinButton)
        {
            m_Task=Taskbar.AddTask(This,IsNull(config.Title.InnerHTML,""));
            This.OnClosed.Attach(
                function()
                {
                    Taskbar.RemoveTask(m_Task);
                }
            );
        }
        
    }

}



function IE6_TIP(config)
{
    var This = this;
    var OwnerForm = this;
    
config.Css = "IE6_TIP_BK";
    
    var width = config.Width, height = config.Height;
    config.Width=450;
    config.Height=250;

    Control.call(This, config);

    var Base = {
        GetType: This.GetType,
        is: This.is
    };

    This.GetType = function() { return "IE6_TIP"; }
    This.is = function(type) { return type == This.GetType() ? true : Base.is(type); }
    

    this.GetDom().innerHTML = "<a class ='link_chrome' target='_blank' href='http://www.google.cn/chrome'></a><a class ='link_firefox' target='_blank' href='http://download.mozilla.org/?product=firefox-3.6&os=win&lang=zh-CN'></a><a class ='link_ie8' target='_blank' href='http://download.microsoft.com/download/1/6/1/16174D37-73C1-4F76-A305-902E9D32BAC9/IE8-WindowsXP-x86-CHS.exe'></a>";

    This.Resize(width,height);
}

