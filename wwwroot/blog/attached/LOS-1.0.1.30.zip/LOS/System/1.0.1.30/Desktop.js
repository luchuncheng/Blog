﻿
var Directory=null;
var File=null;
var Control=null;
var AnchorStyle=null;
var Window = null;

var Controls=null;

var GUID = '6D36E3CC-7BC5-4AF2-B38C-EAF044A714BE'

var ConfigFileName = System.GetSpecialDirectory("Config") + "/" + GUID + ".conf";
var PreConfig = "";
var Config = null;

function init(completeCallback,errorCallback)
{
	System.LoadModules(
		function()
		{
			Controls = System.GetModule("Controls.js");

			Window = System.GetModule("Window.js").Window;

			Control = System.GetModule("Controls.js").Control;
			AnchorStyle = System.GetModule("Controls.js").AnchorStyle;
			Directory = System.GetModule("IO.js").Directory;
			File = System.GetModule("IO.js").File;
			File.Open(openFileCallback, errorCallback, ConfigFileName, true);
		},
		errorCallback,
		["Controls.js", "Window.js", "IO.js"]
	);
	
	function openFileCallback(configFile)
	{
		var configFileContent=configFile.Content;
		if(configFileContent=="")
		{
			Config = {
				Shortcuts: [
					{ ImageUrl: "FileBrowser/icon.png", ID: "SHORTCUT001", Text: "主文件夹", Handler: "System.Exec(function(){},alert,'FileBrowser.js',System.GetSpecialDirectory('Home'),System.GetSpecialDirectory('Home'))" },
					{ ImageUrl: "FileBrowser/pub.png", ID: "SHORTCUT002", Text: "共享文件", Handler: "System.Exec(function(){},alert,'FileBrowser.js',System.GetFullPath('pub'),System.GetFullPath('pub'))" },
					{ ImageUrl: "Notepad/icon.png", ID: "Notepad", Text: "记事本", Path: "Notepad/Notepad.js" },
					{ ImageUrl: "ImageBrowser/icon.png", ID: "ImageBrowser", Text: "查看图片", Path: "ImageBrowser.js" },
					{ ImageUrl: "IM/icon.png", ID: "IM", Text: "即时通讯", Path: "IM/IM.js" },
					{ ImageUrl: "Setting/icon.png", ID: "Setting", Text: "系统设置", Path: "Setting/Setting.js" },
				]
			};
			
			PreConfig = System.RenderJson(Config);
		}
		else
		{
			Config = System.ParseJson(configFileContent);
		}
		
		var temp = Config.Shortcuts;
		Config.Shortcuts = [
			{ ImageUrl: "FileBrowser/icon.png", ID: "SHORTCUT001", Text: "主文件夹", Handler: "System.Exec(function(){},alert,'FileBrowser.js',System.GetSpecialDirectory('Home'),System.GetSpecialDirectory('Home'))" },
			{ ImageUrl: "FileBrowser/pub.png", ID: "SHORTCUT002", Text: "共享文件", Handler: "System.Exec(function(){},alert,'FileBrowser.js',System.GetFullPath('pub'),System.GetFullPath('pub'))" }
		];
		
		for(var i in temp)
		{
			if(temp[i].ID != "SHORTCUT001" && temp[i].ID != "SHORTCUT002")
			{
				Config.Shortcuts.push(temp[i]);
			}
		}
		
        DocumentPanel=new DocumentPanelCtor();
        Module.Desktop=new DesktopCtor();
        Module.Taskbar=new TaskbarCtor();
	
		completeCallback();
	}
}

function SaveConfig(competeCallback,errorCallback)
{
	try
	{
		var configJson = System.RenderJson(Config);
		if(PreConfig != configJson)
		{
			File.Create(
				function()
				{
					PreConfig = configJson;
					competeCallback();
				},
				errorCallback,
				ConfigFileName,
				configJson
			);
		}
		else
		{
			competeCallback();
		}
	}
	catch(ex)
	{
		errorCallback(ex);
	}
}

function dispose(competeCallback,errorCallback)
{
	SaveConfig(competeCallback,errorCallback);
}

function TransferCharForJavascript(s)
{
	newStr = s.replace(
		/[\x26\x27\x3C\x3E\x0D\x0A]/g,
		function(c)
		{
			ascii = c.charCodeAt(0);
			return '\\u00' + (ascii < 16 ? '0' + ascii.toString(16) : ascii.toString(16));
		}
	);
	return newStr;
}

function DesktopItem(itemConfig)
{
	itemConfig = System.Clone(itemConfig);
	
	var imgUrl = itemConfig.ImageUrl.substr(0,1) == '/' ? System.GetUrl(System.GetFullPath(itemConfig.ImageUrl)) : System.GetUrl(System.GetSpecialDirectory("System") + "/" + itemConfig.ImageUrl) ;
	
	var isIE6=/MSIE 6.0/ig.test(navigator.appVersion);
	
	this.dom=document.createElement("div");
	this.dom.className='shortcut';
	this.dom.innerHTML = String.format(
		'<div class="icon" style="{0}"></div>'+
		'<div class="text">{1}</div>',
		isIE6?String.format("filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='{0}', sizingMethod='scale');",imgUrl):String.format("background-image:url('{0}')",imgUrl),
		System.ReplaceHtml(itemConfig.Text)
	);
	this.dom.ondblclick=function()
	{
		if (itemConfig.ID == "SHORTCUT001")
		{
			System.Exec(function(){},alert,'FileBrowser.js',System.GetSpecialDirectory('Home'),System.GetSpecialDirectory('Home'));
		}
		else
		{
			if (itemConfig.Handler != undefined) eval(itemConfig.Handler);
			else if (itemConfig.Path != undefined) System.Exec(function() { }, function(ex) { alert(ex); }, itemConfig.Path);
		}
	}
}

function TaskbarItem(dialog,title)
{
	var This=this;
	if(title==undefined) title="";
	this.Item=document.createElement("DIV");
	this.Item.className="item";
	this.Item.innerHTML = System.ReplaceHtml(title);
	this.Item.title=title;

	this.Item.onclick=function()
	{
		if(dialog==null) return;
		if(dialog.IsVisible())
		{
			if(dialog.IsTop())
				dialog.Hide();
			else
				dialog.BringToTop();
		}
		else
			dialog.Show(true);
		if(This.Item.className=="item_shine") This.Item.className="item";
	}
	
	this.Dialog=dialog;
	
	this.title=function(newTitle)
	{
		if(newTitle!=undefined) this.Item.innerHTML = System.ReplaceHtml(newTitle);
		This.Item.title=newTitle;
		return this.Item.innerHTML;
	}
	
	this.SetText=function(text)
	{
		This.Item.innerHTML = System.ReplaceHtml(text);
	}
	
	this.Shine=function(highlight)
	{
		if(highlight==undefined) highlight=false;
		var count=6;
		var interval=setInterval(
			function()
			{
				if(count>0)
				{
					switch(count)
					{
					case 1:
					case 3:
					case 5:
						This.Item.className="item";
						break;
					case 2:
					case 4:
					case 6:
						This.Item.className="item_shine";
						break;
					}
					count--;
				}
				else
				{
					This.Item.className=(highlight?"item_shine":"item");
					clearInterval(interval);
				}
			},
			200
		);
	}
}

function DocumentPanelCtor()
{
    var This=this;
    var config={
        Parent:null,
        Left:0,
        Top:0,
        Width:document.documentElement.clientWidth,
        Height:document.documentElement.clientHeight,
        Css:""
    }
    
    Control.call(This,config);
    
    var Base={
        GetType:This.GetType,
        is:This.is
    }
    
    This.is=function(type){return type==this.GetType()?true:Base.is(type);}
    This.GetType = function() { return "DocumentPanel"; }

    This.GetDom().style.overflow = "hidden";
    
    window.onresize=function()
    {
    	var width = (document.documentElement.clientWidth > 600) ? document.documentElement.clientWidth : 800;
    	var height = (document.documentElement.clientHeight > 450) ? document.documentElement.clientHeight : 600;
    	This.Resize(width, height);
    }
    
    document.body.appendChild(This.GetDom());
}

function DesktopCtor()
{
    var This=this;

    var config={
        Parent:DocumentPanel,
        Left:0,
        Top:0,
        Width:DocumentPanel.GetWidth(),
        Height:DocumentPanel.GetHeight()-28,
        Css:"desktop_d",
        AnchorStyle:AnchorStyle.All
    }
    Control.call(This,config);
    var Base={
        GetType:This.GetType,
        is:This.is
    }
    This.is=function(type){return type==this.GetType()?true:Base.is(type);}
    This.GetType = function() { return "Desktop"; }

	var m_MoveDiv=document.createElement("DIV");
	m_MoveDiv.style.position="absolute";
	m_MoveDiv.style.display='none';
	m_MoveDiv.style.zIndex='100000';
	m_MoveDiv.style.left='0px';
	m_MoveDiv.style.top='0px';
	m_MoveDiv.className='moveBackground';
	m_MoveDiv.setAttribute("unselectable","on");
	
	This.GetDom().appendChild(m_MoveDiv);
    
	var menuConfig={
		Items:[
			{Text:"添加/删除程序",ID:"Application"},
			{ID:""},
			{Text:"系统设置",ID:"Setting"}
		]
	};
	
	This.ContextMenu = new Controls.Menu(menuConfig);
	
	This.ContextMenu.OnCommand.Attach(
		function(cmd)
		{
			if(cmd == "Setting")
			{
				System.Exec(function(){},function(){},"Setting/Setting.js");
			}
			else if(cmd == "Application")
			{
				ApplicationMangementForm.GetInstance().Show(true);
				ApplicationMangementForm.GetInstance().Load();
			}
		}
	);
	
    This.ShowPage = function(visible)
    {
    }
    
    This.Navigate = function(url)
    {
    }
	
	This.DisplaySetting = function()
	{
		ApplicationMangementForm.GetInstance().Show(true);
		ApplicationMangementForm.GetInstance().Load();
	}

    This.GetDom().style.overflow = "hidden";
   
    This.GetDom().onscroll=function()
    {
		var dom=This.GetDom();
		if(dom.scrollLeft>0 || dom.scrollTop >0)
		{
			dom.scrollLeft=0;
			dom.scrollTop=0;
		}
    }
    
    var m_Items = {};
		
	for(var i in Config.Shortcuts)
	{
		var sc=Config.Shortcuts[i];
		
		var item=new DesktopItem(sc);
		m_Items[sc.ID] = item;
		This.GetDom().appendChild(item.dom);
	}
    
	This.AddShortcut=function(sc)
	{
		var item=new DesktopItem(sc);
		m_Items[sc.ID] = item;
		This.GetDom().appendChild(item.dom);
		
		Config.Shortcuts.push(System.Clone(sc));
	}
	
	This.RemoveShortcut = function(id)
	{
		if(m_Items[id]!=undefined)
		{
			This.GetDom().removeChild(m_Items[id].dom);
			delete m_Items[id];
			
			var index = -1;
			for(var i = 0; i<Config.Shortcuts.length; i++)
			{
				if(Config.Shortcuts[i].ID == id) {index = i; break;}
			}
			
			if(index >= 0) Config.Shortcuts.splice(index, 1);
		}
	}
	
	This.ExistsShortcut=function(id)
	{
		return m_Items[id] != undefined;
	}
	
	This.EnterMove=function(cursor)
	{
		m_MoveDiv.style.width=This.GetWidth()+'px';
		m_MoveDiv.style.height=This.GetHeight()+'px';
		m_MoveDiv.style.display='block';
		System.DisableSelect(m_MoveDiv, true);
		m_MoveDiv.style.cursor = (cursor == undefined ? "default" : cursor);
	}
	
	This.LeaveMove=function()
	{
		m_MoveDiv.style.display='none';
	}
    
    This.AddWindow=function(wnd)
    {
		This.AddControl(wnd);
    }
    
    This.RemoveWindow=function(wnd)
    {
		This.RemoveControl(wnd);
    }
}

function TaskbarCtor()
{      
    var This=this;
    var config={
        Parent:DocumentPanel,
        Left:0,
        Top:DocumentPanel.GetHeight()-28,
        Width:DocumentPanel.GetWidth(),
        Height:28,
        Css:"taskbar_d",
        AnchorStyle:AnchorStyle.Bottom|AnchorStyle.Left|AnchorStyle.Right
    }
    Control.call(This,config);
    var Base={
        GetType:This.GetType,
        is:This.is
    }
    This.is=function(type){return type==this.GetType()?true:Base.is(type);}
    This.GetType=function(){return "Taskbar";}
    
    var m_HGuide=new Controls.GuideLine(This.GetClientWidth(),[40,4,13,4,0,4,13,2]);

    var m_BtnLogout = new Control(
		{
			Parent: This,
			Left: 0, Top: 2, Width: m_HGuide.GetWidth(0), Height: 26,
			Css: 'logoutButton',
			AnchorStyle: AnchorStyle.Left | AnchorStyle.Top
		}
    );


    m_BtnLogout.GetDom().onclick = function()
    {
		if(confirm("您确定要退出系统？"))
		{
    		System.Shutdown();
    	}
    }
    
    var m_BtnLeft=new Control(
		{
			Parent:This,
			Left:m_HGuide.Get(1),Top:2,Width:m_HGuide.GetWidth(2),Height:26,
			Css:'btnLeft',
			AnchorStyle:AnchorStyle.Left|AnchorStyle.Top
		}
    );
    
    var m_BtnRight=new Control(
		{
			Parent:This,
			Left:m_HGuide.Get(5),Top:2,Width:m_HGuide.GetWidth(6),Height:26,
			Css:'btnRight',
			AnchorStyle:AnchorStyle.Right|AnchorStyle.Top
		}
    );
    
    var m_ItemPanel=new Control(
		{
			Parent:This,
			Left:m_HGuide.Get(3),Top:2,Width:m_HGuide.GetWidth(4),Height:26,
			Css:'itemPanel',
			AnchorStyle:AnchorStyle.All
		}
    );
    
    m_ItemPanel.GetDom().innerHTML="<div class='itemContainer'></div>";
    
    var m_ItemContainer=m_ItemPanel.GetDom().firstChild;
    
    m_ItemContainer.style.width='10px';
    m_ItemContainer.style.height='26px';
    
    m_BtnLeft.GetDom().onclick=function()
	{
		m_ItemPanel.GetDom().scrollLeft-=m_ScrollUnit;
	}
    
    m_BtnRight.GetDom().onclick=function()
	{
		m_ItemPanel.GetDom().scrollLeft+=m_ScrollUnit;
	}    
	
	m_ItemPanel.OnResized.Attach(
		function()
		{
			ResizeContainer();
			CalcScrollUnit();
		}
	);
	
	m_ItemContainer.onmousedown=function(evt)
	{
		var width=GetContainerWidth();
		m_ItemContainer.style.width=width;
		
		if(m_ItemPanel.GetClientWidth()<width)
		{
			if(evt==undefined) evt=event;
			
			MoveVar={
				PreClientX:evt.clientX,
				PreScrollLeft:m_ItemPanel.GetDom().scrollLeft,
				Object:m_ItemPanel.GetDom()
			}
		}
	}
	
	function GetContainerWidth()
	{
		return m_Count>=0?m_Count*m_ItemWidth+8:10;
	}
	
	function ResizeContainer()
	{
		var width=GetContainerWidth();
		m_ItemContainer.style.width=width+'px';
		
		if(m_ItemPanel.GetClientWidth()<width)
		{
			m_BtnLeft.SetVisible(true);
			m_BtnRight.SetVisible(true);
		}
		else
		{
			m_BtnLeft.SetVisible(false);
			m_BtnRight.SetVisible(false);
		}
		m_ItemPanel.GetDom().scrollLeft=m_ItemPanel.GetDom().scrollLeft;
	}
	
	function CalcScrollUnit()
	{
		var width=m_ItemPanel.GetClientWidth();
		var temp=Math.round(width/m_ItemWidth-0.5);
		m_ScrollUnit=((width % m_ItemWidth==0)?width:(Math.round(width/m_ItemWidth-0.5)*m_ItemWidth));
	}
	
	
	var items={};
	var m_Count=0;
	var m_ItemWidth = 110;
	var m_ScrollUnit=0;
	
	this.AddTask=function(dialog,title)
	{
		var item=new TaskbarItem(dialog,title);
		items[System.GenerateUniqueId()]=item;	
		m_ItemContainer.appendChild(item.Item);
		m_Count++;
		ResizeContainer();
		return item;
	}
	
	this.RemoveTask=function(item)
	{
		for(var k in items)
		{
			if(items[k]==item)
			{
				m_ItemContainer.removeChild(items[k].Item);
				delete items[k];
				m_Count--;
				ResizeContainer();
				break;
			}
		}
	}
	
	m_BtnLeft.SetVisible(false);
	m_BtnRight.SetVisible(false);
	CalcScrollUnit();
}
	
var MoveVar=null;

function body_onmousemove(evt)
{
	if(MoveVar!=null)
	{
		if(evt==undefined) evt=event;
		MoveVar.Object.scrollLeft=MoveVar.PreScrollLeft-(evt.clientX-MoveVar.PreClientX);
	}
}

function body_onmouseup(evt)
{
	MoveVar=null;
}

if(document.attachEvent)
{
	document.attachEvent(
		"onmousemove",
		function(evt)
		{
			if(evt==null) evt=window.event;
			body_onmousemove(evt);
		}
	);
	document.attachEvent(
		"onmouseup",
		function(evt)
		{
			if(evt==null) evt=window.event;
			body_onmouseup(evt);
		}
	);
}
else if(document.addEventListener)
{
	document.addEventListener(
		"mousemove",
		function(evt)
		{
			if(evt==null) evt=window.event;
			return body_onmousemove(evt);
		},
		false
	)
	document.addEventListener(
		"mouseup",
		function(evt)
		{
			if(evt==null) evt=window.event;
			return body_onmouseup(evt);
		},
		false
	)
}

function ApplicationMangementForm()
{
    var This = this;

    var config = {
    	Width: 680, Height: 500, Left: 0, Top: 0,
    	Css: 'window', BorderWidth: 6,
    	Resizable: true, HasMinButton: false, HasMaxButton: false,
    	MinWidth: 680, MinHeight: 500,
    	Title: {
    		Height: 18,
    		InnerHTML: '添加/删除程序'
    	},
    	OnClose:function()
    	{
    		This.Waiting("正在保存桌面配置....");
    		SaveConfig(
    			function()
    			{
    				This.Completed();
    				This.Close();
    			},
    			function(ex)
    			{
    				This.Completed();
    				alert(ex);
    				This.Close();
    			}
    		);
    	}
    };

    Window.call(This, config);

    var Base = {
        GetType: This.GetType,
        is: This.is
    };

    This.GetType = function() { return "ApplicationMangementForm"; }
    This.is = function(type) { return type == This.GetType() ? true : Base.is(type); }
    
    This.Load = function()
    {
    	This.Waiting("正在读取应用程序列表...");
    	File.Open(
			function(file)
			{
				try
				{
					var apps = System.ParseJson(file.Content);
				}
				catch(ex)
				{
					alert(ex);
				}
				m_ApplicationInfoContainer.Load(apps);
				This.Completed();
			},
			function(ex)
			{
				This.Completed();
				alert(ex);
			},
			System.GetSpecialDirectory("System") + "/Application.conf", false, "utf-8"
		);
    }
    
	var m_ApplicationInfoContainer = new ApplicationInfoContainer(
		{
			Left: 1, Top: 1, Width: This.GetClientWidth() - 2, Height: This.GetClientHeight() - 2,
			"AnchorStyle": Controls.AnchorStyle.All,
			Parent: This, Css: "applicationInfoContainer", BorderWidth: 1
		}
	);
}

ApplicationMangementForm.Instance = null;

ApplicationMangementForm.GetInstance = function()
{
	if(ApplicationMangementForm.Instance == null)
	{
		ApplicationMangementForm.Instance = new ApplicationMangementForm();
		ApplicationMangementForm.Instance.MoveEx('center', 0, -20);
		ApplicationMangementForm.Instance.OnClosed.Attach(
			function()
			{
				ApplicationMangementForm.Instance = null;
			}
		);
	}
	
	return ApplicationMangementForm.Instance;
}

function ApplicationInfoContainer(config)
{
    var This = this;

    Control.call(This, config);

    var Base = {
        GetType: This.GetType,
        is: This.is
    };

    This.GetType = function() { return "ApplicationInfoContainer"; }
    This.is = function(type) { return type == This.GetType() ? true : Base.is(type); }
    
    This.GetDom().style.overflowY = "scroll";
    This.GetDom().style.overflowX = "hidden";
    
    This.Load = function(apps)
    {
		This.Clear();
		var top = 0;
		for(var category in apps)
		{
			var header = new ApplicationCategoryHeader(
				{
					Left: 0, Top:top, Width:This.GetClientWidth() - 18, Height:24,
					AnchorStyle: Controls.AnchorStyle.Left | Controls.AnchorStyle.Right | Controls.AnchorStyle.Top,
					Parent:This, Css: "applicationCategoryHeader"
				}
			);
			header.SetText(category);
			top += 24;
			
			for(var i in apps[category])
			{
				new ApplicationInfoPanel(
					{
						Left: 0, Top:top, Width:This.GetClientWidth() - 18, Height:64,
    					AnchorStyle: Controls.AnchorStyle.Left | Controls.AnchorStyle.Right | Controls.AnchorStyle.Top,
						Parent:This, ApplicationInfo:apps[category][i], Css: "applicationInfoPanel"
					}
				);
				top += 64;
			}
		}
    }
	
}

function ApplicationCategoryHeader(config)
{
    var This = this;
    var OwnerForm = this;

    Control.call(This, config);

    var Base = {
        GetType: This.GetType,
        is: This.is
    };

    This.GetType = function() { return "ApplicationCategoryHeader"; }
    This.is = function(type) { return type == This.GetType() ? true : Base.is(type); }
    
    This.SetText = function(text)
    {
		This.GetDom().innerHTML = String.format("<div>{0}</div>", text);
    }
}

function ApplicationInfoPanel(config)
{
    var This = this;
    var OwnerForm = this;
    

    
    var width = config.Width, height = config.Height;
    config.Width=597;
    config.Height=64;

    Control.call(This, config);

    var Base = {
        GetType: This.GetType,
        is: This.is
    };

    This.GetType = function() { return "ApplicationInfoPanel"; }
    This.is = function(type) { return type == This.GetType() ? true : Base.is(type); }
    
    var m_AppIcon = new Controls.Control({"Left":16,"Top":8,"Width":48,"Height":48,"AnchorStyle":Controls.AnchorStyle.Left|Controls.AnchorStyle.Top,"Parent":This,"Text":"","Css":"control"});
    
    var url = System.GetUrl(System.GetSpecialDirectory("System") + "/" + config.ApplicationInfo.Icon);
    m_AppIcon.GetDom().style.backgroundImage = String.format("url({0})", url);
    
    m_AppIcon.OnResized.Attach(
        function(btn)
        {
            
        }
    )

    
    var m_AppName = new Controls.Label({"Left":72,"Top":11,"Width":345,"Height":14,"AnchorStyle":Controls.AnchorStyle.Left|Controls.AnchorStyle.Right|Controls.AnchorStyle.Top,"Parent":This,"Text":"","Css":"label"});
    
    m_AppName.GetDom().style.fontWeight = "bold";
    m_AppName.SetText(config.ApplicationInfo.Name);

    
    var m_AppSummary = new Controls.Label({"Left":72,"Top":35,"Width":345,"Height":20,"AnchorStyle":Controls.AnchorStyle.Left|Controls.AnchorStyle.Right|Controls.AnchorStyle.Top|Controls.AnchorStyle.Bottom,"Parent":This,"Text":"","Css":"label"});
    
    m_AppSummary.SetText(config.ApplicationInfo.Summary);

    
    var m_BtnExec = new Controls.Button({"Left":432,"Top":19,"Width":64,"Height":26,"AnchorStyle":Controls.AnchorStyle.Right|Controls.AnchorStyle.Top,"Parent":This,"Text":"运 行","Css":"button"});
    
    
    
    m_BtnExec.OnClick.Attach(
        function(btn)
        {
            System.Exec(function(){},function(ex){alert(ex);},config.ApplicationInfo.Path);
        }
    )

    
    var m_BtnAdd = new Controls.Button({"Left":507,"Top":19,"Width":64,"Height":26,"AnchorStyle":Controls.AnchorStyle.Right|Controls.AnchorStyle.Top,"Parent":This,"Text":"添 加","Css":"button"});
    
    
    
    m_BtnAdd.OnClick.Attach(
        function(btn)
        {
            if(m_BtnAdd.GetText() == "删 除")
            {
				Module.Desktop.RemoveShortcut(config.ApplicationInfo.ID);
            }
            else
            {
				Module.Desktop.AddShortcut(
					{
						ImageUrl: config.ApplicationInfo.Icon, 
						ID: config.ApplicationInfo.ID, 
						Text: config.ApplicationInfo.Name, 
						Path: config.ApplicationInfo.Path 
					}	
				);
            }
			m_BtnAdd.SetText(Module.Desktop.ExistsShortcut(config.ApplicationInfo.ID) ? "删 除" : "添 加");
			m_BtnAdd.SetCss(Module.Desktop.ExistsShortcut(config.ApplicationInfo.ID) ? "button" : "button_default");
        }
    );

    m_BtnAdd.SetText(Module.Desktop.ExistsShortcut(config.ApplicationInfo.ID) ? "删 除" : "添 加");
	m_BtnAdd.SetCss(Module.Desktop.ExistsShortcut(config.ApplicationInfo.ID) ? "button" : "button_default");
    

    

    This.Resize(width,height);
}
