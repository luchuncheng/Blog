﻿
System.Link("StyleSheet",Module.GetResourceUrl("ImageBrowser/StyleSheet.css"),"text/css");

var ImageBrowser=null;
var Window=null;
var Control=null;
var AnchorStyle=null;

function init(completeCallback,errorCallback)
{
	System.LoadModules(
		function()
		{
			ImageBrowser=System.GetModule("CommonDialog.js").ImageBrowser;
			Window=System.GetModule("Window.js").Window;
			Control=System.GetModule("Controls.js").Control;
			AnchorStyle=System.GetModule("Controls.js").AnchorStyle;
			completeCallback();
		},
		errorCallback,
		["Window.js","Controls.js","CommonDialog.js"]
	);
}

var MoveData=null;

System.AttachEvent(
	document,"mousemove",
	function(evt)
	{
		if(evt==undefined) evt=event;
		if(MoveData!=null)
		{
			MoveData.Target.style.left=(MoveData.PreviousLeft+(evt.clientX-MoveData.PreviousClientX))+'px';
			MoveData.Target.style.top=(MoveData.PreviousTop+(evt.clientY-MoveData.PreviousClientY))+'px';
		}
	}
);

System.AttachEvent(
	document,"mouseup",
	function(evt)
	{
		if(MoveData!=null)
		{
			Desktop.LeaveMove();
			MoveData=null;
		}
	}
);

function Application()
{
	var This=this;
	var m_ImageBrowserForm=null;
	var m_Task=null;
	
	this.Start=function(baseUrl,picUrl)
	{
		m_ImageBrowserForm=new ImageBrowserForm();
		m_Task=Taskbar.AddTask(m_ImageBrowserForm,'图片浏览');
		m_ImageBrowserForm.OnClosed.Attach(
			function(wnd)
			{
				Taskbar.RemoveTask(m_Task);
				This.Dispose();
			}
		);
		m_ImageBrowserForm.MoveEx('center',0,0);
		m_ImageBrowserForm.Show(true);
		m_ImageBrowserForm.Focus();
		
		if(picUrl!=undefined)
		{
			m_ImageBrowserForm.Load(picUrl);
		}
		else
		{
			m_ImageBrowserForm.Select(function(){},System.GetFullPath("Home"));
		}
	}
	
	this.Terminate=function(completeCallback,errorCallback)
	{
		m_ImageBrowserForm.Close();
		completeCallback();
	}
}

function ImageBrowserForm()
{
	var This=this;	
	
	var winConfig={
		Width:730,Height:550,Left:0,Top:0,
		Css:'window',BorderWidth:6,
		Resizable:true,HasMinButton:true,
		Title:{
			Height:18,
			InnerHTML:'图片浏览'
		}
	}
	
	Window.call(this,winConfig);
	    
	var Base={
		GetType:this.GetType,
		is:this.is
	}
    
	this.is=function(type){return type==this.GetType()?true:Base.is(type);}
	this.GetType=function(){return "ImageBrowserForm";}
	   
	var	m_ImageBrowser=new ImageBrowser(
		{
			Left:1,Top:1,Width:This.GetClientWidth()-2,Height:This.GetClientHeight()-2,
			Parent:This,
			AnchorStyle:AnchorStyle.All
		}
	);
	
	var m_ImagePanel=new ImagePanel(
		{
			Left:1,Top:1,Width:This.GetClientWidth()-2,Height:This.GetClientHeight()-2,
			Parent:This,
			AnchorStyle:AnchorStyle.All,
			Css:"imagePanel"
		},
		m_ImageBrowser
	);
	m_ImagePanel.SetVisible(false);
	
	This.Select=m_ImageBrowser.Select;
	This.SelectPublic=m_ImageBrowser.SelectPublic;
	
	m_ImageBrowser.OnDblClick.Attach(
		function(path,info)
		{
			m_ImagePanel.SetVisible(true);
			m_ImageBrowser.SetVisible(false);
			m_ImagePanel.Load(info);
		}
	);
	
	This.Load=function(path)
	{
		m_ImageBrowser.Select(
			function(node)
			{
				if(node!=null)
				{
					var name=System.Path.GetFileName(path).toUpperCase();
					var allImages=m_ImageBrowser.GetAllImages();
					for(var i in allImages)
					{
						if(allImages[i].Name.toUpperCase()==name)
						{
							m_ImagePanel.SetVisible(true);
							m_ImagePanel.Load(allImages[i]);
							break;
						}
					}
				}
				else
				{
					m_ImageBrowser.Select(
						function()
						{
							m_ImagePanel.SetVisible(true);
							m_ImagePanel.Load(
								{
									Path:path,
									Name:name,
									Index:-1
								}
							);
						},
						System.GetFullPath("Home")
					);
				}
			},
			System.Path.GetDirectoryName(path)
		);
	}
}

function ImagePanel(config,browser)
{
	var This=this;	
	
	Control.call(this,config);
	    
	var Base={
		GetType:this.GetType,
		is:this.is
	}
    
	this.is=function(type){return type==this.GetType()?true:Base.is(type);}
	this.GetType=function(){return "ImagePanel";}
	
	var m_ImageBk=new Control(
		{
			Left:0,Top:0,Width:This.GetClientWidth(),Height:This.GetHeight()-0,
			AnchorStyle:AnchorStyle.All,
			Parent:This,Css:'imageBackground'
		}
	);
	
	var m_ImagePanel=new Control(
		{
			Left:0,Top:0,Width:This.GetClientWidth(),Height:This.GetHeight()-0,
			AnchorStyle:AnchorStyle.All,
			Parent:This,Css:'imageContainer'
		}
	);
	/*
	var m_TitlePanel=new Control(
		{
			Left:0,Top:0,Width:This.GetClientWidth(),Height:30,
			AnchorStyle:AnchorStyle.Left | AnchorStyle.Right,
			Parent:This,Css:'titleContainer'
		}
	);
	
	m_TitlePanel.GetDom().innerHTML="<div class='text'>AAA</div><div class='btnClose'></div>";
	*/
	var m_Image=null;
	
	var m_Toolbar=new ImageToolbar(
		{
			Left:(This.GetWidth()-192)/2,Top:This.GetHeight()-24-16,Width:192,Height:24,
			AnchorStyle:AnchorStyle.Right | AnchorStyle.Bottom,
			Parent:This,Css:'toolbar'
		}
	);
	
	function resize()
	{
		var width=m_ImagePanel.GetWidth();
		var height=m_ImagePanel.GetHeight();
		
		if(m_Image!=null)
		{
			m_Image.style.left=(width-m_Image.width)/2+'px';
			m_Image.style.top=(height-m_Image.height)/2+'px';
		}
		
		m_Toolbar.Move(
			(This.GetWidth()-m_Toolbar.GetWidth())/2,
			This.GetHeight()-m_Toolbar.GetHeight()-16
		);
	}
	
	function adjust()
	{
		var width=m_ImagePanel.GetWidth();
		var height=m_ImagePanel.GetHeight();
		if(m_ImageInfo.Width>width || m_ImageInfo.Height>height)
		{
			if(m_ImageInfo.Width*height<m_ImageInfo.Height*width)
			{
				m_Image.height=height;
				m_Image.width=m_ImageInfo.Width*height/m_ImageInfo.Height;
			}
			else
			{
				m_Image.width=width;
				m_Image.height=m_ImageInfo.Height*width/m_ImageInfo.Width;
			}
		}
		else
		{
			m_Image.width=m_ImageInfo.Width;
			m_Image.height=m_ImageInfo.Height;
		}
	}
	
	This.OnResized.Attach(
		function()
		{
			resize();
		}
	);
	
	function img_onmousedown(evt)
	{
		if(evt==undefined) evt=event;
		Desktop.EnterMove("move");
		MoveData={
			Target:m_Image,
			PreviousClientX:evt.clientX,
			PreviousClientY:evt.clientY,
			PreviousLeft:parseInt(m_Image.style.left),
			PreviousTop:parseInt(m_Image.style.top)
		};
		if(evt.preventDefault) evt.preventDefault(); 
		return false;
	}
	
	This.Load=function(image)
	{
		m_ImageInfo=image;
		m_Image=new Image();
		m_Image.onselectstart=function(){return false;}
		System.DisableSelect(m_Image);
		m_Image.onmousedown=img_onmousedown;
		
		if(m_ImageInfo.Index==-1)
		{
			var dom=m_ImagePanel.GetDom();
			if(dom.firstChild!=null && dom.firstChild!=undefined) dom.removeChild(dom.firstChild);
			This.GetTopContainer().Waiting("正在加载图片...");
			m_Image.onload=function()
			{
				m_ImageInfo.Width=m_Image.width;
				m_ImageInfo.Height=m_Image.height;
				dom.appendChild(m_Image);
				adjust();
				resize();
				This.GetTopContainer().Completed();
			}
			m_Image.src=System.GetUrl(m_ImageInfo.Path);
		}
		else
		{
			var dom=m_ImagePanel.GetDom();
			if(dom.firstChild!=null && dom.firstChild!=undefined)
				dom.replaceChild(m_Image,dom.firstChild);
			else
				dom.appendChild(m_Image);
				
			m_Image.width=image.Width;
			m_Image.height=image.Height;
			
			adjust();
			resize();
			
			This.GetTopContainer().Waiting("正在加载图片...");
			m_Image.onload=function()
			{
				adjust();
				resize();
				This.GetTopContainer().Completed();
			}
			m_Image.src=System.GetUrl(image.Path);
		}
			
	}

	var m_ImageInfo;
	var CurrentImagePanel=This;
	
	function ImageToolbar(config)
	{
		var This=this;	
		
		Control.call(this,config);
		    
		var Base={
			GetType:this.GetType,
			is:this.is
		}
	    
		this.is=function(type){return type==this.GetType()?true:Base.is(type);}
		this.GetType=function(){return "ImageToolbar";}
		
		This.GetDom().innerHTML=
			"<div class='toolbarMargin'></div>"+
			"<div title='放大' class='btnZoomIn'></div>"+
			"<div title='缩小' class='btnZoomOut'></div>"+
			"<div title='适应窗口' class='btnAdjust'></div>"+
			"<div title='实际大小' class='btnOriginal'></div>"+
			"<div title='上一个' class='btnPrevious'></div>"+
			"<div title='下一个' class='btnNext'></div>"+
			"<div title='关闭' class='btnClose'></div>"+
			"<div class='toolbarMargin'></div>";
		
		This.GetDom().childNodes[1].onclick=function()
		{
			m_Image.width=m_Image.width*1.2;
			m_Image.height=m_Image.height*1.2;
			resize();
		}
		
		This.GetDom().childNodes[2].onclick=function()
		{
			if(m_Image.width>50 && m_Image.height>50)
			{
				m_Image.width=m_Image.width/1.2;
				m_Image.height=m_Image.height/1.2;
				resize();
			}
		}
		
		This.GetDom().childNodes[3].onclick=function()
		{
			adjust();
			resize();
		}
		
		This.GetDom().childNodes[4].onclick=function()
		{
			m_Image.width=m_ImageInfo.Width;
			m_Image.height=m_ImageInfo.Height;
			resize();
		}
		
		This.GetDom().childNodes[5].onclick=function()
		{
			if(m_ImageInfo.Index==-1) return;
			var allImages=browser.GetAllImages();
			if(m_ImageInfo.Index>0) 
			{
				CurrentImagePanel.Load(allImages[m_ImageInfo.Index-1]);
			}
		}
		
		This.GetDom().childNodes[6].onclick=function()
		{
			if(m_ImageInfo.Index==-1) return;
			var allImages=browser.GetAllImages();
			if(m_ImageInfo.Index<allImages.length-1) 
			{
				CurrentImagePanel.Load(allImages[m_ImageInfo.Index+1]);
			}
		}
		
		This.GetDom().childNodes[7].onclick=function()
		{
			browser.SetVisible(true);
			CurrentImagePanel.SetVisible(false);
		}
		
	}
}