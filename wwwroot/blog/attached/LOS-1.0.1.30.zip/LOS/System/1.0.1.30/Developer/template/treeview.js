﻿////<pre class="sh_javascript">

var [[NAME]]_DS=function()
{
////</pre>
////[[DSMEMBER]]
////<div id="[[FULLNAME]].DataSource.Member" style="margin-left:[[ML:1]]px; margin-top:0px; margin-bottom:0px;"></div>
////<pre class="sh_javascript">

	this.GetSubNodes=function(callback,item)
	{
////</pre>
////[[GETSUBNODES]]
////<div id="[[FULLNAME]].DataSource.GetSubNodes" style="margin-left:[[ML:2]]px; margin-top:0px; margin-bottom:0px;"></div>
////<pre class="sh_javascript">
	}
}
////</pre>
////<pre class="sh_javascript">

var [[NAME]] = new Controls.TreeView([[CONFIG]]);

////</pre>
////[[INIT]]
////<div id="[[FULLNAME]].Init" style="margin-left:[[ML:0]]px; margin-top:0px; margin-bottom:0px;"></div>
////<pre class="sh_javascript">

[[NAME]].OnClick.Attach(
	function(btn)
	{
////</pre>
////[[ONCLICK_CODE]]
////<div id="[[FULLNAME]].OnClick" style="margin-left:[[ML:2]]px; margin-top:0px; margin-bottom:0px;"></div>
////<pre class="sh_javascript">
	}
)
////</pre>