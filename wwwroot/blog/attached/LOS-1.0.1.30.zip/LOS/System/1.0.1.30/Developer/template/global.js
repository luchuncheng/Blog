﻿////<pre class="sh_javascript">
//模块级全局变量和函数，在此定义的变量和函数将由该应用程序的所有实例共享
////[[CODE]]
////</pre>
////<div id="global" style="margin-left:[[ML:0]]px; margin-top:0px; margin-bottom:0px;"></div>
