﻿////<pre class="sh_javascript">

var [[NAME]] = new Controls.SimpleTabControl([[CONFIG]]);

////</pre>
////[[INIT]]
////<div id="[[FULLNAME]].Init" style="margin-left:[[ML:0]]px; margin-top:0px; margin-bottom:0px;"></div>
////<pre class="sh_javascript">

[[NAME]].OnSelectedTab.Attach(
	function(index,preIndex)
	{
////</pre>
////[[ONRESIZED_EVENT]]
////<div id="[[FULLNAME]].OnSelectedTab" style="margin-left:[[ML:2]]px; margin-top:0px; margin-bottom:0px;"></div>
////<pre class="sh_javascript">
	}
)
////</pre>