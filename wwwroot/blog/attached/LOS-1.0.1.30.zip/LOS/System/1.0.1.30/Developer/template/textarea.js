﻿////<pre class="sh_javascript">

var [[NAME]] = new Controls.TextArea([[CONFIG]]);

////</pre>
////[[INIT]]
////<div id="[[FULLNAME]].Init" style="margin-left:[[ML:0]]px; margin-top:0px; margin-bottom:0px;"></div>