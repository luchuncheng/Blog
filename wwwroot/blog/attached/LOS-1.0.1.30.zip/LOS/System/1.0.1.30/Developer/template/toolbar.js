﻿////<pre class="sh_javascript">

var [[NAME]] = new Controls.Toolbar([[CONFIG]]);

////</pre>
////[[INIT]]
////<div id="[[FULLNAME]].Init" style="margin-left:[[ML:0]]px; margin-top:0px; margin-bottom:0px;"></div>
////<pre class="sh_javascript">

[[NAME]].OnCommand.Attach(
	function(command)
	{
////</pre>
////[[ONCOMMAND]]
////<div id="[[FULLNAME]].OnCommand" style="margin-left:[[ML:2]]px; margin-top:0px; margin-bottom:0px;"></div>
////<pre class="sh_javascript">
	}
)
////</pre>