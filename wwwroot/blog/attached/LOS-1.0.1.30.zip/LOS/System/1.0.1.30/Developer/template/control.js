﻿////<pre class="sh_javascript">

var [[NAME]] = new Controls.Control([[CONFIG]]);

////</pre>
////[[INIT]]
////<div id="[[FULLNAME]].Init" style="margin-left:[[ML:0]]px; margin-top:0px; margin-bottom:0px;"></div>
////<pre class="sh_javascript">

[[NAME]].OnResized.Attach(
	function(btn)
	{
////</pre>
////[[ONRESIZED_EVENT]]
////<div id="[[FULLNAME]].OnResized" style="margin-left:[[ML:2]]px; margin-top:0px; margin-bottom:0px;"></div>
////<pre class="sh_javascript">
	}
)
////</pre>