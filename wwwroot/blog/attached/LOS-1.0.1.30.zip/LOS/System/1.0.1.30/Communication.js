﻿
function init(completeCallback,errorCallback)
{
	completeCallback();
}

/*
accessories=[
{Source:,Name:},
{Source:,Name:}
]
*/
function Communication()
{
}

var BaseDate=new Date(2009,0,1);

Communication.Send=function(callback,errorCallback,type,guid,receiver,msgBody,accessories)
{
	var builder=[];
	builder.push('<CommunicationService Command="Send">');
	builder.push(String.format('<Message Receiver="{0}" GUID="{1}" Type="{2}">',receiver,guid,type));
	builder.push(String.format('<Body>{0}</Body>',System.TransferCharForXML(msgBody)));
	for(var index in accessories)
	{
		builder.push(
			String.format(
				'<Accessory Source="{0}" Name="{1}"/>',
				accessories[index].Source,
				accessories[index].Name
			)
		);
	}
	builder.push("</Message>");
	builder.push('</CommunicationService>');
	var data=builder.join('\r\n');
	
	return System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
				callback()
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}

Communication.SendInstantMessage=function(callback,errorCallback,receiver,msgBody,accessories)
{
	var builder=[];
	builder.push('<CommunicationService Command="SendInstantMessage">');
	builder.push(String.format('<Message Receiver="{0}" Type="0">',receiver));
	builder.push(String.format('<Body>{0}</Body>',System.TransferCharForXML(msgBody)));
	for(var index in accessories)
	{
		builder.push(
			String.format(
				'<Accessory Source="{0}" Name="{1}"/>',
				accessories[index].Source,
				accessories[index].Name
			)
		);
	}
	builder.push("</Message>");
	builder.push('</CommunicationService>');
	var data=builder.join('\r\n');
	
	return System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
				callback(ret.Message)
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}

Communication.AddListener=function (callback,errorCallback,guid,owner,type,from,handlerId)
{
	var data = System.CreateServiceData(
		"CommunicationService", "AddListener",
		{
			Owner: owner, Type: type, From: from == 0 ? 0 : from - BaseDate, HandlerID: handlerId, Guid: guid
		}
	);
	
	return System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
				callback(ret.Return)
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}

Communication.RemoveListener=function (callback,errorCallback,owner,guid)
{
	var data = System.CreateServiceData(
		"CommunicationService","RemoveListener",
		{
			Owner:owner,Guid:guid
		}
	);
	
	return System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
				callback(ret.Return)
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}

Communication.FindInstantMessages=function (callback,errorCallback,user,sender,from,to,count)
{
	var data = System.CreateServiceData(
		"CommunicationService","FindInstantMessages",
		{
			From:from==null?"":from-BaseDate,
			To:to==null?"":to-BaseDate,
			Count: count==null?"":count,
			Sender:sender==null?"":sender,
			User:user
		}
	);
	
	return System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
				callback(ret.Return)
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}

Communication.GetAllSenders=function (callback,errorCallback,user)
{
	var data = System.CreateServiceData(
		"CommunicationService","GetAllSenders",
		{
			User:user
		}
	);
	
	return System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
				callback(ret.Return)
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}

Communication.GetMessageDate=function (callback,errorCallback,user,type)
{
	var data = System.CreateServiceData(
		"CommunicationService","GetMessageDate",
		{
			Type:type,
			User:user
		}
	);
	
	return System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
				callback(ret.Return)
			else
				errorCallback(ret.Data);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}

Module.Communication=Communication;

function dateToString(date)
{
	if(date!=null)
		return String.format("{0}-{1}-{2} {3}:{4}:{5}",date.getFullYear(),date.getMonth()+1,date.getDate(),date.getHours(),date.getMinutes(),date.getSeconds());
	else
		return "";
}


function encode(str)
{
	var res=str.replace(
		/&|\x5C|\x0A|\x2B|\x0D/g,
		function(s)
		{
			var ascii=s.charCodeAt(0)
			if(ascii<=0xFF)
			{
				var zero=''
				if(ascii<=0xF) zero+='0'
				return '\\x'+zero+ascii.toString(16)
			}
			else
			{
				var zero=''
				if(ascii<=0xF) zero+='000'
				else if(ascii<=0xFF) zero+='00'
				else if(ascii<=0xFFF) zero+='0'
				return '\\u'+zero+ascii.toString(16)
			}
		}
	)
	return res		
}

function MessageListener(owner,type,from,handler)
{
	var This = this;
	var m_Msgs = [];
	var m_Listener = "";
	var m_MaxCreatedTime = from;
	var m_Key=owner.toUpperCase();
	var m_HandlerID = "MLH-"+System.GenerateUniqueId();
	var m_Stop = true;
	
	This.GetOwner=function(){return owner;}
	
	function AddListener(retry,count)
	{
		if(retry==undefined) retry=true;
		if(count==undefined) count=0;
		var key=owner.toUpperCase();
		
		Communication.AddListener(
			function(ret)
			{
				m_Listener=ret;
			},
			function()
			{
				if(retry && count<5 && !m_Stop) 
				{
					setTimeout(function(){AddListener(retry,count+1)},5*1000);
				}
			},
			m_Listener,
			owner,type,m_MaxCreatedTime,m_HandlerID
		);
	}
	
	function RemoveListener()
	{
		var key=owner.toUpperCase();
		Communication.RemoveListener(
			function(){},
			function(){},
			owner,
			m_Listener
		);
	}
	
	System.OnSessionRecover.Attach(
		function(error)
		{
			AddListener(true);
		}
	);

	This.Start = function()
	{
		if(!m_Stop) return;
		m_Stop = false;
		System.RegisterCommandHandler(m_HandlerID,MessageListenerHandler);
		AddListener();
	}
	
	This.Stop = function()
	{
		if(m_Stop) return;
		m_Stop = true;
		System.RemoveCommandHandler(m_HandlerID);
		RemoveListener();
		This.OnStop.Call(this);
	}

	function MessageListenerHandler(ret)
	{
		if(m_Stop) return;
		try
		{
			var key = ret.Owner.toUpperCase()
			for(var i in ret.Messages)
			{
				if(ret.Messages[i].CreatedTime > m_MaxCreatedTime)
					m_MaxCreatedTime = ret.Messages[i].CreatedTime;
			}
		}
		catch(ex)
		{
		}
		handler(ret);
	}
	
	this.OnStop = new Delegate();
}

Module.MessageListener = MessageListener;