﻿
var FileSystem=new (function(){
	
	var m_Root="/";
	
	var m_FileSystem=new FileSystemItem(System.GetUser(),"");
	
	this.Find=function(path)
	{
		return m_FileSystem.Find(path);
	}
	this.AddItem=function(path,newItem)
	{
		m_FileSystem.AddItem(path,newItem);
	}
	this.Add=function(fullPath,itemInfo)
	{
		var item=this.Find(Path.GetDirectoryName(fullPath));
		if(item!=null)
		{
			item.Add(itemInfo);
		}
	}
	this.Renew=function(fullPath,itemInfo,createNew)
	{
		var item=this.Find(Path.GetDirectoryName(fullPath));
		if(item!=null)
		{
			item.Renew(Path.GetFileName(fullPath),itemInfo,createNew);
		}
	}
	this.Delete=function(fullPath)
	{
		var item=this.Find(Path.GetDirectoryName(fullPath));
		if(item!=null)
		{
			item.Delete(Path.GetFileName(fullPath));
		}
	}
	this.Reset=function(fullPath,newItems)
	{
		var item=this.Find(fullPath);
		if(item!=null)
		{
			item.Reset(newItems);
		}
	}
	this.OnRefresh=new Delegate();

})();
	
function FileSystemItem(name,fullPath)
{
	var m_SubItems={};
	var m_ItemInfos=null;
	
	var CurrentItem=this;
	
	var m_LastUpdateTime=null;
	
	this.OnRefresh=new Delegate();
	
	this.Private={
		AddItem:function(nodes,start,newItem)
		{
			if(nodes==null || start==nodes.length)
			{
				m_SubItems[newItem.GetName()]=newItem;
			}
			else
			{
				var name=nodes[start];
				var next=m_SubItems[name];
				if(next==undefined)
				{
					next=new FileSystemItem(name,CurrentItem.GetFullPath()+"/"+name);
					m_SubItems[name]=next;
				}
				next.Private.AddItem(nodes,start+1,newItem);
			}
		},
		Find:function(nodes,start)
		{
			if(start==nodes.length-1 && CurrentItem.Exists(nodes[start]))
			{
				return m_SubItems[nodes[start]];
			}
			else
			{
				var next=m_SubItems[nodes[start]];
				return next==undefined?null:next.Private.Find(nodes,start+1);
			}
		}
	}
	this.GetName=function()
	{
		return name;
	}
	this.GetFullPath=function()
	{
		return fullPath;
	}
	this.Exists=function(itemName)
	{
		return m_SubItems[itemName]!=undefined;
	}
	this.AddItem=function(path,newItem)
	{
		this.Private.AddItem(path.split("/"),1,newItem);
	}
	this.RemoveItem=function(item)
	{
		delete m_SubItems[item.GetName()];
	}
	this.Find=function(path)
	{
		return this.Private.Find(path.split("/"),1);
	}
	this.Refresh=function(completeCallback,errorCallback,useCache)
	{			
		if(useCache==undefined) useCache=true;
		if(m_ItemInfos==null || useCache==false)
		{
			var data = System.CreateServiceData(
				"DirectoryService","GetSubItems",{Path:CurrentItem.GetFullPath()}
			);
			System.SendCommand(
				function(ret)
				{
					if(ret.Result=="OK")
					{
						m_ItemInfos=ret.Items;
						m_LastUpdateTime=new Date();
						FileSystem.AddItem(Path.GetDirectoryName(CurrentItem.GetFullPath()),CurrentItem);
						completeCallback(ret.Items)
					}
					else
						errorCallback(ret.Message);
				},
				function(error)
				{
					errorCallback(error)
				},
				data
			)
		}
		else
		{
			completeCallback(m_ItemInfos);
		}
	}
	this.Notify=function()
	{
		FileSystem.OnRefresh.Call(CurrentItem.GetFullPath(),m_ItemInfos);
	}
	this.IndexOf = function(name)
	{
		for (var i = 0; i < m_ItemInfos.length; i++)
		{
			if (name == m_ItemInfos[i].Name) return i;
		}
		return -1;
	}
	this.Add = function(itemInfo)
	{
		if (m_ItemInfos != null)
		{
			var index = this.IndexOf(itemInfo.Name);
			if (index == -1) m_ItemInfos.push(itemInfo);
			else m_ItemInfos[index] = itemInfo;
			this.Notify();
		}
	}
	this.Renew=function(name,itemInfo,createNew)
	{
		if(createNew==undefined) createNew=false;
		
		if(m_ItemInfos!=null)
		{
			for(var i=0;i<m_ItemInfos.length;i++)
			{
				if(m_ItemInfos[i].Name==name)
				{
					m_ItemInfos[i]=itemInfo;
					this.Notify();
					break;
				}
			}
			if(i>=m_ItemInfos.length && createNew)
			{
				m_ItemInfos.push(itemInfo);
				this.Notify();
			}
		}
	}
	this.Delete=function(name)
	{
		if(m_ItemInfos!=null)
		{
			var i;
			for(var i=0;i<m_ItemInfos.length;i++)
			{
				if(m_ItemInfos[i].Name==name) break;
			}
			if(i<m_ItemInfos.length) m_ItemInfos.splice(i,1);
			this.Notify();
		}
	}
	this.Reset=function(newItems)
	{
		m_ItemInfos=newItems;
		m_LastUpdateTime=new Date();
		this.Notify();
	}
}

Module.FileSystem=FileSystem;

(function(){

function File()
{
}

File.Create=function(callback,errorCallback,fileName,content,encoding)
{
	if(content==undefined) content="";
	if(encoding==undefined) encoding="utf-8";
	var data=System.CreateServiceData(
		"FileService","Create",{FileName:fileName,Content:content,Encoding:encoding}
	);
	System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
			{
				FileSystem.Renew(fileName,ret.NewItemInfo,true);
				callback({FileName:fileName,Content:content})
			}
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data,
		false
	)
}

File.Open=function(callback,errorCallback,fileName,createNew,encoding)
{
	if(createNew==undefined) createNew=false;
	if(encoding==undefined) encoding="utf-8";
	
	var data=System.CreateServiceData(
		"FileService","Open",{FileName:fileName,CreateNew:createNew,Encoding:encoding}
	);

	System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
			{
				if (ret.NewItemInfo != undefined) FileSystem.Renew(fileName, ret.NewItemInfo, true);
				callback({FileName:fileName,Content:ret.Content})
			}
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data,
		false
	)
}

File.Zip=function(callback,errorCallback,items,target)
{
	var data=System.CreateServiceData(
		"FileService","Zip",{Files:items.join('|'),Target:target}
	);
	System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
			{
				FileSystem.Add(target,ret.NewItemInfo);
				callback(ret.Items)
			}
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}

File.UnZip=function(callback,errorCallback,source,target)
{
	var data=System.CreateServiceData(
		"FileService","UnZip",{Source:source,Target:target}
	);
	System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
			{
				FileSystem.Renew(target,ret.NewItemInfo,true);
				FileSystem.Reset(target,ret.Items);
				callback()
			}
			else
			{
				FileSystem.Renew(target,ret.NewItemInfo,true);
				FileSystem.Reset(target,ret.Items);
				errorCallback(ret.Message);
			}
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}

File.Move=function(callback,errorCallback,items,target)
{
	var data=System.CreateServiceData(
		"FileService","Move",{Items:items.join('|'),Target:target}
	);
	System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
			{
				for(var i in items) FileSystem.Delete(items[i]);
				FileSystem.Reset(target,ret.Items);
				callback();
			}
			else
			{
				for(var i in ret.SuccessItems) FileSystem.Delete(ret.SuccessItems[i]);
				FileSystem.Reset(target,ret.Items);
				errorCallback(ret.Message);
			}
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}

File.Copy=function(callback,errorCallback,items,target)
{
	var data=System.CreateServiceData(
		"FileService","Copy",{Items:items.join('|'),Target:target}
	);
	System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
			{
				FileSystem.Reset(target,ret.Items);
				callback();
			}
			else
			{
				FileSystem.Reset(target,ret.Items);
				errorCallback(ret.Message);
			}
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}

File.Rename=function(callback,errorCallback,path,newName)
{
	var data=System.CreateServiceData(
		"FileService","Rename",{Path:path,NewName:newName}
	);
	System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
			{
				FileSystem.Renew(path,ret.NewItemInfo,false);
				callback();
			}
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}

Module.File=File;
})();

(function(){

function Directory()
{
}

Directory.GetSubDirectories=function(callback,errorCallback,path)
{
	var item=FileSystem.Find(path);
	if(item==null) item=new FileSystemItem(Path.GetFileName(path),path);
	item.Refresh(
		function(items)
		{
			var subDirs=[];
			for(var i in items)
			{
				if(items[i].Type=='D' || items[i].Type=='E') subDirs.push(items[i]);
			}
			callback(subDirs);
		},
		errorCallback
	);
}
Directory.GetSubItems=function(callback,errorCallback,path,useCache)
{
	if(useCache==undefined) useCache=true;
	
	var item=FileSystem.Find(path);
	if(item==null)
	{
		item=new FileSystemItem(Path.GetFileName(path),path);
	}
	item.Refresh(
		function(items)
		{
			if(!useCache) FileSystem.Reset(path,items);
			callback(items);
		},
		errorCallback,
		useCache
	);
}
Directory.Refresh=function(completeCallback,errorCallback,path)
{
	var data = System.CreateServiceData(
		"DirectoryService","GetSubItems",{Path:path}
	);
	
	System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
			{
				FileSystem.Reset(path,ret.Items);
				completeCallback(ret.Items)
			}
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}
Directory.Create=function(callback,errorCallback,path)
{
	var data = System.CreateServiceData(
		"DirectoryService","Create",{Path:path}
	);
	
	System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
			{
				FileSystem.Add(path,ret.NewItemInfo);
				callback();
			}
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}
Directory.CreateProject=function(callback,errorCallback,path,name,content)
{
	var data = System.CreateServiceData(
		"DirectoryService","CreateProject",{Path:path,Name:name,Content:content}
	);
	
	System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
			{
				FileSystem.Add(path+"/"+name,ret.NewItemInfo);
				callback();
			}
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}
Directory.SaveProject=function(callback,errorCallback,path,content,code,css)
{
	var data = System.CreateServiceData(
		"DirectoryService", "SaveProject", { Path: path, Content: content, Code: code, Css: css }
	);
	
	System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
			{
				//FileSystem.Add(path+"/"+name,ret.NewItemInfo);
				callback();
			}
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}
Directory.DeleteItems=function(callback,errorCallback,items)
{
	var data = System.CreateServiceData(
		"DirectoryService","DeleteItems",{Items:items.join('|')}
	);
	
	System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
			{
				for(var i in items) FileSystem.Delete(items[i]);
				callback()
			}
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}
Directory.CreateThumbnailImage=function(callback,errorCallback,path)
{
	var data = System.CreateServiceData(
		"DirectoryService","CreateThumbnailImage",{Path:path}
	);
	
	System.SendCommand(
		function(ret)
		{
			if(ret.Result=="OK")
			{
				callback(ret.ThumbnailImageInfo);
			}
			else
				errorCallback(ret.Message);
		},
		function(error)
		{
			errorCallback(error)
		},
		data
	)
}

Module.Directory=Directory;

})();

function Path()
{
}

Path.GetFileName=function(fullName)
{
	var index=fullName.lastIndexOf("/")
	var name=(index==-1?fullName:fullName.substring(index+1,fullName.length));
	return name;
}

Path.GetFileExtension=function(fullName)
{
	var index=fullName.lastIndexOf(".")
	var ext=(index==-1?"":fullName.substring(index,fullName.length));
	return ext;
}

Path.GetDirectoryName=function(fullName)
{
	var index=fullName.lastIndexOf("/")
	switch(index)
	{
	case -1:
	    return null;
	case 0:
	    return "/";
	default:
	    return fullName.substring(0,index);
	}
}

Path.GetFileNameNoExtention=function(fullName)
{
	var index=fullName.lastIndexOf("/")
	var name=(index==-1?fullName:fullName.substring(index+1,fullName.length));
	index=name.lastIndexOf(".");
	return index==-1?name:name.substring(0,index);
}

Path.Join=function()
{
	var path="";
	for(var i=0;i<arguments.length;i++)
	{
		if(arguments[i]!=undefined && arguments[i]!=null && arguments[i]!="")
		{
			if(path[path.length-1]!='/') path+='/';
			path+=arguments[i];
		}
	}
	return path;
}

Module.Path=Path;

function init(completeCallback,errorCallback)
{
	completeCallback();
}