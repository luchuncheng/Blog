﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Threading;
using System.IO;

/// <summary>
///XmlHttpTest 的摘要说明
/// </summary>
public class XmlHttpTest : IHttpAsyncHandler
{
	public XmlHttpTest()
	{
	}

	static StreamWriter _writer = null;
	HttpContext _context = null;

	IAsyncResult IHttpAsyncHandler.BeginProcessRequest(HttpContext context, AsyncCallback cb, Object extraData)
	{
		_context = context;
		Global.WriteLog(_context, String.Format("{0} Begin", context.Request["ID"]));
		AsyncOperation operation = new AsyncOperation(cb, context, extraData, _writer);
		operation.Process();
		return operation;
	}

	void IHttpAsyncHandler.EndProcessRequest(IAsyncResult result)
	{
		Global.WriteLog(_context, String.Format("{0} End", _context.Request["ID"]));
	}

	void IHttpHandler.ProcessRequest(HttpContext context)
	{
	}

	bool IHttpHandler.IsReusable
	{
		get { return true; }
	}

	private void Process()
	{
	}
}

public class Global
{
	static object _lock = new object();
	static public void WriteLog(HttpContext context, string log)
	{
		lock (_lock)
		{
			StreamWriter _writer = File.AppendText(context.Server.MapPath("~\\Test\\Log.txt"));
			_writer.WriteLine(log);
			_writer.Flush();
			_writer.Close();
		}
	}
}

class AsyncOperation : IAsyncResult
{    
	private bool _completed;
    private Object _state;
    private AsyncCallback _callback;
    private HttpContext _context;
	private StreamWriter _writer;

    bool IAsyncResult.IsCompleted { get { return _completed; } }
    WaitHandle IAsyncResult.AsyncWaitHandle { get { return null; } }
    Object IAsyncResult.AsyncState { get { return _state; } }
    bool IAsyncResult.CompletedSynchronously { get { return false; } }

    public AsyncOperation(AsyncCallback callback, HttpContext context, Object state,StreamWriter writer)
    {
        _callback = callback;
        _context = context;
        _state = state;
        _completed = false;
		_writer = writer;
    }

	public void Process()
	{
		Thread thread = new Thread(new ThreadStart(this.ProcessThreadEntry));
		thread.Start();
	}

	public void ProcessThreadEntry()
	{
#if DEBUG
		Thread.Sleep(20000);
#endif
		Complete();
	}

	public void Complete()
	{
		lock (this)
		{
			if (_context.Response.IsClientConnected)
			{
				Global.WriteLog(_context, String.Format("{0} Complete", _context.Request["ID"]));
				_context.Response.Write("OK");
			}
			else
			{
				Global.WriteLog(_context, String.Format("{0} Client Closed", _context.Request["ID"]));
			}
			_callback(this);
		}
	}
}
