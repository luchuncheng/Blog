﻿
//Window
var moveVar=null;
var resizeVar=null;

function body_onmousemove(evt)
{
	if(moveVar!=null)
	{
		moveVar.NewLeft = moveVar.Left+(evt.clientX-moveVar.MouseLeft);
		moveVar.NewTop = moveVar.Top+(evt.clientY-moveVar.MouseTop);
		displayWindowBorder(moveVar.NewLeft,moveVar.NewTop);
	}
	else if(resizeVar!=null)
	{
		var diffX=evt.clientX-resizeVar.MouseLeft
		var diffY=evt.clientY-resizeVar.MouseTop
		switch(resizeVar.Type)
		{
		case 0:
			resizeVar.NewWidth=resizeVar.Width-diffX;
			resizeVar.NewHeight=resizeVar.Height-diffY;
			resizeVar.NewLeft=resizeVar.Left+diffX;
			resizeVar.NewTop=resizeVar.Top+diffY;
			break;
		case 1:
			resizeVar.NewHeight=resizeVar.Height-diffY;
			resizeVar.NewTop=resizeVar.Top+diffY;
			break;
		case 2:
			resizeVar.NewWidth=resizeVar.Width+diffX;
			resizeVar.NewHeight=resizeVar.Height-diffY;
			resizeVar.NewTop=resizeVar.Top+diffY;
			break;
		case 3:
			resizeVar.NewWidth=resizeVar.Width-diffX;
			resizeVar.NewLeft=resizeVar.Left+diffX;
			break;
		case 5:
			resizeVar.NewWidth=resizeVar.Width+diffX;
			break;
		case 6:
			resizeVar.NewWidth=resizeVar.Width-diffX;
			resizeVar.NewHeight=resizeVar.Height+diffY;
			resizeVar.NewLeft=resizeVar.Left+diffX;
			break;
		case 7:
			resizeVar.NewHeight=resizeVar.Height+diffY;
			break;
		case 8:
			resizeVar.NewHeight=resizeVar.Height+diffY;
			resizeVar.NewWidth=resizeVar.Width+diffX;
			break;
		}
		
		if(resizeVar.NewWidth<resizeVar.MinWidth) resizeVar.NewWidth=resizeVar.MinWidth;
		if(resizeVar.NewHeight<resizeVar.MinHeight) resizeVar.NewHeight=resizeVar.MinHeight;
		
		displayWindowBorder(resizeVar.NewLeft,resizeVar.NewTop,resizeVar.NewWidth,resizeVar.NewHeight);
	}
}

function body_onmouseup(evt)
{
	if(moveVar!=null)
	{
		hideWindowBorder();
		moveVar.Window.move('',moveVar.NewLeft,moveVar.NewTop);
		delete moveVar;
		moveVar=null;
		enableSelect();
	}
	else if(resizeVar!=null)
	{
		hideWindowBorder();
		resizeVar.Window.move('',resizeVar.NewLeft,resizeVar.NewTop);
		resizeVar.Window.resize(resizeVar.NewWidth,resizeVar.NewHeight);
		delete resizeVar;
		resizeVar=null;
		enableSelect();
	}
}

if(document.attachEvent)
{
	document.attachEvent(
		"onmousemove",
		function(evt)
		{
			if(evt==null) evt=window.event;
			body_onmousemove(evt);
		}
	);
	document.attachEvent(
		"onmouseup",
		function(evt)
		{
			if(evt==null) evt=window.event;
			body_onmouseup(evt);
		}
	);
}
else if(document.addEventListener)
{
	document.addEventListener(
		"mousemove",
		function(evt)
		{
			if(evt==null) evt=window.event;
			return body_onmousemove(evt);
		},
		false
	)
	document.addEventListener(
		"mouseup",
		function(evt)
		{
			if(evt==null) evt=window.event;
			return body_onmouseup(evt);
		},
		false
	)
}

/*
config={
	Width:宽度,
	Height:高度,
	Left:
	Top:
	Css:样式,
	BorderWidth:边框宽度,
	Resizable:是否可调整大小,
	Title:{
		Height:高度
		InnerHTML:内容
	},
	Content:{
		InnerHTML:内容
	}
}
*/

function Window(config)
{
	if(!appendWindowBorder)
	{
		appendWindowBorder=true;
		document.body.appendChild(windowBorder);
	}
		
	var This=this;
	//
	var id="login_window";
	
	//私有方法
	//公共方法
	This.show=function(isTop)
	{
		container.style.display='block';
		if(isTop) setTopWindow(This);
	}
	This.hide=function()
	{
		container.style.display='none';
		This.onhided.call(This);
	}
	This.close=function()
	{
		var ret=This.onclosing.call(This);
		if(ret==null || ret)
		{
			if(parent!=null) 
				parent.container().removeChild(container);
			else
				document.body.removeChild(container);
			This.onclosed.call(This);
			delete This;
		}
	}
	This.isVisible=function()
	{
		return container.style.display!='none';
	}
	This.isTop=function()
	{
		return setTopVar.Window==This;
	}
	//移动窗口
	This.move=function(position,x,y)
	{
		position=position.toUpperCase();
		
		var align;
		var verticalAlign;
		
		if(position=='CENTER')
		{
			align="MIDDLE";
			verticalAlign="MIDDLE";
		}
		else
		{
			var ps=position.split("|");
			align=ps.length>0?ps[0]:"NULL";
			verticalAlign=ps.length>1?ps[1]:"NULL";
		}
		
		switch(align)
		{
		case "LEFT":
			left=0;
			break;
		case "RIGHT":
			left=document.documentElement.clientWidth-width;
			break;
		case "MIDDLE":
			left=Math.round((document.documentElement.clientWidth-width)/2);
			break;
		default:
			left=0;
		}
		left+=x;
		
		switch(verticalAlign)
		{
		case "TOP":
			top=0;
			break;
		case "BOTTOM":
			top=document.documentElement.clientHeight-height;
			break;
		case "MIDDLE":
			top=Math.round((document.documentElement.clientHeight-height)/2);
			break;
		default:
			top=0;
		}
		top+=y;
		
		if(dom.style.position!="fixed")
		{
			var scrollLeft=document.body.scrollLeft+document.documentElement.scrollLeft;
			var scrollTop=document.body.scrollTop+document.documentElement.scrollTop;
			left+=scrollLeft;
			top+=scrollTop;
		}
		
		if(left<0) left=0;
		if(top<0) top=0;
		
		dom.style.left=left+'px';
		dom.style.top=top+'px';
	}
	This.resize=function(newWidth,newHeight)
	{
		width=newWidth;
		height=newHeight;
			
		dom.style.width=width+'px';
		dom.style.height=height+'px';
		dom.style.margin="0px";
		dom.style.padding="0px";
		
		var ws=[borderWidth,width-borderWidth*2,borderWidth]
		var hs=[borderWidth,height-borderWidth*2,borderWidth]
		for(var y=0;y<=2;y++)
		{
			for(var x=0;x<=2;x++)
			{
				var i=y*3+x;
				dom.childNodes[i].style.width=ws[x]+'px';
				dom.childNodes[i].style.height=hs[y]+'px';
				dom.childNodes[i].style.margin="0px";
				dom.childNodes[i].style.padding="0px";
				if(i!=4)
				{
					dom.childNodes[i].style.fontSize="2px";
					if(dom.childNodes[i].style.MozUserSelect!=undefined)
						dom.childNodes[i].style.MozUserSelect="none";
				}
			}
		}
		
		domTitle.style.width=ws[1]+'px';
		domTitle.style.height=title.Height+'px';
		domTitle.style.margin="0px";
		domTitle.style.padding="0px"; 
		domTitle.style.borderWidth="0px";
					
		domClient.style.left=ws[0]+'px';
		domClient.style.top=hs[0]+title.Height+'px';
		domClient.style.width=(ws[1]-2)+'px';
		domClient.style.height=(hs[1]-title.Height-2)+'px';
		domClient.style.margin="0px";
		domClient.style.padding="0px";
		domClient.style.borderWidth="1px";
					
		domLoading.style.left=ws[0]+'px';
		domLoading.style.top=hs[0]+title.Height+'px';
		domLoading.style.width=(ws[1]-2)+'px';
		domLoading.style.height=(hs[1]-title.Height-2)+'px';
		domLoading.style.margin="0px";
		domLoading.style.padding="0px";
		domLoading.style.borderWidth="1px";
		
		This.onresized.call(This);
	}
	This.zIndex=function(newIndex)
	{
		if(newIndex!=undefined)
		{	
			if(parent!=null) parent.zIndex(newIndex);else container.style.zIndex=newIndex;
		}
		return parent!=null?parent.zIndex():container.style.zIndex;
	}
	This.container=function()
	{
		return container;
	}
	
	This.content=function(newContent)
	{
		if(newContent!=undefined)
		{
			if(domClient.firstChild!=null) domClient.removeChild(domClient.firstChild);
			domClient.appendChild(newContent);
		}
		return domClient.firstChild;
	}
	This.title=function(newTitle)
	{
		if(newTitle!=undefined)
		{
			domTitle.childNodes[1].innerHTML=newTitle;
		}
		return domTitle.childNodes[1].innerHTML;
	}
		
	This.disable=function()
	{
		disableLayer.style.width=dom.style.width;
		disableLayer.style.height=dom.style.height;
		disableLayer.style.left='0px';
		disableLayer.style.top='0px';
		disableLayer.style.display='block';
	}
	This.enable=function()
	{
		disableLayer.style.display='none';
	}
	
	This.isDisabled=function()
	{
		return disableLayer.style.display=='block';
	}
	
	This.waiting=function()
	{
		//domClient.style.display='none';
		domLoading.style.display='block';
	}
	
	This.completed=function()
	{
		domLoading.style.display='none';
		//domClient.style.display='block';
	}
	This.dom=function()
	{
		return dom;
	}
	
	This.width=function(){return width;}
	This.height=function(){return height;}
	This.clientWidth=function(){return width-borderWidth*2-2;}
	This.clientHeight=function(){return height-title.Height-borderWidth*2-2;}
	
	This.onclosed=new Delegate();
	This.onhided=new Delegate();
	This.onclosing=new Delegate();
	This.onresized=new Delegate();
	
	//======================================================================
	//初始化
	//读取配置
	var width=400,height=300,left=0,top=0,css='',borderWidth=6,resizable=true,parent,container,hasMinButton=true;
	var title={Height:18,InnerHTML:""};
	var content={InnerHTML:""};
	var topContainer=null;
	if(config.Parent!=undefined && config.Parent!=null)
	{
		parent=config.Parent;
	}
	else
	{
		parent=null;
	}
	container=document.createElement('DIV');
	container.style.position="fixed";
	container.style.zIndex='0';
	container.style.left="0px";
	container.style.top="0px";
	
	if(config.Width!=undefined) width=config.Width;
	if(config.Height!=undefined) height=config.Height;
	if(config.Left!=undefined) left=config.Left;
	if(config.Top!=undefined) top=config.Top;
	if(config.Css!=undefined) css=config.Css;
	if(config.BorderWidth!=undefined) borderWidth=config.BorderWidth;
	if(config.Resizable!=undefined) resizable=config.Resizable;
	if(config.HasMinButton!=undefined) hasMinButton=config.HasMinButton;
	if(config.Title!=undefined)
	{
		if(config.Title.Height!=undefined) title.Height=config.Title.Height;
		if(config.Title.InnerHTML!=undefined) title.InnerHTML=config.Title.InnerHTML;
	}
	if(config.Content!=undefined)
	{
		if(config.Content.InnerHTML!=undefined) content.InnerHTML=config.Content.InnerHTML;
	}
	//DOM
	var dom=document.createElement("DIV");
	dom.id=id;
	dom.className=css;
	dom.style.position="absolute";
	dom.tabIndex=-1;
	dom.innerHTML=(
		"<div class='border_nw' style='float:left; cursor:nw-resize; z-index:0;'></div>"+
		"<div class='border_n' style='float:left; cursor:n-resize; z-index:0;'></div>"+
		"<div class='border_ne' style='float:left; cursor:ne-resize; z-index:0;'></div>"+
		"<div class='border_w' style='float:left; cursor:w-resize; z-index:0;'></div>"+
		"<div style='float:left; cursor:-resize; z-index:0;'>"+
			"<div class='title'>"+
				"<div class='icon' style='float:left;'></div>"+
				"<div class='text' style='float:left;'></div>"+
				"<div class='closeButton' style='float:right;'></div>"+
				"<div class='minButton' style='float:right;'></div>"+
				"<div class='custom' id='{ID}_Custom'></div>"+
			"</div>"+
			"<div class='content' style='position:absolute;'></div>"+
			"<div class='waiting' style='position:absolute;display:none;'></div>"+
		"</div>"+
		"<div class='border_e' style='float:left; cursor:e-resize; z-index:0;'></div>"+
		"<div class='border_sw' style='float:left; cursor:sw-resize; z-index:0;'></div>"+
		"<div class='border_s' style='float:left; cursor:s-resize; z-index:0;'></div>"+
		"<div class='border_se' style='float:left; cursor:se-resize; z-index:0;'></div>"+
		"<div style='position:absolute;display:none;' class='disabled'></div>"
	).replace(/{ID}/g,id);
	
	var domTitle=dom.childNodes[4].childNodes[0];
	var domClient=dom.childNodes[4].childNodes[1];
	var domLoading=dom.childNodes[4].childNodes[2];
	var closeBtn=domTitle.childNodes[2];
	var minBtn=domTitle.childNodes[3];
	var disableLayer=dom.childNodes[9];
	
	closeBtn.style.display="none";
	minBtn.style.display="none";
	
	container.style.display='none';
	
	dom.onclick=function()
	{
		setTopWindow(This);
	}
	
	domTitle.onmousedown=function(evt)
	{
		if(evt==undefined) evt=event;
		var target=null;
		if(evt.srcElement!=undefined) target=evt.srcElement;
		if(evt.target!=undefined) target=evt.target;
		if(target!=closeBtn && target!=minBtn)
		{
			moveVar={
				Window:This,
				MouseLeft:evt.clientX,
				MouseTop:evt.clientY,
				ScrollLeft:document.documentElement.scrollLeft,
				ScrollTop:document.documentElement.scrollTop,
				Left:left,
				Top:top,
				NewLeft:left,
				NewTop:top
			}
			
			displayWindowBorder(left,top,width,height);
			disableSelect();
			setTopWindow(This);
		}
	}
					
	for(var i=0;i<=8;i++)
	{
		if(i!=4)
		{
			(function(rbs_type)
			{
				dom.childNodes[i].onmousedown=function(evt)
				{
					if(resizable)
					{
						if(evt==null) evt=window.event;
						resizeVar={
							Left:left,
							Top:top,
							NewLeft:left,
							NewTop:top,
							Width:width,
							Height:height,
							NewWidth:width,
							NewHeight:height,
							MouseLeft:evt.clientX,
							MouseTop:evt.clientY,
							Type:rbs_type,
							MinWidth:200,
							MinHeight:100,
							Window:This
						}
						displayWindowBorder(left,top,width,height);
						disableSelect();
						setTopWindow(This);
					}
				};
			})(i);
		}
	}
	closeBtn.onclick=function(evt)
	{
		if(evt==undefined) evt=event;
		This.close();
		return true;
	}
	minBtn.onclick=function(evt)
	{
		if(evt==undefined) evt=event;
		This.hide();
		return true;
	}
	domClient.innerHTML=content.InnerHTML;
	domTitle.childNodes[1].innerHTML=title.InnerHTML;
	This.move('',left,top)
	This.resize(width,height);
	
	container.appendChild(dom);
	if(parent!=null) parent.container().appendChild(container);
	else document.body.appendChild(container);
}

function isNull(val,alt)
{
	return (val==undefined || val==null)?alt:val;
}

function displayWindowBorder(left,top,width,height)
{
	if(left!=undefined && top!=undefined)
	{
		if(windowBorder.style.position=="fixed")
		{
			windowBorder.style.left=left+"px";
			windowBorder.style.top=top+"px";
		}
		else
		{
			var scrollLeft=document.body.scrollLeft+document.documentElement.scrollLeft;
			var scrollTop=document.body.scrollTop+document.documentElement.scrollTop;
			windowBorder.style.left=(scrollLeft+left)+"px";
			windowBorder.style.top=(scrollTop+top)+"px";
		}
	}
	if(width!=undefined) windowBorder.style.width=(width-8)+"px";
	if(height!=undefined) windowBorder.style.height=(height-8)+"px";
	windowBorder.style.display='block';
}

	
var windowBorder=document.createElement("DIV");
var appendWindowBorder=false;
windowBorder.style.position="absolute";
windowBorder.style.display='none';
windowBorder.style.zIndex='6000';
windowBorder.style.borderStyle="solid";
windowBorder.style.borderColor="#666666";
windowBorder.style.borderWidth='4px';

function hideWindowBorder()
{
	windowBorder.style.display='none'
}


var setTopVar={
	Window:null,
	PreZIndex:null
}

function setTopWindow(win)
{
	if(setTopVar.Window!=null)
	{
		setTopVar.Window.zIndex(setTopVar.PreZIndex);
	}
	setTopVar.PreZIndex=win.zIndex();
	setTopVar.Window=win;
	win.zIndex(3000);
}


var pre_onselectstart=null;
var pre_MozUserSelect=null;

function disableSelect()
{
	if(pre_onselectstart==null) pre_onselectstart=document.onselectstart;
	if(pre_MozUserSelect==null) pre_MozUserSelect=document.body.style.MozUserSelect;
	document.onselectstart=function(){return false;}
	document.body.style.MozUserSelect='none';
}

function enableSelect()
{
	if(document.onselectstart!=undefined) document.onselectstart=pre_onselectstart;
	if(document.body.style.MozUserSelect!=undefined) document.body.style.MozUserSelect=pre_MozUserSelect;
	pre_onselectstart=null;
	pre_MozUserSelect=null;
}

function resize(dom,width,height)
{
	dom.style.width=width+'px';
	dom.style.height=height+'px';
}

function isNull(val,alt)
{
	return (val==undefined || val==null?alt:val);
}

function Delegate()
{
	var all=[];
	
	var This=this;
	
	This.call=function()
	{
		var ret=null;
		for(var index in all)
		{
			ret=all[index].apply(This,arguments);
		}
		return ret;
	}
	
	This.attach=function(func)
	{
		all.push(func);
	}
	
	This.Detach=function(func)
	{
		var index=0;
		for(index in all) 
		{
			if(all[index]==func) break;
		}
		if(index<all.length)
		{
			delete all[index];
			all.splice(index,1);
		}
	}
}