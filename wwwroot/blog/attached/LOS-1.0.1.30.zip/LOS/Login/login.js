﻿
function GetParams()
{
    var pairs=window.location.search.substr(1,window.location.search.length-1).split("&");
    var params={};
    for(var i in pairs)
    {
        var vs=pairs[i].split("=");
        params[vs[0]]=vs[1];
    }
    return params;
}	

var Params=GetParams();
var VerifyCode="",VerifyCodeGuid="";

function match(reg,str)
{
    reg.lastIndex=0;
    var ft = reg.exec(str);
    return (ft!=null && ft.length==1 && ft[0]==str) 
}

String.format=function(fmt)
{
    var params=arguments;
    var pattern=/{{|{[1-9][0-9]*}|\x7B0\x7D/g;
    return fmt.replace(
	    pattern,
	    function(p)
	    {
		    if(p=="{{") return "{";
		    return params[parseInt(p.substr(1,p.length-2),10)+1]
	    }
    );
}

function Register(data,onsuccess,onerror)
{
	var request = null;
    
	if(window.XMLHttpRequest) 
	{
		request=new XMLHttpRequest();
	}
	else if(window.ActiveXObject) 
	{
		request=new ActiveXObject("Microsoft.XMLHttp");
	}
	
	request.onreadystatechange=function()
	{
		if(request.readyState==4)
		{
			try
			{
				switch(request.status)
				{
				case 200:
					{
					    var ret=eval(request.responseText);
					    if(ret.IsSucceed)
						    onsuccess(ret.Data);
						else
						    onerror(ret.Data);
						break;
					}
				default:
					{
						onerror(request.statusText);
						break;
					}
				}
			}
			catch(ex)
			{
				onerror(ex.message);
			}
		}
	}
	
	request.open("POST","register.aspx",true);
	request.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	request.send(data);
}

function LoginWindow()
{
	var config={
		Css:'window',
		BorderWidth:6,
		Resizable:false,
		Title:{
			Height:18,
			InnerHTML:'登录'
		},
		Content:{
			InnerHTML:""
		},
		HasMinButton:false
	}
	
	Window.call(this,config);
	
	this.dom().style.background="url(Login/image.gif) no-repeat 0px -600px";
	
	var content=document.createElement("DIV");
	content.className='login';
	content.innerHTML=
		'<table class="login_table" cellpadding="0" cellspacing="0">'+
			'<tr>'+
				'<td class="td_left">用户名：</td>'+
				'<td class="td_right"><input class="text" type="text" /></td>'+
			'</tr>'+
			'<tr>'+
				'<td class="td_left">密码：</td>'+
				'<td class="td_right"><input class="text" type="password" /></td>'+
			'</tr>'+
			'<tr>'+
				'<td class="td_left">选项：</td>'+
				'<td class="td_right"><table><tr><td style="vertical-align:middle"><input type="checkbox" CHECKED/></td><td style="vertical-align:middle;font-size:14px; color:#15428B;">桌面模式</td><td style="width:20px;"></td><td style="vertical-align:middle"><input type="checkbox" /></td><td style="vertical-align:middle;font-size:14px; color:#15428B;">记住登陆状态</td></tr></table></td>'+
			'</tr>'+
			'<tr>'+
				'<td class="td_left" style="border-top:solid 1px #DBDCDE;"></td>'+
				'<td class="td_right" style="border-top:solid 1px #DBDCDE;"><div class="btnLogin"></div><div class="btnRegister"></div></td>'+
			'</tr>'+
		'</table>'

	var txtUserName = content.firstChild.rows[0].cells[1].firstChild;
	var txtPassword = content.firstChild.rows[1].cells[1].firstChild;
	var btnLogin = content.firstChild.rows[3].cells[1].childNodes[0];
	var btnRegister = content.firstChild.rows[3].cells[1].childNodes[1];
	var checkMode = content.firstChild.rows[2].cells[1].firstChild.rows[0].cells[0].firstChild;
	var checkRem = content.firstChild.rows[2].cells[1].firstChild.rows[0].cells[3].firstChild;

	btnLogin.onclick = function()
	{
		var nameReg = /[a-zA-Z0-9_]+/ig;
		var pwdReg = /[a-zA-Z0-9]+/ig;

		if (txtUserName.value == "")
		{
			alert("用户名不能为空！");
			return;
		}
		if (txtUserName.value.length < 4 || !match(nameReg, txtUserName.value))
		{
			alert("用户名格式错误！");
			return;
		}
		if (txtPassword.value == "")
		{
			alert("密码不能为空！");
			return;
		}
		document.getElementById("UserName").value = txtUserName.value;
		document.getElementById("Password").value = txtPassword.value;
		document.getElementById("Command").value = "Login";
		document.getElementById("Mode").value = checkMode.checked ? "1" : "0";
		document.getElementById("Rem").value = checkRem.checked ? "1" : "0";
		document.getElementById("form1").submit();
	}
	
	btnRegister.onclick=function()
	{
	    loginWindow.hide();
	    registerWindow.move('CENTER',0,-100);
	    registerWindow.show(true);
	}
			
	this.content(content);
    
    var preShow=this.show
    this.show=function(isTop)
    {
	    document.onkeypress=function(evt)
	    {
	        if(evt==undefined) evt=event;
	        if(evt.keyCode==13)
	        {
	           btnLogin.onclick();
	        }
	    }
        preShow(isTop);
        txtUserName.focus();
    }
}

function RegisterWindow()
{
    var This=this;
	var config={
		Css:'window',
		BorderWidth:6,
		Resizable:false,
		Title:{
			Height:18,
			InnerHTML:'注册'
		},
		Content:{
			InnerHTML:""
		},
		HasMinButton:false
	}
	
	Window.call(this,config);
	
	this.dom().style.background="url(Login/image.gif) no-repeat 0px -175px";
	
	var content=document.createElement("DIV");
	content.className='register';
	content.innerHTML=
		'<table cellpadding="0" cellspacing="0">'+
			'<tr>'+
				'<td class="td_left">用户名：</td>'+
				'<td class="td_right"><input class="text" type="text" /></td>'+
			'</tr>'+
			'<tr>'+
				'<td class="td_left">昵称：</td>'+
				'<td class="td_right"><input class="text" type="text" /></td>'+
			'</tr>'+
			'<tr>'+
				'<td class="td_left">密码：</td>'+
				'<td class="td_right"><input class="text" type="password" /></td>'+
			'</tr>'+
			'<tr>'+
				'<td class="td_left">密码确认：</td>'+
				'<td class="td_right"><input class="text" type="password" /></td>'+
			'</tr>'+
			'<tr>'+
				'<td class="td_left">电子邮箱：</td>'+
				'<td class="td_right"><input class="text" type="text"/></td>'+
			'</tr>'+
			'<tr>'+
				'<td class="td_left">验证码：</td>'+
				'<td class="td_right"><input class="text" type="text"/></td>'+
			'</tr>'+
			'<tr>'+
				'<td class="td_left"></td>'+
				'<td class="td_right"><div style="float:left;"><img title="点击刷新验证码" style="width:76px;height:26px;cursor:pointer;"/></div><div class="btnOK"></div><div class="btnCancel"></div></td>'+
			'</tr>'+
		'</table>'
		
	var txtName=content.firstChild.rows[0].cells[1].firstChild;
	var txtNickname=content.firstChild.rows[1].cells[1].firstChild;
	var txtPassword=content.firstChild.rows[2].cells[1].firstChild;
	var txtPwdConfirm=content.firstChild.rows[3].cells[1].firstChild;
	var txtEMail=content.firstChild.rows[4].cells[1].firstChild;
	var txtVerifyCode=content.firstChild.rows[5].cells[1].firstChild;
	var imgVerifyCode=content.firstChild.rows[6].cells[1].childNodes[0].childNodes[0];
	var btnOK=content.firstChild.rows[6].cells[1].childNodes[1];
	var btnCancel=content.firstChild.rows[6].cells[1].childNodes[2];
	
	imgVerifyCode.onclick=function()
	{
	    RefreshVerifyCode();
	}

    function RefreshVerifyCode()
    {
	    This.waiting();
	    try
	    {
	        var request = null;
	        if(window.XMLHttpRequest) 
	        {
		        request=new XMLHttpRequest();
	        }
	        else if(window.ActiveXObject) 
	        {
		        request=new ActiveXObject("Microsoft.XMLHttp");
	        }
    		
	        request.onreadystatechange=function()
	        {
		        if(request.readyState==4)
		        {
			        switch(request.status)
			        {
			        case 200:
				        {
				            var ret=eval(request.responseText);
				            imgVerifyCode.src="VerifyCode/"+ret.Guid+".png?"+(new Date()-new Date(2009,0,1));
				            VerifyCodeGuid=ret.Guid;
					        break;
				        }
			        }
	                This.completed();
		        }
	        }
    		
	        request.open("POST","VerifyCode.aspx",true);
	        request.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	        request.send("Guid="+VerifyCodeGuid);
	    }
	    catch(ex)
	    {
	        This.completed();
	    }
    }
	
	btnOK.onclick=function()
	{
	    var nameReg=/[a-zA-Z0-9_]+/ig;
	    var pwdReg=/[a-zA-Z0-9]+/ig;
	    
	    if(!match(nameReg,txtName.value))
	    {
	        alert("用户名格式不正确（用户名只能包含英文字符，数字和下划线）！");
	        return;
	    }
	    if(txtName.value.length<4)
	    {
	        alert("用户名必须4个字符以上！");
	        return;
	    }
	    if(txtNickname.value=="")
	    {
	        alert("昵称不能为空！");
	        return;
	    }
	    if(!match(pwdReg,txtPassword.value))
	    {
	        alert("密码格式不正确（密码只能包含英文字符和数字）！");
	        return;
	    }
	    if(txtPassword.value.length<4)
	    {
	        alert("密码必须4个字符以上！");
	        return;
	    }
	    if(txtPassword.value!=txtPwdConfirm.value)
	    {
	        alert("两次输入的密码不匹配！");
	        return;
	    }
	    if(txtEMail.value=="")
	    {
	        alert("电子邮箱不能为空！");
	        return;
	    }
	    if(txtVerifyCode.value=="")
	    {
	        alert("验证码不能为空！");
	        return;
	    }
	    This.waiting();
	    Register(
	        String.format(
	            "Name={0}&Nickname={1}&Password={2}&VerifyCodeGuid={3}&VerifyCode={4}&EMail={5}",
	            txtName.value,txtNickname.value,txtPassword.value,VerifyCodeGuid,txtVerifyCode.value,txtEMail.value
	        ),
	        function()
			{
	    		document.getElementById("UserName").value = txtName.value;
	    		document.getElementById("Password").value = txtPassword.value;
	    		document.getElementById("Command").value = "Login";
	    		document.getElementById("Mode").value = "1";
	    		document.getElementById("form1").submit();
	        },
	        function(msg)
	        {
	            alert(msg);
	            This.completed();
	            RefreshVerifyCode();
	        }
	    );
	}
	
	btnCancel.onclick=function()
	{
	    registerWindow.hide();
	    loginWindow.move('CENTER',0,-100);
	    loginWindow.show(true);
	}
	
	this.content(content);
    
    var preShow=this.show
    this.show=function(isTop)
    {
	    document.onkeypress=function(evt)
	    {
	        if(evt==undefined) evt=event;
	        if(evt.keyCode==13) btnOK.onclick();
	    }
        preShow(isTop);
        RefreshVerifyCode();
        txtName.focus();
    }
}

function InformationWindow()
{
    var This=this;
	var config={
		Css:'window',
		BorderWidth:6,
		Resizable:false,
		Title:{
			Height:18,
			InnerHTML:'提示'
		},
		Content:{
			InnerHTML:""
		},
		HasMinButton:false
	}
	
	Window.call(this,config);
	
	this.dom().style.background="url(Login/image.gif) no-repeat 0px -175px";
	
	var content=document.createElement("DIV");
	content.className='information';
	content.innerHTML=
		'<table cellpadding="0" cellspacing="0">'+
			'<tr style = "height: 170px;">'+
				'<td><div class="text"></div></td>'+
			'</tr>'+
			'<tr>'+
				'<td class="td_right"><div class="btnTemp"></div><div class="btnLogin"></div><div class="btnRegister"></div></td>'+
			'</tr>'+
		'</table>';
	
	this.content(content);
	
	content.firstChild.rows[0].cells[0].childNodes[0].innerHTML = String.format(
		"您已接受 <span class='user'>{0}</span> 的邀请，系统即将启动与 <span class='user'>{0}</span> 的会话，请选择您要执行的操作：<br/>"+
		"1. 注册一个新帐号。<br/>"+
		"2. 使用已经注册的帐号登录。<br/>"+
		"3. 创建一个临时用户（关闭浏览器后，所有聊天记录和数<br/>&nbsp;&nbsp;&nbsp;据将被删除）。<br/>",
		unescape(Params["Nickname"])
	);
	
	var btnRegister=content.firstChild.rows[1].cells[0].childNodes[2];
	var btnLogin=content.firstChild.rows[1].cells[0].childNodes[1];
	var btnTemp=content.firstChild.rows[1].cells[0].childNodes[0];

	btnRegister.onclick = function()
	{
		This.close();
		registerWindow.show(true);
	}

	btnLogin.onclick = function()
	{
		This.close();
		loginWindow.show(true);
	}

	btnTemp.onclick = function()
	{
		document.getElementById("Command").value = "CreateTempraryUser";
		document.getElementById("UserName").value = Params["User"];
		document.getElementById("form1").submit();
	}
    
    var preShow=this.show
    this.show=function(isTop)
    {
	    document.onkeypress=function(evt)
	    {
	        if(evt==undefined) evt=event;
	        if(evt.keyCode==13) btnTemp.onclick();
	    }
        preShow(isTop);
    }
}

var loginWindow=null,registerWindow=null,infoWindow = null;