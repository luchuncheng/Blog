﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Web;
using System.Xml;
using Core;
using Core.IO;
using System.Data;
using System.Web.Security;

namespace Core.Web
{
	class ManagementService : Service
	{
		HttpContext _context = null;

		public ManagementService(HttpContext context, XmlElement data, String sessionId)
			: base(context, data, sessionId)
		{
			_context = context;
		}

		public override String Process()
		{
			switch (Data.GetAttribute("Command"))
			{
			case "GetUserInfo":
				{
					string name = GetParam("Name");
					return GetUserInfo(name);
				}
			case "UpdateUserInfo":
				{
					string name = GetParam("Name");
					Hashtable values = Utility.ParseJson(GetParam("Values")) as Hashtable;
					return UpdateUserInfo(name, values);
				}
			case "CreateGroup":
				{
					string name = GetParam("Name");
					string nickName = GetParam("Nickname");
					return CreateGroup(name, nickName);
				}
			case "AddFriend":
				{
					string peer = GetParam("Peer");
					string msgId = GetParam("MessageID");
					return AddFriend(peer, msgId);
                }
            case "AddToGroup":
                {
                    string peer = GetParam("Peer");
                    string group = GetParam("Group");
                    string msgId = GetParam("MessageID");
                    return AddToGroup(peer, group, msgId);
				}
			case "DeleteGroup":
				{
					string name = GetParam("Name");
					return DeleteGroup(name);
				}
			case "DeleteFriend":
				{
					string peer = GetParam("Peer");
					return DeleteFriend(peer);
				}
			case "RemoveFromGroup":
				{
					string group = GetParam("Group");
					string member = GetParam("Member");
					return RemoveFromGroup(group, member);
				}
			case "Logout":
				{
					return Logout();
				}
			case "SendAddFriendRequest":
				{
					string peer = GetParam("Peer");
					string verifyInfo = GetParam("VerifyInfo");
					return SendAddFriendRequest(peer, verifyInfo);
				}
			case "UpdateInviteCode":
				{
					string name = GetParam("Name");
					return UpdateInviteCode(name);
				}
			default:
				{
					throw new Exception("Unknown Command!");
				}
			}
		}

		public string UpdateUserInfo(string name, Hashtable values)
		{
			AccountInfo info = AccountManagement.Instance.GetUserInfo(name);
			if (info.Type == 0 && String.Compare(name, UserName, true) == 0 ||
				info.Type == 1 && info.IsCreatedBy(UserName))
			{
				AccountManagement.Instance.UpdateUserInfo(name, values);
			}
			else
			{
				throw new Exception("您没有权限执行此操作！");
			}

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"Return", info
			);
		}

		public string CreateGroup(string name,string nickName)
		{
			AccountManagement.Instance.CreateGroup(UserName, name, nickName);

			return Utility.RenderHashJson(
				Context,
				"Result", "OK"
			);
		}

		public string GetUserInfo(string name)
		{
			AccountInfo userInfo = AccountManagement.Instance.GetUserInfo(name);
			if (userInfo.Type == 0 && String.Compare(name, UserName, true) == 0 ||
				userInfo.Type == 1 && userInfo.ContainsMember(UserName))
			{

				return Utility.RenderHashJson(
					Context,
					"Result", "OK",
					"Return", userInfo
				);
			}
			else
			{
				throw new Exception("您没有权限执行该操作！");
			}
		}

		public string UpdateInviteCode(string name)
		{
			AccountInfo userInfo = AccountManagement.Instance.GetUserInfo(name);
			if ((userInfo.Type == 0 && String.Compare(name, UserName, true) == 0) ||
				(userInfo.Type == 1 && userInfo.IsCreatedBy(UserName)))
			{
				String newCode = Guid.NewGuid().ToString().ToUpper().Replace("-", "");
				AccountManagement.Instance.UpdateInviteCode(name, newCode);

				return Utility.RenderHashJson(
					Context,
					"Result", "OK",
					"Return", newCode
				);
			}
			else
			{
				throw new Exception("您没有权限执行该操作！");
			}
		}

		public string GetFriends()
		{
			AccountInfo userInfo = AccountManagement.Instance.GetUserInfo(UserName);
			string[] fs = userInfo.Friends;

			AccountInfo[] infos = new AccountInfo[fs.Length];
			for (int i = 0; i < fs.Length; i++)
			{
				infos[i] = AccountManagement.Instance.GetUserInfo(fs[i]);
			}

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"Return", infos
			);
		}

		public string AddFriend(string peer,string msgId)
		{
			AccountManagement.Instance.AddFriend(UserName, peer, Int32.Parse(msgId));

			return GetFriends();
        }

        public string AddToGroup(string peer, string group, string msgId)
        {
            AccountInfo groupInfo = AccountManagement.Instance.GetUserInfo(group);
            if (!groupInfo.IsCreatedBy(UserName)) throw new Exception("您没有权限执行该操作！");
            AccountManagement.Instance.AddFriend(group, peer, Int32.Parse(msgId));

            return GetFriends();
        }

		public string DeleteFriend(string peer)
		{
            AccountInfo peerInfo = AccountManagement.Instance.GetUserInfo(peer);

            if (String.Compare(peer, "administrator", true) == 0) throw new Exception("不能删除系统管理员！");
            if (peerInfo.Type == 1 && peerInfo.IsCreatedBy(UserName)) throw new Exception("不能退出自己创建的群！");

			AccountManagement.Instance.DeleteFriend(UserName, peer);

			return GetFriends();
		}

		public string DeleteGroup(string group)
		{
			AccountInfo groupInfo = AccountManagement.Instance.GetUserInfo(group);

			if (groupInfo.Type == 1 && groupInfo.IsCreatedBy(UserName))
			{
				AccountManagement.Instance.DeleteGroup(group, UserName);
			}
			else
			{
				throw new Exception("不能退出自己创建的群！");
			}

			return GetFriends();
		}

		public string RemoveFromGroup(string group, string member)
		{
			AccountInfo groupInfo = AccountManagement.Instance.GetUserInfo(group);
			AccountInfo userInfo = AccountManagement.Instance.GetUserInfo(UserName);
			if (groupInfo.Type == 1 && groupInfo.IsCreatedBy(UserName))
			{
				if (String.Compare(member, UserName, true) == 0) throw new Exception("不能移除群的创建者！");

				AccountManagement.Instance.DeleteFriend(member, group);

				return Utility.RenderHashJson(
					Context,
					"Result", "OK"
				);
			}
			else
			{
				throw new Exception("您没有权限执行此操作！");
			}
		}
	
		public string SendAddFriendRequest(String peer,String info)
		{
			if (String.Compare(peer, UserName, true) == 0) throw new Exception("不能添加自己为好友！");
			AccountInfo userInfo = AccountManagement.Instance.GetUserInfo(UserName);
			AccountInfo peerInfo = AccountManagement.Instance.GetUserInfo(peer);
			if (peerInfo == null) throw new Exception(String.Format("用户(群)\"{0}\"不存在！", peer));

            if (peerInfo.Type == 1)
            {
                if (peerInfo.ContainsMember(UserName)) throw new Exception(String.Format("您已加入群\"{0}\"！", peer));
				string msg = String.Format("ADDTOGROUP:{0},{1},{2},{3}", peer, peerInfo.NickName, UserName, info);
				MessageManagement.Instance.Add(peerInfo.Creator, "System", msg, 1);
            }
            else
            {
                if (userInfo.ContainsFriend(peer)) throw new Exception(String.Format("\"{0}\"已经是您的好友,不能重复添加好友！", peer));
				string msg = String.Format("ADDFRIEND:{0},{1}", UserName, info);
				MessageManagement.Instance.Add(peer, "System", msg, 1);
            }

			return Utility.RenderHashJson(
				Context,
				"Result", "OK"
			);
		}

		public string Logout()
		{
			FormsAuthentication.SignOut();

			return Utility.RenderHashJson(
				Context,
				"Result", "OK"
			);
		}
	}
}
