﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Xml;
using System.Data;
using System.Web.Security;
using System.Drawing;
using System.Drawing.Imaging;
using Core;

namespace Core.Web
{
	class VerifyCodeHandler : IHttpHandler
	{
		static Hashtable VerifyCodes = new Hashtable();
		
		public VerifyCodeHandler()
		{
		}

		void IHttpHandler.ProcessRequest(HttpContext context)
		{
			VerifyCode vc = new VerifyCode(context.Request.Params["Guid"]);
			lock (VerifyCodes)
			{
				VerifyCodes[vc.Guid] = vc;
			}
			context.Response.Write( String.Format("({{\"Guid\":\"{0}\"}})", vc.Guid));
		}

		bool IHttpHandler.IsReusable
		{
			get { return true; }
		}

		public static bool CheckVerifyCode(String guid, String code)
		{
			lock (VerifyCodes)
			{
				bool ret = VerifyCodes.ContainsKey(guid) && String.Compare((VerifyCodes[guid] as VerifyCode).Code, code, true) == 0;
				VerifyCodes.Remove(guid);
				return ret;
			}
		}

		public static void RemoveVerifyCode(String guid)
		{
			lock (VerifyCodes)
			{
				VerifyCodes.Remove(guid);
			}
		}
	}

	class VerifyCode
	{
		static string Letters = "abdefhijkmnprstuvwxyABDEFGHJKLMNPQRSTUVWXY345678";
		static Color BkColor = Color.FromArgb(0x99, 0xCE, 0x28);
		static Brush BkBrush = new SolidBrush(BkColor);
		public String Code;
		public String Guid = System.Guid.NewGuid().ToString();
		public DateTime CreatedTime = DateTime.Now;
		public VerifyCode(String guid)
		{
			Guid = String.IsNullOrEmpty(guid) ? System.Guid.NewGuid().ToString() : guid;
			Code = "";
			Random random = new Random();
			for (int i = 0; i < 4; i++)
			{
				Code += Letters[(int)Math.Round(random.NextDouble() * (Letters.Length - 1))];
			}
			Bitmap bmp = new Bitmap(76, 26);
			Graphics graphics = Graphics.FromImage(bmp);
			graphics.FillRectangle(BkBrush, new Rectangle(0, 0, bmp.Width, bmp.Height));
			graphics.DrawString(Code, new Font("Courier New", 22, FontStyle.Bold, GraphicsUnit.Pixel), Brushes.Blue, new RectangleF(4, 2, 68, 22));
			double h = Math.PI * 0.7;
			for (int i = 0; i < bmp.Height; i++)
			{
				int dif = 16 - (int)Math.Round(Math.Sin(h * i / (bmp.Height - 1)) * 16);
				for (int j = bmp.Width - 1; j >= 0; j--)
				{
					if (j < dif)
					{
						bmp.SetPixel(j, i, BkColor);
					}
					else
					{
						bmp.SetPixel(j, i, bmp.GetPixel(j - dif, i));
					}
				}
			}
			
			bmp.Save(String.Format("{0}\\VerifyCode\\{1}.png", Server.Instance.BaseDirectory, Guid), ImageFormat.Png);
		}
	}
}
