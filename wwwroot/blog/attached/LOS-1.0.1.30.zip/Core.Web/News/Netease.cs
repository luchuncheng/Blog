﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Net;
using System.IO;
using System.Threading;
using System.Text.RegularExpressions;
using System.Web;
using Core.Web;
using System.Web.Configuration;

namespace Core.Web.News
{
	public class Netease
	{
		// Fields
		private const int INTERVAL = 0x7530;
		private Hashtable m_Config;
		private string m_ConfigPath;
		private AutoResetEvent m_Event = new AutoResetEvent(true);
		private static Netease m_Instance = new Netease();
		private string m_LogFile;
		private bool m_Stop = true;
		private Thread m_Thread;

		// Methods
		private Netease()
		{
		}

		private string CreateNewsContent(NeteaseNews news)
		{
			StringBuilder builder = new StringBuilder();
			builder.AppendFormat("<h1>{0}</h1>", news.Title);
			if (!string.IsNullOrEmpty(news.Summary))
			{
				builder.AppendFormat("<p class=\"news_summary\">{0}</p>", news.Summary);
			}
			builder.Append(news.Content);
			builder.AppendFormat("<p class='come_from'>转载自:<a target=\"_blank\" href=\"{1}\">{0}</a> &nbsp;&nbsp;来源:{2}</p>", "网易新闻", news.Url, news.Source);
			return builder.ToString();
		}

		public void Initialize(HttpServerUtility server)
		{
			this.m_ConfigPath = Server.Instance.FilesRoot + @"\News\NewsFromNetease.conf";
			if (!File.Exists(m_ConfigPath))
			{
				using (Stream stream = File.Create(m_ConfigPath))
				{
					stream.Close();
				}
			}
			this.m_LogFile = Server.Instance.FilesRoot + @"\News\NewsFromNetease.log";
			if (!File.Exists(m_LogFile))
			{
				using (Stream stream = File.Create(m_LogFile))
				{
					stream.Close();
				}
			}
			string str = File.ReadAllText(this.m_ConfigPath);
			this.m_Config = (str == "") ? new Hashtable() : (Utility.ParseJson(str) as Hashtable);
		}

		private void SaveConfig()
		{
			try
			{
				Hashtable conf = new Hashtable();
				DateTime now = DateTime.Now;
				foreach (DictionaryEntry ent in m_Config)
				{
					DateTime createdTime = (DateTime)((ent.Value as Hashtable)["CreatedTime"]);
					if ((now - createdTime).Days < 1) conf[ent.Key] = ent.Value;
				}
				File.WriteAllText(this.m_ConfigPath, Utility.RenderJson(conf, null));
			}
			catch
			{
			}
		}

		public void Start()
		{
			if (WebConfigurationManager.AppSettings["GrabNews"] != "true") return;
			this.m_Stop = false;
			this.m_Thread = new Thread(new ThreadStart(this.ThreadEntry));
			this.m_Thread.Start();
		}

		public void Stop()
		{
			this.m_Stop = true;
			if (!this.m_Event.WaitOne(0x9c40))
			{
				this.m_Thread.Abort();
			}
		}

		public void ThreadEntry()
		{
			int num;
			this.m_Event.WaitOne();
			while (true)
			{
				num = 0;
				File.AppendAllText(this.m_LogFile, string.Format("[{0:yyyy-MM-dd HH:mm:ss}] GRAD START TheardID = {1}\r\n", DateTime.Now, Thread.CurrentThread.ManagedThreadId));
				string html = HtmlTag.GetHtml("http://news.163.com");
				if (html != "")
				{
					try
					{
						List<HtmlTag> list = HtmlTag.FindTag("div", @"<div\s[^<>]*class\s*=\s*\x22area areabg1 clearfix\x22[^<>]*>", html);
						if (list.Count > 0)
						{
							List<HtmlTag> list2 = list[0].FindTag("div", @"<div\s[^<>]*class\s*=\s*\x22colM\x22[^<>]*>");
							List<HtmlTag> list3 = new List<HtmlTag>();
							if (list2.Count > 0)
							{
								list3.Add(list2[0]);
							}
							if (list2.Count > 1)
							{
								List<HtmlTag> list4 = list2[1].FindTag("div", @"<div\s[^<>]*class\s*=\s*\x22content\x22[^<>]*>");
								if (list4.Count > 0)
								{
									list3.Add(list4[0]);
								}
								if (list4.Count > 1)
								{
									list3.Add(list4[1]);
								}
								if (list4.Count > 2)
								{
									list3.Add(list4[2]);
								}
							}
							int[] numArray = new int[] { 11, 12, 13, 14 };
							for (int i = 0; (i < 4) && (i < list3.Count); i++)
							{
								try
								{
									List<HtmlTag> list5 = list3[i].FindTag("a", @"<a\s[^<>]*href\s*=\s*\x22http://news.163.com[^<>\x22]*\x22[^<>]*>");
									File.AppendAllText(this.m_LogFile, string.Format("[{1:yyyy-MM-dd HH:mm:ss}] GRAD CATEGORY {0} UrlCount = {2}, TheardID = {3}\r\n", new object[] { numArray[i], DateTime.Now, list5.Count, Thread.CurrentThread.ManagedThreadId }));
									for (int j = list5.Count - 1; j >= 0; j--)
									{
										try
										{
											HtmlTag tag = list5[j];
											NeteaseNews news = new NeteaseNews(tag.GetAttribute("href"));
											if (!this.m_Config.ContainsKey(news.Url) && news.Load())
											{
												num++;
												File.AppendAllText(this.m_LogFile, string.Format("[{1:yyyy-MM-dd HH:mm:ss}] GRAD URL {0} TheardID = {2}\r\n", news.Url, DateTime.Now, Thread.CurrentThread.ManagedThreadId));
												string content = this.CreateNewsContent(news);
												ThemeManagement.Instance.NewTheme(numArray[i], "administrator", news.Title, content, 0, false);
												Hashtable hashtable = new Hashtable();
												hashtable["CreatedTime"] = DateTime.Now;
												this.m_Config[news.Url] = hashtable;
												Thread.Sleep(0x7530);
											}
										}
										catch
										{
										}
										if (this.m_Stop)
										{
											goto Label_02C3;
										}
									}
								}
								catch
								{
								}
							Label_02C3:
								this.SaveConfig();
							}
						}
					}
					catch
					{
					}
				}
				string str3 = HtmlTag.GetHtml("http://news.163.com/rollnews/");
				if (str3 != "")
				{
					try
					{
						List<HtmlTag> list6 = HtmlTag.FindTag("div", @"<div\s[^<>]*class\s*=\s*\x22area\x22[^<>]*>", str3);
						if (list6.Count > 0)
						{
							List<HtmlTag> list7 = list6[0].FindTag("a");
							File.AppendAllText(this.m_LogFile, string.Format("[{1:yyyy-MM-dd HH:mm:ss}] GRAD CATEGORY {0} UrlCount = {2}, TheardID = {3}\r\n", new object[] { 15, DateTime.Now, list7.Count, Thread.CurrentThread.ManagedThreadId }));
							for (int k = list7.Count - 1; k >= 0; k--)
							{
								try
								{
									HtmlTag tag2 = list7[k];
									NeteaseNews news2 = new NeteaseNews(tag2.GetAttribute("href"));
									if (!this.m_Config.ContainsKey("rollnews:" + news2.Url) && news2.Load())
									{
										num++;
										File.AppendAllText(this.m_LogFile, string.Format("[{1:yyyy-MM-dd HH:mm:ss}] GRAD URL {0} TheardID = {2}\r\n", news2.Url, DateTime.Now, Thread.CurrentThread.ManagedThreadId));
										string str4 = this.CreateNewsContent(news2);
										ThemeManagement.Instance.NewTheme(15, "administrator", news2.Title, str4, 0, false);
										Hashtable hashtable2 = new Hashtable();
										hashtable2["CreatedTime"] = DateTime.Now;
										this.m_Config["rollnews:" + news2.Url] = hashtable2;
										Thread.Sleep(0x1388);
									}
								}
								catch
								{
								}
								if (this.m_Stop)
								{
									break;
								}
							}
						}
					}
					catch
					{
					}
				}

				File.AppendAllText(this.m_LogFile, string.Format("[{0:yyyy-MM-dd HH:mm:ss}] GRAD END TheardID = {1}\r\n", DateTime.Now, Thread.CurrentThread.ManagedThreadId));
				if (!this.m_Stop)
				{
					Thread.Sleep(0x124f80);
				}
				else
				{
					break;
				}
			}
			this.m_Event.Set();
		}

		// Properties
		public static Netease Instance
		{
			get
			{
				return m_Instance;
			}
		}

		// Nested Types
		private class NeteaseNews
		{
			// Fields
			private static Regex ARegx = new Regex(@"<(\/|)a(\s[^<>]*href\s*=\s*\x22([^<>\x22]*)\x22[^<>]*|)>", RegexOptions.IgnoreCase);
			public string Content = "";
			public bool EnableComment;
			private static Regex IFrameRegx = new Regex(@"<iframe(\s[^<>]*|)>[^<>]*</iframe>|<iframe(\s[^<>]*|)/>", RegexOptions.IgnoreCase);
			public string Source = "";
			private static Regex SourceRegx = new Regex(@"来源:\s* <a[^<>]*>([^<>]*)</a>(\S*)", RegexOptions.IgnoreCase);
			public string Summary = "";
			public string Title = "";
			public string Url;

			// Methods
			public NeteaseNews(string url)
			{
				this.Url = url;
			}

			public bool Load()
			{
				string html = HtmlTag.GetHtml(this.Url);
				if (html == "")
				{
					return false;
				}
				List<HtmlTag> list = HtmlTag.FindTag("div", @"<div\s[^<>]*class\s*=\s*\x22endContent\x22[^<>]*>", html);
				if (list.Count == 0)
				{
					return false;
				}
				if (list[0].FindTag("div", @"<div\s[^<>]*class\s*=\s*\x22endPageNum\x22[^<>]*>").Count > 0)
				{
					return false;
				}
				List<HtmlTag> list3 = list[0].FindTag("h1", @"<h1\s[^<>]*id\s*=\s*\x22h1title\x22[^<>]*>");
				if (list3.Count == 0)
				{
					return false;
				}
				this.Title = list3[0].InnerHTML;
				List<HtmlTag> list4 = list[0].FindTag("p", @"<p\s[^<>]*class\s*=\s*\x22summary\x22[^<>]*>");
				if (list4.Count > 0)
				{
					this.Summary = list4[0].InnerHTML;
				}
				List<HtmlTag> list5 = list[0].FindTag("span", @"<span\s[^<>]*class\s*=\s*\x22info\x22[^<>]*>");
				if (list5.Count == 0)
				{
					return false;
				}
				Match match = SourceRegx.Match(list5[0].InnerHTML);
				if (match.Success && (match.Groups.Count >= 3))
				{
					this.Source = match.Groups[1].Value + match.Groups[2].Value;
				}
				List<HtmlTag> list6 = list[0].FindTag("div", @"<div\s[^<>]*id\s*=\s*\x22endText\x22[^<>]*>");
				if (list6.Count == 0)
				{
					return false;
				}
				this.Content = list6[0].InnerHTML;
				List<HtmlTag> list7 = list[0].FindTag("div", @"<div\s[^<>]*class\s*=\s*\x22endMore\x22[^<>]*>");
				if (list6.Count == 0)
				{
					return false;
				}
				this.EnableComment = list7[0].InnerHTML.IndexOf("该评论已关闭") < 0;
				this.Content = IFrameRegx.Replace(this.Content, new MatchEvaluator(this.ReplaceByBlank));
				this.Content = ARegx.Replace(this.Content, new MatchEvaluator(this.ReplaceA));
				return true;
			}

			private string ReplaceA(Match match)
			{
				if (match.Groups[1].Value == "/")
				{
					return "</a>";
				}
				return string.Format("<a href=\"{0}\" target=\"_black\">", match.Groups[3].Value);
			}

			private string ReplaceByBlank(Match match)
			{
				return string.Empty;
			}
		}
	}
}