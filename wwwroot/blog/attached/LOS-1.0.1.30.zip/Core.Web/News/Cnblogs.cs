﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Net;
using System.IO;
using System.Threading;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Configuration;
using Core.Web;

namespace Core.Web.News
{
	public class Cnblogs
	{
		static Cnblogs m_Instance = new Cnblogs();

		static public Cnblogs Instance
		{
			get { return m_Instance; }
		}

		String m_ConfigPath = null;
		Hashtable m_Config = null;
		bool m_Stop = true;
		Thread m_Thread = null;
		AutoResetEvent m_Event = new AutoResetEvent(true);

		private Cnblogs()
		{
		}

		public void Initialize(HttpServerUtility server)
		{
			m_ConfigPath =  Server.Instance.FilesRoot + @"\News\NewsFromCnblogs.conf";
			if (!File.Exists(m_ConfigPath))
			{
				using (Stream stream = File.Create(m_ConfigPath))
				{
					stream.Close();
				}
			}
			String conf = File.ReadAllText(m_ConfigPath);
			m_Config = (conf == "" ? new Hashtable() : Utility.ParseJson(conf) as Hashtable);
		}
#if DEBUG
		const int INTERVAL = 10 * 2000;
#else
		const int INTERVAL = 30 * 2000;
#endif

		static Regex TopicImgRegx = new Regex(@"<a[^<>]*>[^<>]*<img\s[^<>]*class[^<>]*=[^<>]*\x22topic_img\x22[^<>]*/>[^<>]*</a>", RegexOptions.IgnoreCase);
		static Regex ARegx = new Regex(@"<(\/|)a(\s[^<>]*href[^<>]*=[^<>]*\x22([^<>]*)\x22[^<>]*|)>", RegexOptions.IgnoreCase);
		
		public void ThreadEntry()
		{
			m_Event.WaitOne();
			while (true)
			{
				try
				{
					String html = HtmlTag.GetHtml("http://www.cnblogs.com/news/");
					if (!String.IsNullOrEmpty(html))
					{
						List<HtmlTag> tags = HtmlTag.FindTag("div", "<div\\s[^<>]*class[^<>]*=[^<>]*\"post_item_body news_body\"[^<>]*>", html);
						for (int i = tags.Count - 1; i >= 0; i--)
						{
							HtmlTag tag = tags[i];
							CnblogsNews news = new CnblogsNews(tag);
							if (!m_Config.ContainsKey(news.Url) && news.LoadContent())
							{
								Hashtable data = new Hashtable();
								data["CreatedTime"] = DateTime.Now;
								string content = String.Format("<h1>{0}</h1>{1}", news.Title, ARegx.Replace(TopicImgRegx.Replace(news.Content, this.ReplaceTopicImg), this.ReplaceA));
								ThemeManagement.Instance.NewTheme(2, "administrator", news.Title, content, 0, false);
								m_Config[news.Url] = data;
							}
							if (m_Stop) break;
							Thread.Sleep(INTERVAL);
						} 
						SaveConfig();
					}
				}
				catch
				{
				}
				if (m_Stop) break;
#if DEBUG
				Thread.Sleep(10 * 60 * 1000);
#else
				Thread.Sleep(30 * 60 * 1000);
#endif
			}
			m_Event.Set();
		}

		private void SaveConfig()
		{

			Hashtable conf = new Hashtable();
			DateTime now = DateTime.Now;
			foreach (DictionaryEntry ent in m_Config)
			{
				DateTime createdTime = (DateTime)((ent.Value as Hashtable)["CreatedTime"]);
				if ((now - createdTime).Days < 3) conf[ent.Key] = ent.Value;
			}
			File.WriteAllText(m_ConfigPath, Utility.RenderJson(conf, null));
		}

		public void Start()
		{
			if (WebConfigurationManager.AppSettings["GrabNews"] != "true") return;
			m_Stop = false;
			m_Thread = new Thread(ThreadEntry);
			m_Thread.Start();
		}

		public void Stop()
		{
			m_Stop = true;
			if (!m_Event.WaitOne(40 * 1000))
			{
				m_Thread.Abort();
			}
		}

		private String ReplaceTopicImg(Match match)
		{
			return String.Empty;
		}

		private String ReplaceA(Match match)
		{
			if (match.Groups[1].Value == "/")
			{
				return "</a>";
			}
			else
			{
				return String.Format("<a href=\"{0}\" target=\"_black\">", match.Groups[3].Value);
			}
		}
		
		class CnblogsNews
		{
			public String Title, Summary, Url, Content;
			public DateTime PostTime;

			static Regex DateTimeReg = new Regex(@"发布于\s+([0-9]+)-([0-9]+)-([0-9]+)\s+([0-9]+):([0-9]+)");

			public CnblogsNews(HtmlTag tag)
			{
				foreach (HtmlTag aTag in tag.FindTag("a"))
				{
					if (aTag.GetAttribute("class") == "titlelnk")
					{
						Title = aTag.InnerHTML ?? String.Empty;
						Url = aTag.GetAttribute("href") ?? String.Empty;
					}
				}

				foreach (HtmlTag pTag in tag.FindTag("p"))
				{
					if (pTag.GetAttribute("class") == "post_item_summary")
					{
						Summary = pTag.InnerHTML ?? String.Empty;
					}
				}

				foreach (HtmlTag pTag in tag.FindTag("div"))
				{
					if (pTag.GetAttribute("class") == "post_item_foot news_foot")
					{
						Match m = DateTimeReg.Match(pTag.InnerHTML ?? String.Empty);
						PostTime = new DateTime(Int32.Parse(m.Groups[1].Value), Int32.Parse(m.Groups[2].Value), Int32.Parse(m.Groups[3].Value), Int32.Parse(m.Groups[4].Value), Int32.Parse(m.Groups[5].Value), 0);
					}
				}
			}

			public bool LoadContent()
			{
				String html = HtmlTag.GetHtml(Url);
				if (!String.IsNullOrEmpty(html))
				{
					List<HtmlTag> tags = HtmlTag.FindTag("div", "<div\\s[^<>]*id[^<>]*=[^<>]*\"news_body\"[^<>]*>", html);
					if (tags.Count > 0)
					{
						Content = tags[0].InnerHTML;
					}
					return tags.Count > 0;
				}
				else
				{
					return false;
				}
			}
		}
	}
}
