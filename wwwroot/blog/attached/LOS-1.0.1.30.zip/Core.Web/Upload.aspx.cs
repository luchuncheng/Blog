﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.IO;

public partial class Upload : System.Web.UI.Page
{
	string m_ErrorMsg = "";

	public string ErrorMsg
	{
		get { return m_ErrorMsg; }
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		if (IsPostBack)
		{
			try
			{
				string path = Request.Params["Path"];
				string decompress = Request.Params["Decompress"];
				Core.Security.CheckPermission(path, Context, Core.DirectoryPermission.Create);
                HttpPostedFile file = Request.Files["fuFile"];
                string name = System.IO.Path.GetFileName(file.FileName);
                using (Stream stream = Core.IO.File.Create(path + "/" + name))
				{
					try
					{
						byte[] buffer = new byte[16 * 1024];
						int count = 0;
						do
						{
							count = file.InputStream.Read(buffer, 0, buffer.Length);
							stream.Write(buffer, 0, count);
						} while (count == buffer.Length);
					}
					finally
					{
						stream.Close();
					}
				}
				if(decompress!=null && decompress=="True")
				{
                    Core.IO.File.UnZip(path + "/" + name, path);
				}
				m_ErrorMsg = "";
			}
			catch (System.Exception ex)
			{
				m_ErrorMsg = ex.Message;
			}
		}
	}
}
