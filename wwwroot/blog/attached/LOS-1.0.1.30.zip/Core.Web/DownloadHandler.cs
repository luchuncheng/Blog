﻿using System;
using System.Collections;
using System.Data;
using System.Configuration;
using System.Web;
using System.Xml;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Core;
using Core.IO;
using System.Threading;

/// <summary>
///DownloadHandler 的摘要说明
/// </summary>
namespace Core.Web
{
	public class DownloadHandler : IHttpHandler
	{
		static Hashtable ContentType = new Hashtable();

		static DownloadHandler()
		{
			ContentType[".JS"] = "application/x-javascript";
			ContentType[".XML"] = "text/xml";
			ContentType[".HTML"] = "text/html";
			ContentType[".HTM"] = "text/html";
			ContentType[".CSS"] = "text/css";
			ContentType[".TXT"] = "text";
			ContentType[".PNG"] = "image";
			ContentType[".BMP"] = "image";
			ContentType[".GIF"] = "image";
			ContentType[".JPG"] = "image";
			ContentType[".ICO"] = "image";
			ContentType[".CUR"] = "image";
		}

		public DownloadHandler()
		{
		}

		void IHttpHandler.ProcessRequest(HttpContext context)
		{
#if DEBUG
			Thread.Sleep(200);
#endif
			string fileName = context.Request["FileName"];

			string user = Path.GetUser(fileName);
			string relativePath = Path.GetRelativePath(fileName);
			string relRoot = Path.GetRoot(relativePath);

			if (string.IsNullOrEmpty(user))
			{
				user = context.User.Identity.Name;
				fileName = "/" + user + "/" + relativePath;
			}

			string ext = Core.IO.Path.GetExtension(fileName).ToUpper();

			if (String.Compare(relRoot, "pub", true) == 0 && ext == ".CHM")
			{
				String url = String.Format("pub/reader.aspx?file={0}", HttpUtility.UrlEncode(fileName));
				context.Response.Redirect(url);
			}
			else
			{
				Core.Security.CheckPermission(fileName, context, FilePermission.Read);

				using (System.IO.Stream stream = Core.IO.File.Open(fileName, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.Read))
				{
					try
					{
						if (ContentType.ContainsKey(ext))
						{
							context.Response.ContentType = ContentType[ext] as string;
						}
						else
						{
							context.Response.ContentType = "application/octet-stream";
							context.Response.AppendHeader("Content-Disposition", string.Format("attachment;filename={0}", Microsoft.JScript.GlobalObject.escape(Core.IO.Path.GetFileName(fileName))));
						}


						FileSystemInfo fileInfo = File.GetFileInfo(fileName);
						if (fileInfo != null)
						{
							context.Response.AppendHeader("Last-Modified", String.Format("{0:R}", fileInfo.LastWriteTime));
							context.Response.AppendHeader("Content-Length", stream.Length.ToString());
							context.Response.AppendHeader("ETag", Utility.MD5(String.Format("{0:R}:{1}", fileInfo.LastWriteTime, fileName)));
						}

						byte[] buffer = new byte[4 * 1024];
						while (true)
						{
							int c = stream.Read(buffer, 0, buffer.Length);
							if (c == 0) break;
							context.Response.OutputStream.Write(buffer, 0, c);
						}
					}
					finally
					{
						stream.Close();
					}
				}
			}
		}

		bool IHttpHandler.IsReusable
		{
			get { return true; }
		}
	}
}