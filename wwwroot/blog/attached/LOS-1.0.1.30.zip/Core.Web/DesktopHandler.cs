﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Xml;
using Core;
using Core.IO;
using System.Data;
using System.Web.Security;
using System.Reflection;

namespace Core.Web
{
	using Core.Text;

	public class DesktopHandler : IHttpHandler
	{
		static TextTemplate DesktopTemplate = new TextTemplate(Resources.DesktopTemplate);
		static TextTemplate WebDesktopTemplate = new TextTemplate(Resources.WebDesktopTemplate);
		static TextTemplate BBS_DesktopTemplate = new TextTemplate(Resources.BBS_DesktopTemplate);

		public DesktopHandler()
		{
		}

		private static void CreateUserDirectory(String user)
		{
			String path = String.Empty;
			if (!Core.IO.Directory.Exists(path = String.Format("/{0}/Home", user))) Core.IO.Directory.CreateDirectory(path);
			if (!Core.IO.Directory.Exists(path = String.Format("/{0}/Config", user))) Core.IO.Directory.CreateDirectory(path);
			if (!Core.IO.Directory.Exists(path = String.Format("/{0}/Groups", user))) Core.IO.Directory.CreateDirectory(path);
			if (!Core.IO.Directory.Exists(path = String.Format("/{0}/Message", user))) Core.IO.Directory.CreateDirectory(path);
			if (!Core.IO.Directory.Exists(path = String.Format("/{0}/Share", user))) Core.IO.Directory.CreateDirectory(path);
			if (!Core.IO.Directory.Exists(path = String.Format("/{0}/pub", user))) Core.IO.Directory.CreateDirectory(path);
			if (!Core.IO.Directory.Exists(path = String.Format("/{0}/Temp", user))) Core.IO.Directory.CreateDirectory(path);
		}

		void IHttpHandler.ProcessRequest(HttpContext context)
		{
			if (System.IO.Path.GetFileName(context.Request.FilePath).ToLower() == "bbs.aspx" && !context.Request.IsAuthenticated)
			{
				context.Response.Redirect("bbs_login.aspx");
				return;
			}

			CreateUserDirectory(context.User.Identity.Name);

			String userId = context.User.Identity.Name;

			Session session = SessionManagement.Instance.Login(userId);
			AccountInfo info = AccountManagement.Instance.GetUserInfo(userId);
			Hashtable vals = new Hashtable();
			vals["NICKNAME"] = info.NickName;
			vals["USERINFO"] = Utility.RenderJson(Utility.RenderJson(info, context), context);
			vals["LOGINTIME"] = Utility.RenderJson(Utility.RenderJson(DateTime.Now, context), context);
			vals["SESSIONID"] = session.SessionID;
#if DEBUG
			vals["ALLOWEXEC"] = "true";
#else
			vals["ALLOWEXEC"] = info.IsRole("管理员") ? "true" : "false";
#endif
			vals["VERSION"] = Server.Instance.Version.ToString();
			vals["HOMEPAGE"] = info.HomePage.StartsWith("http://", StringComparison.CurrentCultureIgnoreCase) ? info.HomePage : "http://" + info.HomePage;
#if DEBUG
			vals["DEBUG"] = "true";
#else
			vals["DEBUG"]="false";
#endif

			if (context.Request.Params["User"] != null && context.Request.Params["InviteCode"] != null
				&& String.Compare(userId, context.Request.Params["User"]) != 0
				 && AccountManagement.Instance.GetUserInfo(context.Request.Params["User"]).InviteCode == context.Request.Params["InviteCode"])
			{
				AccountManagement.Instance.AddFriend(context.Request.Params["User"], userId);
				vals["INVITEUSER"] = context.Request.Params["User"];
				vals["INVITECODE"] = context.Request.Params["InviteCode"];
			}
			else
			{
				vals["INVITEUSER"] = String.Empty;
				vals["INVITECODE"] = String.Empty;
			}

			if (System.IO.Path.GetFileName(context.Request.FilePath).ToLower() == "bbs.aspx")
			{
				context.Response.Write(BBS_DesktopTemplate.Render(vals));
			}
			else
			{
				context.Response.Write(
					context.Request.Params["Mode"] == "0" ? WebDesktopTemplate.Render(vals) : DesktopTemplate.Render(vals)
				);
			}
		}

		bool IHttpHandler.IsReusable
		{
			get { return true; }
		}
	}
}
