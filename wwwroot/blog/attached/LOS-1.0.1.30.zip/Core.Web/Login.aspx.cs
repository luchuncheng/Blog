﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Core;

public partial class Login : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
#		if DEBUG

		if (!String.IsNullOrEmpty(Request.QueryString["DebugUser"]))
		{
			String test_user = Request.QueryString["DebugUser"];

			String[] rs = AccountManagement.Instance.GetUserRoles(test_user);
			string roles = string.Empty;
			foreach (String role in rs)
			{
				if (string.IsNullOrEmpty(roles))
					roles = role;
				else
					roles += "," + role;
			}
			UserLogin(test_user, roles, false);
			string qs = Request.QueryString.ToString();
			if (String.IsNullOrEmpty(qs))
			{
				Response.Redirect("desktop.aspx");
			}
			else
			{
				Response.Redirect(String.Format("desktop.aspx?{0}", qs));
			}
			return;
		}

#		endif

		if (IsPostBack)
		{
			if (Request.Params["Command"] == "Login")
			{
				string userId = Request.Params["UserName"].Trim();
				string password = Request.Params["Password"].Trim();
				if (AccountManagement.Instance.Validate(userId, password))
				{
					String[] rs = AccountManagement.Instance.GetUserRoles(userId);
					string roles = string.Empty;
					foreach (String role in rs)
					{
						if (string.IsNullOrEmpty(roles))
							roles = role;
						else
							roles += "," + role;
					}
					UserLogin(userId, roles, Request.Params["Rem"] == "1");
					/*
					int timeout = 30 * 1000;
					if (SessionManager.Instance.ExistSession(userId)) SessionManager.Instance.ShutdownExistSession(userId);

					//最多等待30秒，如果现有连接不能正常关闭，则丢弃
					while (SessionManager.Instance.ExistSession(userId) && timeout > 0)
					{
						System.Threading.Thread.Sleep(500);
						timeout -= 500;
					}
					*/
					if (Request.QueryString["ReturnUrl"] == null)
					{
						string qs = Request.QueryString.ToString();

						string mode = Request.Params["Mode"] ?? "1";
						if (String.IsNullOrEmpty(qs)) qs = String.Format("Mode={0}", mode); else qs += String.Format("&Mode={0}", mode);

						Response.Redirect(String.Format("desktop.aspx?{0}", qs));
					}
					else
					{
						Response.Redirect(Request.QueryString["ReturnUrl"]);
					} 
				}
			}
		}
		else
		{
			if (Request.IsAuthenticated && Request.QueryString["Redirect"] != "false")
			{
				if (Request.QueryString["ReturnUrl"] == null)
				{
					string qs = Request.QueryString.ToString();

					string mode = Request.Params["Mode"] ?? "1";
					if (String.IsNullOrEmpty(qs)) qs = String.Format("Mode={0}", mode); else qs += String.Format("&Mode={0}", mode);

					Response.Redirect(String.Format("desktop.aspx?{0}", qs));
				}
				else
				{
					Response.Redirect(Request.QueryString["ReturnUrl"]);
				}
			}
		}

	}

	String EncodeExceData(string data)
	{
		System.Text.StringBuilder builder = new System.Text.StringBuilder();
		foreach (char c in data) builder.AppendFormat("{0:X4}", (int)c);
		return builder.ToString();
	}

	void UserLogin(string userName, string roles, bool isPresistent)
	{
		FormsAuthentication.Initialize();

		FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(
			2,									
			userName,								
			DateTime.Now,							
			DateTime.Now.AddMonths(1),				
			isPresistent,							
			roles,								
			FormsAuthentication.FormsCookiePath	
		);

		string hash = FormsAuthentication.Encrypt(ticket);
		HttpCookie cookie = new HttpCookie(
			FormsAuthentication.FormsCookieName,
			hash
		); 

		if (ticket.IsPersistent) cookie.Expires = ticket.Expiration;

		Response.Cookies.Add(cookie);
	}
}
