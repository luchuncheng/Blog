﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Xml;
using System.Web;

namespace Core.Web
{
	abstract class Service
	{
		private HttpContext m_Context;
		private XmlElement m_Data;
		private Hashtable m_Params;
		private String m_SessionID;

		public String SessionID
		{
			get { return m_SessionID; }
		}

		public HttpContext Context
		{
			get { return m_Context; }
			set { m_Context = value; }
		}

		public XmlElement Data
		{
			get { return m_Data; }
			set { m_Data = value; }
		}

		public Service(HttpContext context,XmlElement data,String sessionId)
		{
			m_SessionID = sessionId;
			m_Context = context;
			m_Data = data;
			m_Params = new Hashtable();

			XmlNodeList nodes = Data.GetElementsByTagName("Param");
			foreach(XmlNode node in nodes)
			{
				if (node.NodeType == XmlNodeType.Element)
				{
					XmlElement elem = node as XmlElement;
					m_Params[elem.GetAttribute("Name")] = elem.InnerText;
				}
			}
		}

		protected void CheckPermission(string path, UInt64 action)
		{
			Core.Security.CheckPermission(path, Context, action);
		}

		protected String GetParam(string name)
		{
			return m_Params.ContainsKey(name) ? (String)m_Params[name] : null;
		}

		public string UserName
		{
			get { return Context.User.Identity.Name; }
		}

		public abstract String Process();
	}
}
