﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Xml;
using Core;
using Core.IO;

namespace Core.Web
{
	class FileService : Core.Web.Service
	{
		HttpContext _context = null;

		public FileService(HttpContext context, XmlElement data,String sessionId)
			: base(context, data, sessionId)
		{
			_context = context;
		}

		public override String Process()
		{
			switch (Data.GetAttribute("Command"))
			{
			case "Create":
				{
					string fileName = GetParam("FileName");
					string content = GetParam("Content");
					string encoding = GetParam("Encoding");
					return Create(fileName, content, encoding);
				}
			case "Open":
				{
					string fileName = GetParam("FileName");
					string createNew = GetParam("CreateNew");
					string encoding = GetParam("Encoding");
					return Open(fileName, Boolean.Parse(createNew), encoding);
				}
			case "SaveLog":
				{
					string fileName = GetParam("FileName");
					string content = GetParam("Content");
					return SaveLog(fileName, content);
				}
			case "UnZip":
				{
					string source = GetParam("Source");
					string target = GetParam("Target");
					return UnZip(source, target);
				}
			case "Zip":
				{
					string files = GetParam("Files");
					string target = GetParam("Target");
					return Zip(files, target);
				}
			case "Move":
				{
					string items = GetParam("Items");
					string target = GetParam("Target");
					return Move(items, target);
				}
			case "Rename":
				{
					string path = GetParam("Path");
					string newName = GetParam("NewName");
					return Rename(path, newName);
				}
			case "Copy":
				{
					string items = GetParam("Items");
					string target = GetParam("Target");
					return Copy(items, target);
				}
			default:
				{
					throw new Exception("Unknown Command!");
				}
			}
		}

		public String Create(string fileName, string content, string encoding)
		{
			CheckPermission(fileName, FilePermission.Write);

			using (System.IO.Stream fs = Core.IO.File.Create(fileName))
			{
				try
				{
					if (!string.IsNullOrEmpty(content))
					{
						byte[] buffer = Encoding.GetEncoding(encoding).GetBytes(content);
						fs.Write(buffer, 0, buffer.Length);
					}
				}
				finally
				{
					fs.Close();
				}
			}

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"NewItemInfo", File.GetFileInfo(fileName)
			);
		}

		public String SaveLog(string fileName, string content)
		{
			CheckPermission(fileName, FilePermission.Write);

			using (System.IO.Stream fs = Core.IO.File.Open(fileName,true))
			{
				try
				{
					fs.Seek(0, System.IO.SeekOrigin.End);

					if (!string.IsNullOrEmpty(content))
					{
						byte[] buffer = Encoding.UTF8.GetBytes(Utility.Decode(content));
						fs.Write(buffer, 0, buffer.Length);
					}
				}
				finally
				{
					fs.Close();
				}
			}

			return Utility.RenderHashJson(
				Context,
				"Result", "OK"
			);
		}

		public string Open(string fileName, bool createNew, string encoding)
		{
			string content = "";

			CheckPermission(fileName, FilePermission.Read);

			using (System.IO.Stream fs = Core.IO.File.Open(fileName, createNew))
			{
				try
				{
					byte[] buffer = new byte[fs.Length];
					int count = fs.Read(buffer, 0, buffer.Length);
					content = Encoding.GetEncoding(encoding).GetString(buffer);
				}
				finally
				{
					fs.Close();
				}
			}

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"Content", content
			);
		}

		public string UnZip(string source, string target)
		{
			StringBuilder builder = new StringBuilder();

			CheckPermission(source, FilePermission.Read);
			CheckPermission(Path.GetDirectoryName(target), DirectoryPermission.Create);
			Core.IO.File.UnZip(source, target);

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"Items", Directory.GetFileSystemInfos(target),
				"NewItemInfo", File.GetFileInfo(target)
			);
		}

		public string Zip(string files, string target)
		{

			if (File.Exists(target)) throw new Exception(String.Format("文件'{0}'已存在!", target));
			string[] paths = files.Split('|');
			foreach (string item in paths) CheckPermission(item, FilePermission.Read);
			CheckPermission(target, FilePermission.Write);

			StringBuilder builder = new StringBuilder();

			Core.IO.File.Zip(paths, target, 6);

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"NewItemInfo", File.GetFileInfo(target)
			);
		}

		public string Move(string items, string target)
		{
			List<string> successItems = new List<string>();
			string[] paths = items.Split('|');
			foreach (string item in paths) CheckPermission(item, IOPermission.Delete);
			CheckPermission(target, DirectoryPermission.Create);
			foreach (string path in paths)
			{
				System.IO.FileAttributes attrs = Core.IO.File.GetAttributes(path);
				if ((attrs & System.IO.FileAttributes.Directory) == attrs)
					Core.IO.Directory.Move(path, target + "/" + Core.IO.Path.GetFileName(path));
				else
					Core.IO.File.Move(path, target + "/" + Core.IO.Path.GetFileName(path));
				successItems.Add(path);
			}

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"Items", Directory.GetFileSystemInfos(target)
			);
		}

		public string Rename(string path, string newName)
		{
			string newPath = Core.IO.Path.GetDirectoryName(path) + "/" + newName;

			System.IO.FileAttributes attrs = Core.IO.File.GetAttributes(path);
			bool isDir = (attrs & System.IO.FileAttributes.Directory) == System.IO.FileAttributes.Directory;

			CheckPermission(path, IOPermission.Rename);
			if (string.Compare(Core.IO.Path.GetFileName(path), newName, true) != 0)
			{
				if (isDir)
					Core.IO.Directory.Move(path, newPath);
				else
					Core.IO.File.Move(path, newPath);
			}

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"NewItemInfo", File.GetFileInfo(newPath)
			);
		}

		public string Copy(string items, string target)
		{
			string[] paths = items.Split('|');
			foreach (string item in paths) CheckPermission(item, FilePermission.Read);
			CheckPermission(target, DirectoryPermission.Create);
			foreach (string path in paths)
			{
				System.IO.FileAttributes attrs = Core.IO.File.GetAttributes(path);
				if ((attrs & System.IO.FileAttributes.Directory) == System.IO.FileAttributes.Directory)
					Core.IO.Directory.Copy(path, target + "/" + Core.IO.Path.GetFileName(path));
				else
					Core.IO.File.Copy(path, target + "/" + Core.IO.Path.GetFileName(path));
			}

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"Items", Directory.GetFileSystemInfos(target)
			);
		}
	}
}
