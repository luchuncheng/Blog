﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml;
using System.Collections;
using System.Data;
using Core;
using Core.IO;
using System.Data.SQLite;


namespace Core.Web
{
	class SQLiteService : Service
	{
		public SQLiteService(HttpContext context, XmlElement data, String sessionId)
			: base(context, data, sessionId)
		{
		}

		public override String Process()
		{
			switch (Data.GetAttribute("Command"))
			{
			case "ExecuteNonQuery":
				{
					string path = GetParam("Path");
					string cmdText = GetParam("CommandText");
					return ExecuteNonQuery(path, cmdText);
				}
			case "ExecuteQuery":
				{
					string path = GetParam("Path");
					string cmdText = GetParam("CommandText");
					return ExecuteQuery(path, cmdText);
				}
			case "Create":
				{
					string path = GetParam("Path");
					string ddl = GetParam("DDL");
					bool raiseError = Boolean.Parse(GetParam("RaiseError"));
					return Create(path, ddl, raiseError);
				}
			default:
				{
					throw new Exception("Unknown Command!");
				}
			}
		}

		private String ExecuteNonQuery(string path, string cmdText)
		{
			CheckPermission(path, FilePermission.Read);

			String mp = VirtualPathManagement.Instance.MapPath(path).Path;

			SQLiteConnection conn = new SQLiteConnection(String.Format("Data Source=\"{0}\";Pooling=False", mp));

			SQLiteCommand cmd = new SQLiteCommand(cmdText, conn);

			conn.Open();
			try
			{
				cmd.ExecuteNonQuery();
			}
			finally
			{
				conn.Close();
			}

			return Utility.RenderHashJson(
				Context,
				"Result", "OK"
			);
		}

		private String ExecuteQuery(string path, string cmdText)
		{
			CheckPermission(path, FilePermission.Read);

			String mp = VirtualPathManagement.Instance.MapPath(path).Path;

			SQLiteConnection conn = new SQLiteConnection(String.Format("Data Source=\"{0}\";Pooling=False", mp));
			SQLiteDataAdapter ada = new SQLiteDataAdapter(cmdText, conn);

			DataTable table=new DataTable();

			conn.Open();
			try
			{
				ada.Fill(table);
				ada.Dispose();
			}
			finally
			{
				conn.Close();
			}

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"DataTable", table.Rows
			);
		}

		private String Create(string path, string ddl, bool raiseError)
		{
			CheckPermission(path, FilePermission.Write | FilePermission.Read);

			if (File.Exists(path))
			{
				if (raiseError)
				{
					throw new Exception(String.Format("数据库 \"{0}\"已存在", path));
				}
				else
				{
					return Utility.RenderHashJson(
						Context,
						"Result", "EXISTS"
					);
				}
			}
			else
			{

				if (!Directory.Exists(Path.GetDirectoryName(path)))
				{
					Directory.CreateDirectory(Path.GetDirectoryName(path));
				}

				try
				{
					ExecuteNonQuery(path, ddl);
				}
				catch
				{
					File.Delete(path);
					throw;
				}

				return Utility.RenderHashJson(
					Context,
					"Result", "OK"
				);
			}
		}
	}
}
