﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Xml;
using Core;
using Core.IO;
using LIO = Core.IO;
using System.Data;
using MySql.Data.MySqlClient;
using System.Collections;
using System.Text.RegularExpressions;
using Microsoft.JScript;
using System.Web.Configuration;

namespace Core.Web
{
	class BBS_Service : Core.Web.Service
	{
		public BBS_Service(HttpContext context, XmlElement data, String sessionId)
			: base(context, data, sessionId)
		{
		}

		public override String Process()
		{
			switch (Data.GetAttribute("Command"))
			{
			case "GetAllCategory":
				{
					return GetAllCategory();
				}
			case "GetThemeContent":
				{
					int themeId = Int32.Parse(GetParam("ThemeID"));
					return ThemeManagement.Instance.GetThemeContent(themeId);
				}
			case "NewTheme":
				{
					int categoryId = Int32.Parse(GetParam("CategoryID"));
					string subject = GetParam("Subject");
					string creator = GetParam("Creator");
					string content = GetParam("Content");
					return ThemeManagement.Instance.NewTheme(categoryId, creator, subject, content, 1, true);
				}
			case "AddThemeListener":
				{
					int categoryId = Int32.Parse(GetParam("CategoryID"));
					string cmdId = GetParam("CommandID");
					bool receiveMsg = bool.Parse(GetParam("ReceiveThemes"));
					return AddThemeListener(categoryId, cmdId, receiveMsg);
				}
			case "RemoveThemeListener":
				{
					int categoryId = Int32.Parse(GetParam("CategoryID"));
					string cmdId = GetParam("CommandID");
					return RemoveThemeListener(categoryId, cmdId);
				}
			case "NewMessage":
				{
					int themeId = Int32.Parse(GetParam("ThemeID"));
					string sender = GetParam("Sender");
					string content = GetParam("Content");
					return NewMessage(themeId, sender, content);
				}
			case "AddMessageListener":
				{
					int themeId = Int32.Parse(GetParam("ThemeID"));
					string cmdId = GetParam("CommandID");
					bool receiveMsg = bool.Parse(GetParam("ReceiveMessages"));
					return AddMessageListener(themeId, cmdId, receiveMsg);
				}
			case "RemoveMessageListener":
				{
					int themeId = Int32.Parse(GetParam("ThemeID"));
					string cmdId = GetParam("CommandID");
					return RemoveMessageListener(themeId, cmdId);
				}
			default:
				{
					throw new Exception("Unknown Command!");
				}
			}
		}

		private String NewMessage(Int64 themeId, String sender, String content)
		{
			BBS_Message msg = BBS_MessageManagement.Instance.Insert(themeId, AccountManagement.Instance.GetUserInfo(sender).ID, content);
			return Utility.RenderHashJson(null, "Message", msg);
		}

		private String AddMessageListener(Int64 themeId, string cmdId, bool receiveMsg)
		{
			int count = 0;
			List<BBS_Message> msgs = new List<BBS_Message>();
			BBS_MessageManagement.Instance.AddListener(UserName, SessionID, themeId, cmdId, ref count, receiveMsg ? msgs : null);
			return Utility.RenderHashJson(null, "Messages", msgs, "Count", count);
		}

		private String RemoveMessageListener(Int64 themeId, string cmdId)
		{
			BBS_MessageManagement.Instance.RemoveListener(themeId, cmdId);
			return Utility.RenderHashJson(null, "Result", "OK");
		}

		private String AddThemeListener(int categoryId, string cmdId, bool receiveMsg)
		{
			List<Theme> themes = ThemeManagement.Instance.AddListener(UserName, SessionID, categoryId, cmdId, receiveMsg);
			return Utility.RenderHashJson(null, "Themes", themes);
		}

		private String RemoveThemeListener(int categoryId, string cmdId)
		{
			ThemeManagement.Instance.RemoveListener(cmdId, categoryId);
			return Utility.RenderHashJson(null, "Result", "OK");
		}

		private String GetAllCategory()
		{
			MySqlConnection conn = new MySqlConnection(Server.Instance.MySqlConnectionString);
			MySqlCommand cmd = new MySqlCommand(
				"select * from Category order by Type asc,SEQ desc",
				conn
			);

			DataTable dt = new DataTable();

			MySqlDataAdapter ada = new MySqlDataAdapter(cmd);
			try
			{
				ada.Fill(dt);
			}
			finally
			{
				ada.Dispose();
			}

			return Utility.RenderHashJson(
				Context,
				"Categories", dt.Rows
			);
		}
	}

	class Theme : IRenderJson
	{
		public Int32 ID, CategoryID, CreatorID, SEQ;
		public String CreatorNickname, Subject, Content,CreatorName;
		public DateTime CreatedTime;
		public Int32 EnableComment;

		public Theme(int id, int categoryId, int creatorId, string subject, string content, DateTime createdTime, int enableComment, int seq)
		{
			ID = id;
			CategoryID = categoryId;
			CreatorID = creatorId;
			Subject = subject;
			Content = content;
			CreatedTime = createdTime;
			EnableComment = enableComment;
			SEQ = seq;

			AccountInfo info = AccountManagement.Instance.GetUserInfo(creatorId);
			if (info != null)
			{
				CreatorNickname = info.NickName;
				CreatorName = info.Name;
			}
			else
			{
				throw new Exception("无效用户！");
			}
		}

		void IRenderJson.RenderJson(StringBuilder builder, HttpContext context)
		{
			Utility.RenderHashJson(
				builder, null,
				"ID", ID,
				"CategoryID", CategoryID,
				"CreatorID", CreatorID,
				"CreatorName", CreatorName,
				"CreatorNickname", CreatorNickname,
				"Subject", Subject,
				"Content", Content,
				"CreatedTime", CreatedTime,
				"EnableComment", EnableComment,
				"SEQ", SEQ
			);
		}
	}

	class ThemeListener
	{
		public String User, SessionID, CommandID;
		public int CategoryID;

		public ThemeListener(string user, string sessionId, int categoryId, string cmdId)
		{
			User = user;
			SessionID = sessionId;
			CategoryID = categoryId;
			CommandID = cmdId;
		}

		public void Send(Theme theme)
		{
			Session session = SessionManagement.Instance.GetSession(User, SessionID);
			session.SendCommand(CommandID, Utility.RenderHashJson(null, "Theme", theme));
		}
	}

	class ThemeManagement
	{
		static ThemeManagement m_Instance = new ThemeManagement();

		static public ThemeManagement Instance
		{
			get { return m_Instance; }
		}

		private ThemeManagement()
		{
		}

		Hashtable m_Listeners = new Hashtable();

		public String GetThemeContent(int themeId)
		{
			MySqlConnection conn = new MySqlConnection(Server.Instance.MySqlConnectionString);
			MySqlCommand cmd = new MySqlCommand(
				@"select Content from Theme where ID = ?ThemdID",
				conn
			);

			cmd.Parameters.Add("ThemdID", MySqlDbType.Int32).Value = themeId;

			conn.Open();
			try
			{
				object val = cmd.ExecuteScalar();
				String content = (String)(val ?? "");

				return Utility.RenderHashJson(
					null,
					"Result", "OK",
					"Content", content
				);
			}
			finally
			{
				conn.Close();
			}
		}

		public String NewTheme(int categoryId, string creator, string subject, string content, int enableComment, bool filter)
		{
			subject = HtmlUtil.ReplaceHtml(subject);

			AccountInfo creatorInfo = AccountManagement.Instance.GetUserInfo(creator);
			String dir = Guid.NewGuid().ToString().ToUpper();
			BBS_MsgAccessoryEval eval = new BBS_MsgAccessoryEval(dir, creatorInfo.ID);
			Regex reg = new Regex("{Accessory [^\f\n\r\t\v<>]+}");
			content = reg.Replace(filter ? HtmlUtil.ReplaceHtml(content) : content, eval.Replace);

			DateTime now = DateTime.Now;
			MySqlConnection conn = new MySqlConnection(Server.Instance.MySqlConnectionString);
			MySqlCommand cmd = new MySqlCommand(
				@"insert into Theme (CategoryID,Creator,Subject,Content,CreatedTime,AccDir,EnableComment) values (?CategoryID,?Creator,?Subject,?Content,?CreatedTime,?AccDir,?EnableComment);
				select @@session.identity;",
				conn
			);

			cmd.Parameters.Add("CategoryID", MySqlDbType.Int32).Value = categoryId;
			cmd.Parameters.Add("Creator", MySqlDbType.Int32).Value = creatorInfo.ID;
			cmd.Parameters.Add("Subject", MySqlDbType.Text).Value = subject;
			cmd.Parameters.Add("Content", MySqlDbType.Text).Value = content;
			cmd.Parameters.Add("CreatedTime", MySqlDbType.Datetime).Value = now;
			cmd.Parameters.Add("AccDir", MySqlDbType.Text).Value = dir;
			cmd.Parameters.Add("EnableComment", MySqlDbType.Int32).Value = enableComment;

			Int64 id = 0;

			conn.Open();
			try
			{
				object val = cmd.ExecuteScalar();
				id = (Int64)val;
			}
			finally
			{
				conn.Close();
			}

			Theme theme = new Theme((int)id, categoryId, (int)creatorInfo.ID, subject, content, now, enableComment, 0);

			Hashtable listeners = GetCategoryListeners(categoryId);
			List<String> deleteIDs = new List<String>();
			lock (listeners)
			{
				foreach (DictionaryEntry ent in listeners)
				{
					ThemeListener listener = ent.Value as ThemeListener;
					try
					{
						listener.Send(theme);
					}
					catch
					{
						deleteIDs.Add(listener.CommandID);
					}
				}

				foreach (string cmdId in deleteIDs)
				{
					listeners.Remove(cmdId);
				}
			}

			return Utility.RenderHashJson(
				null,
				"Result", "OK",
				"Theme", theme
			);
		}

		public List<Theme> GetAllThemes(int categoryId)
		{
			List<Theme> themes = new List<Theme>();

			MySqlConnection conn = new MySqlConnection(Server.Instance.MySqlConnectionString);
			MySqlCommand cmd = new MySqlCommand(
				@"select 
					ID, CategoryID, Subject, 
					Creator, CreatedTime, EnableComment, SEQ,
					CASE WHEN length(Content)<1024 THEN Content ELSE '' END as Content
				from Theme
				where CategoryID = ?CategoryID order by CreatedTime desc limit 0,100",
				conn
			);
			cmd.Parameters.Add("CategoryID", MySqlDbType.Int32).Value = categoryId;

			DataTable dt = new DataTable();

			MySqlDataAdapter ada = new MySqlDataAdapter(cmd);
			try
			{
				ada.Fill(dt);
			}
			finally
			{
				ada.Dispose();
			}

			foreach (DataRow row in dt.Rows)
			{
				themes.Add(new Theme((Int32)row["ID"], (Int32)row["CategoryID"], (Int32)row["Creator"], row["Subject"] as string, row["Content"] as string, (DateTime)row["CreatedTime"], (Int32)row["EnableComment"], (Int32)row["SEQ"]));
			}

			return themes;
		}

		private Hashtable GetCategoryListeners(int categoryId)
		{
			lock (m_Listeners)
			{
				if (!m_Listeners.ContainsKey(categoryId))
				{
					m_Listeners.Add(categoryId, new Hashtable());
				}
				return m_Listeners[categoryId] as Hashtable;
			}
		}

		public List<Theme> AddListener(string user, string sessionId, int categoryId, string cmdId, bool receiveMsg)
		{
			Hashtable listeners = GetCategoryListeners(categoryId);

			lock (listeners)
			{
				listeners[cmdId] = new ThemeListener(user, sessionId, categoryId, cmdId);
				return receiveMsg ? GetAllThemes(categoryId) : new List<Theme>();
			}
		}

		public void RemoveListener(string cmdId, int categoryId)
		{
			Hashtable listeners = GetCategoryListeners(categoryId);

			lock (listeners)
			{
				if (listeners.ContainsKey(cmdId)) listeners.Remove(cmdId);
			}
		}
	}


	public class BBS_Message : IRenderJson
	{
		public String SenderNickname, Content, SenderName;
		public Int64 Sender;
		public Int64 ID, ThemeID;
		public DateTime CreatedTime;

		public BBS_Message(Int64 id, Int64 themeId, Int64 sender, String content, DateTime cteatedTime)
		{
			Sender = sender;
			Content = content;
			CreatedTime = cteatedTime;
			ID = id;
			ThemeID = themeId;

			AccountInfo senderInfo = AccountManagement.Instance.GetUserInfo((int)sender);
			if (senderInfo != null)
			{
				SenderNickname = senderInfo.NickName;
				SenderName = senderInfo.Name;
			}
			else
			{
				throw new Exception("无效用户");
			}
		}

		void IRenderJson.RenderJson(StringBuilder builder, System.Web.HttpContext context)
		{
			Utility.RenderHashJson(
				builder, context,
				"Sender", Sender,
				"SenderName", SenderName,
				"SenderNickname", SenderNickname,
				"CreatedTime", CreatedTime,
				"ID", ID,
				"ThemeID", ThemeID,
				"Content", Content
			);
		}
	}

	public class MessageCacheManagement
	{
		static MessageCacheManagement m_Instance = new MessageCacheManagement();

		static public MessageCacheManagement Instance
		{
			get { return m_Instance; }
		}

		private MessageCacheManagement()
		{
		}

		Int32 m_Count = 0;
		Hashtable m_Cache = new Hashtable();

		public List<BBS_Message> GetThemeMessageCache(Int64 themeId)
		{
			lock (m_Cache)
			{
				if (!m_Cache.ContainsKey(themeId))
				{
					m_Cache.Add(themeId, new List<BBS_Message>());
				}

				return m_Cache[themeId] as List<BBS_Message>;
			}
		}

#if		DEBUG
		const Int64 MAX_CACHE_COUNT = 4;
#else
		const Int64 MAX_CACHE_COUNT = 200;
#endif


		/// <summary>
		/// 在缓存中插入一条消息
		/// </summary>
		/// <param name="user"></param>
		/// <param name="msg"></param>
		public void Insert(Int64 themeId, BBS_Message msg)
		{
			List<BBS_Message> themeMsgs = null;

			lock (m_Cache)
			{
				themeMsgs = GetThemeMessageCache(themeId);
				themeMsgs.Add(msg);
				m_Count++;
				if (m_Count >= MAX_CACHE_COUNT)
				{
					Flush();
				}

			}
		}

		private void Flush()
		{
			MySqlConnection conn = new MySqlConnection(Server.Instance.MySqlConnectionString);
			MySqlCommand cmd = new MySqlCommand(
				"insert into Message (ID,ThemeID,Sender,Content,CreatedTime) values (?ID,?ThemeID,?Sender,?Content,?CreatedTime)",
				conn
			);

			cmd.Parameters.Add("ThemeID", MySqlDbType.Int32);
			cmd.Parameters.Add("ID", MySqlDbType.Int32);
			cmd.Parameters.Add("Sender", MySqlDbType.Int32);
			cmd.Parameters.Add("Content", MySqlDbType.Text);
			cmd.Parameters.Add("CreatedTime", MySqlDbType.Datetime);

			conn.Open();
			try
			{
				MySqlTransaction tran = conn.BeginTransaction();
				try
				{
					foreach (DictionaryEntry ent in m_Cache)
					{
						try
						{
							foreach (BBS_Message message in ent.Value as List<BBS_Message>)
							{
								cmd.Parameters["ThemeID"].Value = message.ThemeID;
								cmd.Parameters["ID"].Value = message.ID;
								cmd.Parameters["Sender"].Value = message.Sender;
								cmd.Parameters["Content"].Value = message.Content;
								cmd.Parameters["CreatedTime"].Value = message.CreatedTime;
								cmd.ExecuteNonQuery();
							}
							m_Count -= (ent.Value as List<BBS_Message>).Count;
							(ent.Value as List<BBS_Message>).Clear();
						}
						catch
						{
						}
					}
					tran.Commit();
				}
				catch
				{
					tran.Rollback();
				}
			}
			finally
			{
				conn.Close();
			}
		}

		public void Dispose()
		{
			lock (m_Cache)
			{
				Flush();
			}
		}
	}

	/// <summary>
	/// 消息监听器
	/// </summary>
	public class BBS_MessageListener
	{
		String User, SessionID, CommandID;
		public Int64 ThemeID;

		public BBS_MessageListener(String user, String seeeionId, Int64 themeId, String cmdId)
		{
			User = user;
			SessionID = seeeionId;
			ThemeID = themeId;
			CommandID = cmdId;
		}

		public void Send(BBS_Message msg, int count)
		{
			Session session = SessionManagement.Instance.GetSession(User, SessionID);
			session.SendCommand(CommandID, Utility.RenderHashJson(null, "Message", msg, "Count", count));
		}
	}

	public class BBS_MessageManagement
	{
		static BBS_MessageManagement m_Instance = new BBS_MessageManagement();

		static public BBS_MessageManagement Instance
		{
			get { return m_Instance; }
		}

		private BBS_MessageManagement()
		{
		}

		Int64 m_MaxID = 0;

		public void Initailize()
		{
			if (WebConfigurationManager.AppSettings["GrabNews"] != "true") return;
			MySqlConnection conn = new MySqlConnection(Server.Instance.MySqlConnectionString);
			MySqlCommand cmd = new MySqlCommand(
				"select max(ID) from Message",
				conn
			);

			conn.Open();

			try
			{
				object val = cmd.ExecuteScalar();
				if (val != DBNull.Value) m_MaxID = (Int32)val;
			}
			finally
			{
				conn.Close();
			}
		}

		public void Dispose()
		{
			MessageCacheManagement.Instance.Dispose();
		}

		private List<BBS_Message> Find(Int64 themeId)
		{
			MySqlConnection conn = new MySqlConnection(Server.Instance.MySqlConnectionString);
			MySqlCommand cmd = new MySqlCommand(
				"select * from Message where ThemeID = ?ThemeID order by CreatedTime desc limit 0,30",
				conn
			);
			cmd.Parameters.Add("ThemeID", MySqlDbType.Int32).Value = themeId;

			DataTable dt = new DataTable();

			MySqlDataAdapter ada = new MySqlDataAdapter(cmd);
			try
			{
				ada.Fill(dt);
			}
			finally
			{
				ada.Dispose();
			}

			List<BBS_Message> msgs = new List<BBS_Message>();
			foreach (DataRow row in dt.Rows)
			{
				BBS_Message msg = new BBS_Message((Int32)row["ID"], (Int32)row["ThemeID"], (Int32)row["Sender"], row["Content"] as string, (DateTime)row["CreatedTime"]);
				msgs.Add(msg);
			}
			return msgs;
		}

		Hashtable m_Listeners = new Hashtable();

		private Hashtable GetListeners(Int64 themeId)
		{
			lock (m_Listeners)
			{
				if (!m_Listeners.ContainsKey(themeId))
				{
					m_Listeners.Add(themeId, new Hashtable());
				}
				return m_Listeners[themeId] as Hashtable;
			}
		}

		public BBS_Message Insert(Int64 themeId, Int64 sender, string content)
		{
			BBS_Message msg = new BBS_Message(++m_MaxID, themeId, sender, content, DateTime.Now);

			BBS_MsgAccessoryEval eval = new BBS_MsgAccessoryEval(msg.ID, sender);
			Regex reg = new Regex("{Accessory [^\f\n\r\t\v<>]+}");
			msg.Content = reg.Replace(HtmlUtil.ReplaceHtml(msg.Content), eval.Replace);

			Hashtable listeners = GetListeners(themeId);
			lock (listeners)
			{
				List<String> deleteIds = new List<string>();
				foreach (DictionaryEntry ent in listeners)
				{
					BBS_MessageListener listener = ent.Value as BBS_MessageListener;
					try
					{
						listener.Send(msg, listeners.Count);
					}
					catch
					{
						deleteIds.Add(ent.Key as string);
					}
				}

				foreach(string cmdId in deleteIds)
				{
					listeners.Remove(cmdId);
				}
			}
			MessageCacheManagement.Instance.Insert(themeId, msg);
			return msg;
		}

		public void AddListener(String user, String seeeionId, Int64 themeId, String cmdId,ref int count, List<BBS_Message> msgs)
		{
			BBS_MessageListener listener = new BBS_MessageListener(user, seeeionId, themeId, cmdId);

			Hashtable listeners = GetListeners(themeId);
			lock (listeners)
			{
				listeners[cmdId] = listener;

				List<BBS_Message> messages = new List<BBS_Message>();
				if (msgs != null)
				{
					msgs.AddRange(Find(themeId));
					msgs.AddRange(MessageCacheManagement.Instance.GetThemeMessageCache(themeId));
				}
				count = listeners.Count;
			}
		}

		public void RemoveListener(Int64 themeId, String cmdId)
		{
			Hashtable listeners = GetListeners(themeId);
			lock (listeners)
			{
				listeners.Remove(cmdId);
			}
		}
	}

	internal class BBS_MsgAccessoryEval
	{
		string m_MsgDir;
		Int64 m_Sender;
		AccountInfo m_SenderInfo;
		Int64 m_FileLimit, m_ImageLimit;

		public BBS_MsgAccessoryEval(Int64 msgId, Int64 sender)
		{
			m_Sender = sender;
			m_SenderInfo = AccountManagement.Instance.GetUserInfo((Int32)sender);
			m_MsgDir = string.Format("Public/BBS/Messages/MSG{0:00000000}", msgId);

			m_FileLimit = 1024;
			m_ImageLimit = 200;
		}

		public BBS_MsgAccessoryEval(String dir,Int64 sender)
		{
			m_Sender = sender;
			m_SenderInfo = AccountManagement.Instance.GetUserInfo((Int32)sender);
			m_MsgDir = string.Format("Public/BBS/Messages/{0}", dir);

			m_FileLimit = 1024;
			m_ImageLimit = 200;
		}

		public string Replace(Match match)
		{
			XmlDocument xml = new XmlDocument();
			string value = match.Value;
			xml.LoadXml(string.Format("<{0} />", value.Substring(1, value.Length - 2)));

			string src = GlobalObject.unescape(xml.DocumentElement.GetAttribute("src"));
			string type = xml.DocumentElement.GetAttribute("type").ToLower();

			bool isPublic = LIO.Path.IsPublicResource(src);

			if (isPublic)
			{
				//公共资源不拷贝
				return String.Format("{1}", m_SenderInfo.Name, LIO.Path.GetRelativePath(src));
			}
			else
			{
				if (!LIO.Directory.Exists(m_MsgDir)) LIO.Directory.CreateDirectory(m_MsgDir);

				string fileOwner = LIO.Path.GetUser(src);

				Core.IO.FileInfo info = new Core.IO.FileInfo(src);
				if (type == "file" && info.Length / 1024 > m_FileLimit)
				{
					throw new Exception(String.Format("附件不能超过 {0} KB！", m_FileLimit));
				}
				if (type != "file" && info.Length / 1024 > m_ImageLimit)
				{
					throw new Exception(String.Format("图片不能超过 {0} KB！", m_ImageLimit));
				}

				AccountInfo fileOwnerInfo = AccountManagement.Instance.GetUserInfo(fileOwner);

				if (!String.IsNullOrEmpty(fileOwner) && fileOwnerInfo.ID == m_SenderInfo.ID)
				{
					Hashtable _files = new Hashtable();
					string fileName;
					if (!_files.ContainsKey(src))
					{
						fileName = LIO.Path.GetFileName(src);
						int i = 1;
						while (_files.ContainsValue(fileName))
						{
							fileName = string.Format("{0}({1}){2}", System.IO.Path.GetFileNameWithoutExtension(fileName), i.ToString(), System.IO.Path.GetExtension(fileName));
							i++;
						}

						_files.Add(src, fileName);

						try
						{
							LIO.File.Copy(src, m_MsgDir + "/" + fileName);
						}
						catch
						{
						}

					}
					else
						fileName = _files[src] as string;

					string newUrl = GlobalObject.escape(string.Format("{0}/{1}", m_MsgDir, fileName));

					return newUrl;
				}
				else
				{
					throw new Exception(String.Format("您没有权限读取文件 \"{0}\"", src));
				}
			}
		}
	}
}