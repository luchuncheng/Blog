﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Xml;
using System.Data;
using System.Web.Security;
using Core;

namespace Core.Web
{
	class RegisterHandler: IHttpHandler
	{
		public RegisterHandler()
		{
		}

		void IHttpHandler.ProcessRequest(HttpContext context)
		{
			try
			{
				if (System.Web.Configuration.WebConfigurationManager.AppSettings["EnableRegister"].ToUpper() != "TRUE")
				{
					throw new Exception("系统目前已关闭注册！");
				}
				if (!VerifyCodeHandler.CheckVerifyCode(context.Request.Params["VerifyCodeGuid"], context.Request.Params["VerifyCode"]))
				{
					throw new Exception("验证码错误!");
				}

				AccountManagement.Instance.CreateUser(
					context.Request.Params["Name"], 
					context.Request.Params["Nickname"],
					context.Request.Params["Password"],
					context.Request.Params["EMail"]
				);
			}
			catch(Exception ex)
			{
				context.Response.Write("({" + String.Format("IsSucceed:false,Data:{0}", Core.Utility.RenderJson(ex.Message, context)) + "})");
				return;
			}
			context.Response.Write("({IsSucceed:true,Data:\"OK\"})");
		}

		bool IHttpHandler.IsReusable
		{
			get { return true; }
		}
	}
}
