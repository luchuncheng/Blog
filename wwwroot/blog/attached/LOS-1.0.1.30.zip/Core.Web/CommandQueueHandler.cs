﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Web;
using System.Xml;
using System.Threading;
using System.Web.SessionState;

namespace Core.Web
{
	class CommandQueueHandler : IHttpHandler, IRequiresSessionState
	{
		HttpContext m_Context;

		public CommandQueueHandler()
		{
		}

		void IHttpHandler.ProcessRequest(HttpContext context)
		{
			Hashtable ret = new Hashtable();
			Exception error = null;

			m_Context = context;
			System.IO.Stream inputStream = context.Request.InputStream;
			Byte[] buffer = new Byte[inputStream.Length];
			inputStream.Read(buffer, 0, (int)inputStream.Length);
			string content = context.Request.ContentEncoding.GetString(buffer);
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(content);

			String sessionID = doc.DocumentElement.GetAttribute("SessionID");
			try
			{
				Session current = SessionManagement.Instance.GetSession(User, sessionID);

				current.WriteLog(context.Request.QueryString["ID"], "CommandQueue", "Process", doc.DocumentElement.InnerXml);

				Hashtable fail = new Hashtable();
				Hashtable success = new Hashtable();
				ret.Add("Fail", fail);
				ret.Add("Success", success);

				foreach (XmlNode node in doc.DocumentElement.GetElementsByTagName("Command"))
				{
					if (node.NodeType == XmlNodeType.Element)
					{
						XmlElement elem = node as XmlElement;
						string msgId = elem.GetAttribute("ID");
						try
						{
							if (elem.FirstChild.NodeType == XmlNodeType.Element)
							{
								ServiceThreadEntryParam param = new ServiceThreadEntryParam();
								param.SessionID = sessionID;
								param.MsgID = msgId;
								param.MsgXML = elem.FirstChild as XmlElement;

								ThreadPool.QueueUserWorkItem(new WaitCallback(this.ServiceThreadEntry), param);

								//Thread serviceThread = new Thread(this.ServiceThreadEntry);
								//serviceThread.Start(param);

							}
							success.Add(msgId, "Success");
						}
						catch (Exception e)
						{
							fail.Add(msgId, e);
						}
					}
				}
			}
			catch (Exception e)
			{
				error = e;
			}

			String result = "";
			if (error == null)
			{
				result = Utility.RenderHashJson(
					context,
					"IsSucceed", true,
					"Response", ret
				);
				try
				{
					Session current = SessionManagement.Instance.GetSession(User, sessionID);
					current.WriteLog(context.Request.QueryString["ID"], "CommandQueue", "Success", result);
				}
				catch
				{
				}
			}
			else
			{
				result = Utility.RenderHashJson(
					context,
					"IsSucceed", false,
					"Exception", error
				);
				try
				{
					Session current = SessionManagement.Instance.GetSession(User, sessionID);
					current.WriteLog(context.Request.QueryString["ID"], "CommandQueue", error);
				}
				catch
				{
				}
			}
			context.Response.Write(result);
		}

		void ServiceThreadEntry(object data)
		{
			ServiceThreadEntryParam param = data as ServiceThreadEntryParam;

			String response = String.Empty;

			Exception error = null;

			try
			{
				Session current = SessionManagement.Instance.GetSession(User, param.SessionID);

				current.WriteLog(param.MsgID, "Command", "Process", param.MsgXML.OuterXml);
				switch (param.MsgXML.Name)
				{
					case "FileService":
						{
							Service service = new FileService(m_Context, param.MsgXML, param.SessionID);
							response = service.Process();
							break;
						}
					case "DirectoryService":
						{
							Service service = new DirectoryService(m_Context, param.MsgXML, param.SessionID);
							response = service.Process();
							break;
						}
					case "CommunicationService":
						{
							Service service = new CommunicationService(m_Context, param.MsgXML, param.SessionID);
							response = service.Process();
							break;
						}
					case "ManagementService":
						{
							Service service = new ManagementService(m_Context, param.MsgXML, param.SessionID);
							response = service.Process();
							break;
						}
					case "SQLiteService":
						{
							Service service = new SQLiteService(m_Context, param.MsgXML, param.SessionID);
							response = service.Process();
							break;
						}
					case "BBS_Service":
						{
							Service service = new BBS_Service(m_Context, param.MsgXML, param.SessionID);
							response = service.Process();
							break;
						}
					default:
						{
							throw new Exception("Unknown Service");
						}
				}
			}
			catch (Exception ex)
			{
				error = ex;
			}

			String result = "";
			if (error == null)
			{
				if (response != null)
				{
					result = Utility.RenderHashJson(
						m_Context,
						"IsSucceed", true,
						"Response", new JsonText(response)
					);
					try
					{
						Session current = SessionManagement.Instance.GetSession(User, param.SessionID);
						current.WriteLog(param.MsgID, "Command", "Success", "");
						current.AddResponse(param.MsgID, result);
					}
					catch
					{
					}
				}
			}
			else
			{
				result = Utility.RenderHashJson(
					m_Context,
					"IsSucceed", false,
					"Exception", error
				);
				try
				{
					Session current = SessionManagement.Instance.GetSession(User, param.SessionID);
					current.WriteLog(param.MsgID, "Command", error);
					current.AddResponse(param.MsgID, result);
				}
				catch
				{
				}
			}
		}

		public String User
		{
			get { return m_Context.User.Identity.Name; }
		}

		bool IHttpHandler.IsReusable
		{
			get { return true; }
		}
	}

	class ServiceThreadEntryParam
	{
		public XmlElement MsgXML;
		public String MsgID;
		public string SessionID;
	}
}
