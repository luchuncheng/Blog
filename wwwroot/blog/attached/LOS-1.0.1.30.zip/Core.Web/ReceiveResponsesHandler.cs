﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Web;
using System.Xml;
using System.Threading;
using System.Web.SessionState;

namespace Core.Web
{
	class ErrorAsyncResult : IAsyncResult
	{
		bool IAsyncResult.IsCompleted { get { return true; } }
		WaitHandle IAsyncResult.AsyncWaitHandle { get { return null; } }
		Object IAsyncResult.AsyncState { get { return null; } }
		bool IAsyncResult.CompletedSynchronously { get { return false; } }

		public ErrorAsyncResult()
		{
		}
	}

	class ReceiveResponsesHandler : IHttpAsyncHandler
	{
		HttpContext m_Context;
		String m_SessionID = "";

		public ReceiveResponsesHandler()
		{
		}

		IAsyncResult IHttpAsyncHandler.BeginProcessRequest(HttpContext context, AsyncCallback cb, Object extraData)
		{
			try
			{
				m_Context = context;
				m_SessionID = context.Request.Params["SessionID"];
				Int32 sn = Int32.Parse(context.Request.Params["SN"]);

				Session current = SessionManagement.Instance.GetSession(User, m_SessionID);
				current.WriteLog(context.Request.QueryString["ID"], "ReceiveResponses", "Process", "");

				ResponsesWatcher watcher = current.WatchResponses(context.Request.QueryString["ID"], cb, extraData, sn);
				if (watcher.ResponseDataLength > 0) watcher.Complete(null);
				return watcher;
			}
			catch (Exception error)
			{
				String resultJson = Utility.RenderHashJson(
					context,
					"IsSucceed", false,
					"Exception", error
				);
				context.Response.Write(resultJson);

				ErrorAsyncResult result = new ErrorAsyncResult();
				cb(result);
				return result;
			}
		}

		void IHttpAsyncHandler.EndProcessRequest(IAsyncResult result)
		{
			ResponsesWatcher watcher = result as ResponsesWatcher;
			try
			{
				m_Context.Response.Write(watcher.ResponseData);
				ThreadPool.QueueUserWorkItem(new WaitCallback(WriteLogEntry), null);
			}
			catch
			{
			}
		}

		void WriteLogEntry(object data)
		{
			try
			{
				Session current = SessionManagement.Instance.GetSession(User, m_SessionID);
				current.WriteLog(m_Context.Request.QueryString["ID"], "ReceiveResponses", "Complete", "");
			}
			catch
			{
			}

		}

		void IHttpHandler.ProcessRequest(HttpContext context)
		{
		}

		public String User
		{
			get { return m_Context.User.Identity.Name; }
		}

		bool IHttpHandler.IsReusable
		{
			get { return true; }
		}
	}
}
