﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml;
using System.Collections;
using System.Data;
using Core;
using Core.IO;

namespace Core.Web
{
	class CommunicationService : Service
	{
		static DateTime BaseDate = new DateTime(2009, 1, 1);
		static Hashtable AllowHtmlTag = new Hashtable();
		static Regex HtmlTagRegex = new Regex("<(\\S*?)[^>]*>|</(\\S*?)[^>]*>");
		static Regex ExpressionRegex = new Regex("[^a-zA-Z_]on|[^a-zA-Z_]expression|[^a-zA-Z_]javascript", RegexOptions.IgnoreCase);

		static CommunicationService()
		{
			AllowHtmlTag.Add("I", "I");
			AllowHtmlTag.Add("B", "B");
			AllowHtmlTag.Add("U", "U");
			AllowHtmlTag.Add("P", "P");
			AllowHtmlTag.Add("TH", "TH");
			AllowHtmlTag.Add("TD", "TD");
			AllowHtmlTag.Add("TR", "TR");
			AllowHtmlTag.Add("OL", "OL");
			AllowHtmlTag.Add("UL", "UL");
			AllowHtmlTag.Add("LI", "LI");
			AllowHtmlTag.Add("BR", "BR");
			AllowHtmlTag.Add("H1", "H1");
			AllowHtmlTag.Add("H2", "H2");
			AllowHtmlTag.Add("H3", "H3");
			AllowHtmlTag.Add("H4", "H4");
			AllowHtmlTag.Add("H5", "H5");
			AllowHtmlTag.Add("H6", "H6");
			AllowHtmlTag.Add("H7", "H7");
			AllowHtmlTag.Add("EM", "EM");
			AllowHtmlTag.Add("PRE", "PRE");
			AllowHtmlTag.Add("DIV", "DIV");
			AllowHtmlTag.Add("IMG", "IMG");
			AllowHtmlTag.Add("CITE", "CITE");
			AllowHtmlTag.Add("SPAN", "SPAN");
			AllowHtmlTag.Add("FONT", "FONT");
			AllowHtmlTag.Add("CODE", "CODE");
			AllowHtmlTag.Add("TABLE", "TABLE");
			AllowHtmlTag.Add("TBODY", "TBODY");
			AllowHtmlTag.Add("SMALL", "SMALL");
			AllowHtmlTag.Add("THEAD", "THEAD");
			AllowHtmlTag.Add("CENTER", "CENTER");
			AllowHtmlTag.Add("STRONG", "STRONG");
			AllowHtmlTag.Add("BLOCKQUOTE", "BLOCKQUOTE");
		}

		HttpContext _context = null;

		public CommunicationService(HttpContext context, XmlElement data, String sessionId)
			: base(context, data, sessionId)
		{
			_context = context;
		}

		public override String Process()
		{
			switch (Data.GetAttribute("Command"))
			{
			case "AddListener":
				{
					Int64 mfrom=Int64.Parse(GetParam("From"));
					Nullable<DateTime> from = (mfrom == 0 ? null : new Nullable<DateTime>(BaseDate.AddMilliseconds(mfrom)));

					Int32 type = Int32.Parse(GetParam("Type"));
					String handlerId = GetParam("HandlerID");
					String owner = GetParam("Owner");
					String guid = GetParam("Guid");
					return AddListener(guid, owner, type, from, handlerId);
				}
			case "RemoveListener":
				{
					String guid = GetParam("Guid");
					String owner = GetParam("Owner");
					return RemoveListener(owner, guid);
				}
			case "Send":
				{
					XmlNodeList nodes = Data.GetElementsByTagName("Message");
					return Send(nodes[0] as XmlElement);
				}
			case "SendInstantMessage":
				{
					DateTime begin = DateTime.Now;
					XmlNodeList nodes = Data.GetElementsByTagName("Message");
					return SendInstantMessage(nodes[0] as XmlElement);

				}
			case "GetMessageDate":
				{
					string user = GetParam("User");
					Int32 type = Int32.Parse(GetParam("Type"));
					return GetMessageDate(user, type);
				}
			case "FindInstantMessages":
				{
					string user = GetParam("User");
					string sender = String.IsNullOrEmpty(GetParam("Sender")) ? null : GetParam("Sender");
					Nullable<DateTime> min = String.IsNullOrEmpty(GetParam("From")) ? null : new Nullable<DateTime>(BaseDate.AddMilliseconds(Int64.Parse(GetParam("From"))));
					Nullable<DateTime> max = String.IsNullOrEmpty(GetParam("To")) ? null : new Nullable<DateTime>(BaseDate.AddMilliseconds(Int64.Parse(GetParam("To"))));
					Nullable<Int32> count = String.IsNullOrEmpty(GetParam("Count")) ? null : new Nullable<Int32>(Int32.Parse(GetParam("Count")));
					return FindInstantMessages(user, sender, min, max, count);
				}
			case "GetAllSenders":
				{
					string user = GetParam("User");
					return GetAllSenders(user);
				}
			default:
				{
					throw new Exception("Unknown Command!");
				}
			}
		}

		private static void RenderMsgJson(StringBuilder builder, Message msg)
		{
			AccountInfo sender = AccountManagement.Instance.GetUserInfo((Int32)msg.SenderID);
			AccountInfo receiver = AccountManagement.Instance.GetUserInfo((Int32)msg.ReceiverID);

			Utility.RenderHashJson(
				builder, null,
				"Receiver", receiver.Name,
				"ReceiverNickname", receiver.NickName,
				"ReceiverID", receiver.ID,
				"Sender", sender.Name,
				"SenderNickname", sender.NickName,
				"SenderID", sender.ID,
				"Content", msg.Content,
				"CreatedTime", msg.CreatedTime,
				"ID", msg.Key
			);
		}

		public string FindInstantMessages(String user, string sender, Nullable<DateTime> min, Nullable<DateTime> max, Nullable<int> count)
		{
			AccountInfo userInfo = AccountManagement.Instance.GetUserInfo(user);

			if (userInfo.Type == 0 && String.Compare(userInfo.Name, UserName) == 0 ||
				userInfo.Type == 1 && userInfo.ContainsMember(UserName))
			{
				List<Message> msgs = new List<Message>();
				if (userInfo.Type == 0)
				{
					msgs.AddRange(MessageManagement.Instance.Find(user, sender, user, min, max, 0, count.Value));
					msgs.AddRange(MessageManagement.Instance.Find(user, user, sender, min, max, 0, count.Value));
				}
				else
				{
					if (min == null || min < userInfo.GetGroupMemberRenewTime(UserName))
					{
						min = userInfo.GetGroupMemberRenewTime(UserName);
					}
					msgs.AddRange(MessageManagement.Instance.Find(user, null, null, min, max, 0, count.Value));
				}

				StringBuilder messageBuilder = new StringBuilder();
				messageBuilder.Append("{");
				messageBuilder.AppendFormat("\"Owner\":\"{0}\"", user);
				messageBuilder.Append(",\"Messages\":");
				messageBuilder.Append("[");
				for (int i = 0; i < msgs.Count; i++)
				{
					Message msg = msgs[i];
					if (i > 0) messageBuilder.Append(",");
					RenderMsgJson(messageBuilder, msg);
				}
				messageBuilder.Append("]");
				messageBuilder.Append("}");

				return Utility.RenderHashJson(
					Context,
					"Result", "OK",
					"Return", new JsonText(messageBuilder.ToString())
				);
			}
			else
			{
				throw new Exception("权限不足！");
			}
		}

		public string GetAllSenders(String user)
		{
			AccountInfo userInfo = AccountManagement.Instance.GetUserInfo(user);

			if (userInfo.Type == 0 && String.Compare(userInfo.Name, UserName) == 0 ||
				userInfo.Type == 1 && userInfo.ContainsMember(UserName))
			{
				StringBuilder senders = new StringBuilder();
				senders.Append("[");
				foreach (Int64 id in MessageManagement.Instance.GetAllSenders(userInfo.Name))
				{
					AccountInfo ai = AccountManagement.Instance.GetUserInfo((int)id);
					if (ai != null && ai.ID != userInfo.ID)
					{
						if (senders.Length > 1) senders.Append(",");

						Utility.RenderHashJson(
							senders, Context,
							"Name", ai.Name,
							"Nickname", ai.NickName,
							"Type", ai.Type,
							"ID", ai.ID
						);
					}
				}
				senders.Append("]");

				return Utility.RenderHashJson(
					Context,
					"Result", "OK",
					"Return", new JsonText(senders.ToString())
				);
			}
			else
			{
				throw new Exception("权限不足！");
			}
		}

		public string GetMessageDate(String user,Int32 type)
		{
			AccountInfo userInfo = AccountManagement.Instance.GetUserInfo(user);

			if (userInfo.Type == 0 && String.Compare(userInfo.Name, UserName) == 0 ||
				userInfo.Type == 1 && userInfo.ContainsMember(UserName))
			{
				List<string> dates = MessageManagement.Instance.GetMessageDate(user, type);

				return Utility.RenderHashJson(
					Context,
					"Result", "OK",
					"Data", dates
				);
			}
			else
			{
				throw new Exception("权限不足！");
			}
		}

		/*
		 * <Message Receiver="">
		 *     <Body>
		 *     </Body>
		 *     <Accessory Source="" Name="">
		 *     </Accessory>
		 * </Message>
		 */
		public string Send(XmlElement msgElem)
		{
			string sender = Context.User.Identity.Name;
			string receiver = msgElem.GetAttribute("Receiver");
            Int32 msgType = Int32.Parse(msgElem.GetAttribute("Type"));

			XmlElement bodyElem = msgElem.GetElementsByTagName("Body")[0] as XmlElement;
			string body = bodyElem.InnerText;

            if (msgType == 0)
            {
                body = HtmlTagRegex.Replace(body, ReplaceHtmlTag);
            }

            MessageManagement.Instance.Add(receiver, sender, body, 0);

			return Utility.RenderHashJson(
				Context,
				"Result", "OK"
			);
		}

		/*
		 * <Message Receiver="">
		 *     <Body>
		 *     </Body>
		 *     <Accessory Source="" Name="">
		 *     </Accessory>
		 * </Message>
		 */
		public string SendInstantMessage(XmlElement msgElem)
		{
			string sender = Context.User.Identity.Name;
			string receiver = msgElem.GetAttribute("Receiver");
			AccountInfo receiverInfo = AccountManagement.Instance.GetUserInfo(receiver);

			if (!receiverInfo.ContainsFriend(sender) && !receiverInfo.AcceptStrangerIM)
			{
				throw new Exception(String.Format("\"{0}\"不接受陌生人发送的即时消息！", receiver));
			}

			XmlElement bodyElem = msgElem.GetElementsByTagName("Body")[0] as XmlElement;
			string body = bodyElem.InnerText;

			body = HtmlTagRegex.Replace(body, ReplaceHtmlTag);

			Message message = MessageManagement.Instance.Add(receiver, sender, body, 0);

			StringBuilder builder=new StringBuilder();
			RenderMsgJson(builder, message);

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"Message", new JsonText(builder.ToString())
			);
		}

		private string ReplaceHtmlTag(Match match)
		{
			if (match.Value[1] == '/')
			{
				string tag = match.Value.Substring(2, match.Value.Length - 3);
				if (AllowHtmlTag.ContainsKey(GetName(tag).ToUpper()))
				{
					return match.Value;
				}
				else
				{
					return "&lt;/" + tag + "&gt;";
				}
			}
			else
			{
				string tag = match.Value.Substring(1, match.Value.Length - 2);
				if (AllowHtmlTag.ContainsKey(GetName(tag).ToUpper()))
				{
					return ExpressionRegex.Replace(match.Value, ReplaceExpression);
				}
				else
				{
					return "&lt;" +tag + "&gt;";
				}
			}
		}

		public String AddListener(String guid, String owner, Int32 type, Nullable<DateTime> from, String handlerId)
		{
			AccountInfo ownerInfo = AccountManagement.Instance.GetUserInfo(owner);

			if (ownerInfo.Type == 0 && String.Compare(ownerInfo.Name, UserName) == 0 ||
				ownerInfo.Type == 1 && ownerInfo.ContainsMember(UserName))
			{
				if (ownerInfo.Type == 1 && from < ownerInfo.GetGroupMemberRenewTime(UserName))
				{
					from = ownerInfo.GetGroupMemberRenewTime(UserName);
				}

				if (from == null)
				{
					Hashtable config = null;
					if (type == 0) config = SessionManagement.Instance.GetSession(UserName, SessionID).ReadConfig("A553B162-F95F-4B13-BFCD-606DABFDD71F") as Hashtable;
					else if (type == 1) config = SessionManagement.Instance.GetSession(UserName, SessionID).ReadConfig("951AABD2-4AAC-4382-A502-71A57FC7F90D") as Hashtable;
					if (config != null)
					{
						lock (config)
						{
							if (config.ContainsKey(owner.ToUpper()) && (config[owner.ToUpper()] as Hashtable).ContainsKey("LastReceiveTime"))
							{
								from = (DateTime)((config[owner.ToUpper()] as Hashtable)["LastReceiveTime"]);
							}
							else
							{
								from = new DateTime(2009, 1, 1);
							}
						}
					}
					else
					{
						from = new DateTime(2009, 1, 1);
					}
				}

				String newGuid = MessageManagement.Instance.AddListener(SessionID, guid, UserName, owner, from.Value, type, handlerId);
				
				return Utility.RenderHashJson(
					Context,
					"Result", "OK",
					"Return", newGuid
				);
			}
			else
			{
				throw new Exception("权限不足！");
			}

		}

		public String RemoveListener(String owner, String guid)
		{
			AccountInfo ownerInfo = AccountManagement.Instance.GetUserInfo(owner);

			if (ownerInfo.Type == 0 && String.Compare(ownerInfo.Name, UserName) == 0 ||
				ownerInfo.Type == 1 && ownerInfo.ContainsMember(UserName))
			{
				MessageManagement.Instance.RemoveListener(owner, guid);

				return Utility.RenderHashJson(
					Context,
					"Result", "OK"
				);
			}
			else
			{
				throw new Exception("权限不足！");
			}
		}

		private string ReplaceHtmlEvent(Match match)
		{
			return match.Value.Substring(0, 1) + '_' + match.Value.Substring(1);
		}

		private string ReplaceExpression(Match match)
		{
			return '_' + match.Value;
		}

		private string GetName(string val)
		{
			int index = val.IndexOf(' ');
            if (index == -1) index = val.IndexOf("/");
			if (index == -1) return val;
			else return val.Substring(0, index);
		}
	}
}
