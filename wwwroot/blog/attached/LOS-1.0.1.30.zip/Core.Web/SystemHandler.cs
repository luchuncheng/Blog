﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Xml;
using Core;
using Core.IO;
using System.Data;
using System.Web.Security;
using System.Threading;

namespace Core.Web
{
	class SystemHandler : IHttpHandler
	{
		public SystemHandler()
		{
		}

		void IHttpHandler.ProcessRequest(HttpContext context)
		{
			string Command = context.Request.Params["Command"];
			switch (Command)
			{
			case "Logout":
				{
					SessionManagement.Instance.Logout(context.User.Identity.Name);
					FormsAuthentication.SignOut();
					break;
				}
			case "Monitor":
				{
					int worderThreads, completionPortThreads;
					ThreadPool.GetMaxThreads(out worderThreads, out completionPortThreads);

					int availableWorderThreads, availableCompletionPortThreads;
					ThreadPool.GetAvailableThreads(out availableWorderThreads, out availableCompletionPortThreads);

					List<LockRecord> lockers = Lock.GetLockers();
					StringBuilder builder = new StringBuilder();
					DateTime now= DateTime.Now;
					builder.Append("({");
					builder.AppendFormat(
						"\"Now\":new Date({0},{1},{2},{3},{4},{5})",
						now.Year, now.Month, now.Day, now.Hour, now.Minute, now.Second
					);
					builder.Append(",\"Lockers\":");
					Utility.RenderJson(builder, lockers, context);
					builder.Append(",\"WorderThreads\":");
					Utility.RenderJson(builder, worderThreads - availableWorderThreads, context);
					builder.Append(",\"CompletionPortThreads\":");
					Utility.RenderJson(builder, completionPortThreads - availableCompletionPortThreads, context);
					builder.Append(",\"Trace\":");
					Utility.RenderJson(builder, Trace.GetLogs(), context);
					builder.Append("})");
					context.Response.Write(builder.ToString());
					break;
				}
			}
		}

		bool IHttpHandler.IsReusable
		{
			get { return true; }
		}
	}
}
