﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Core;

public partial class BBS_Login : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (User.Identity.IsAuthenticated)
		{
			Response.Redirect("bbs.aspx");
		}
		else
		{
			if (IsPostBack)
			{
				if (Request.Params["Command"] == "Login")
				{
					string userId = Request.Params["UserName"].Trim();
					string password = Request.Params["Password"].Trim();
					if (AccountManagement.Instance.Validate(userId, password))
					{
						String[] rs = AccountManagement.Instance.GetUserRoles(userId);
						string roles = string.Empty;
						foreach (String role in rs)
						{
							if (string.IsNullOrEmpty(roles))
								roles = role;
							else
								roles += "," + role;
						}
						UserLogin(userId, roles, Request["Rem"] == "1");
					}
				}
				else if (Request.Params["Command"] == "CreateTempraryUser")
				{
					String tempUser = AccountManagement.Instance.CreateTempraryUser();
					UserLogin(tempUser, "普通用户", true);
				}
				
				Response.Redirect("bbs.aspx");
			}
		}

	}

	void UserLogin(string userName, string roles, bool isPresistent)
	{
		FormsAuthentication.Initialize();

		FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(
			2,									
			userName,								
			DateTime.Now,							
			DateTime.Now.AddDays(30),				
			isPresistent,							
			roles,								
			FormsAuthentication.FormsCookiePath	
		);

		string hash = FormsAuthentication.Encrypt(ticket);
		HttpCookie cookie = new HttpCookie(
			FormsAuthentication.FormsCookieName,
			hash
		); 

		if (ticket.IsPersistent) cookie.Expires = ticket.Expiration;

		Response.Cookies.Add(cookie);
	}
}
