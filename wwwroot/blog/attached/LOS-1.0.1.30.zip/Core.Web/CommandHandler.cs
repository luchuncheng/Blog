﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Xml;

namespace Core.Web
{
	class CommandHandler : IHttpHandler
	{
		HttpContext m_Context;

		public CommandHandler()
		{
		}

		void IHttpHandler.ProcessRequest(HttpContext context)
		{
			m_Context = context;

			System.IO.Stream inputStream = context.Request.InputStream;
			Byte[] buffer = new Byte[inputStream.Length];
			inputStream.Read(buffer, 0, (int)inputStream.Length);
			string content = context.Request.ContentEncoding.GetString(buffer);
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(content);

			String response = String.Empty;
			Exception error = null;

			XmlElement msgElem = doc.DocumentElement.FirstChild as XmlElement;

			String sessionID = doc.DocumentElement.GetAttribute("SessionID");

			try
			{

				Session current = null;
				current = SessionManagement.Instance.GetSession(context.User.Identity.Name, sessionID);
				current.WriteLog(doc.DocumentElement.GetAttribute("ID"), "Command", "Process", "");

				switch (msgElem.Name)
				{
				case "FileService":
					{
						Service service = new FileService(context, msgElem, sessionID);
						response = service.Process();
						break;
					}
				default:
					{
						throw new Exception("Unknown Service");
					}
				}
			}
			catch (Exception ex)
			{
				error = ex;
			}

			String ret = "";
			if (error == null)
			{
				ret = Utility.RenderHashJson(
					context,
					"IsSucceed", true,
					"Response", new JsonText(response)
				);

				try
				{
					SessionManagement.Instance.GetSession(context.User.Identity.Name, sessionID).WriteLog(doc.DocumentElement.GetAttribute("ID"), "Command", "Success", "");
				}
				catch
				{
				}
			}
			else
			{
				ret = Utility.RenderHashJson(
					context,
					"IsSucceed", false,
					"Exception", error
				);
				try
				{
					SessionManagement.Instance.GetSession(context.User.Identity.Name, sessionID).WriteLog(doc.DocumentElement.GetAttribute("ID"), "Command", error);
				}
				catch
				{
				}
			}

			context.Response.Write(ret);
		}
		bool IHttpHandler.IsReusable
		{
			get { return true; }
		}
	}
}
