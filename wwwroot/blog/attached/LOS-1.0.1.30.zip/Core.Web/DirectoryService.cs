﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Xml;
using Core;
using Core.IO;

namespace Core.Web
{
	class DirectoryService : Service
	{
		static DateTime BaseDate = new DateTime(2009, 1, 1);

		HttpContext _context = null;

		public DirectoryService(HttpContext context, XmlElement data,String sessionId)
			: base(context, data,sessionId)
		{
			_context = context;
		}

		public override String Process()
		{
			switch (Data.GetAttribute("Command"))
			{
			case "GetSubDirectories":
				{
					string path = GetParam("Path");
					return GetSubDirectories(path);
				}
			case "GetSubItems":
				{
					string path = GetParam("Path");
					return GetSubItems(path);
				}
			case "Create":
				{
					string path = GetParam("Path");
					return Create(path);
				}
			case "CreateProject":
				{
					string path = GetParam("Path");
					string name = GetParam("Name");
					string sln = GetParam("Content");
					return CreateProject(path, name, sln);
				}
			case "SaveProject":
				{
					string path = GetParam("Path");
					string sln = GetParam("Content");
					string code = GetParam("Code");
					string css = GetParam("Css");
					return SaveProject(path, sln, code, css);
				}
			case "DeleteItems":
				{
					string items = GetParam("Items");
					return DeleteItems(items);
				}
			case "CreateThumbnailImage":
				{
					string path = GetParam("Path");
					return CreateThumbnailImage(path);
				}
			default:
				{
					throw new Exception("Unknown Command!");
				}
			}
		}

		public string SaveProject(string path, string sln, string code,string css)
		{
			CheckPermission(path, FilePermission.Write);
			string dir = Path.GetDirectoryName(path);
			string name = Path.GetFileNameWithoutExtension(path);

			using (System.IO.Stream fs = Core.IO.File.Create(path))
			{
				try
				{
					if (!string.IsNullOrEmpty(sln))
					{
						byte[] buffer = Encoding.UTF8.GetBytes(sln);
						fs.Write(buffer, 0, buffer.Length);
					}
				}
				finally
				{
					fs.Close();
				}
			}

			using (System.IO.Stream fs = Core.IO.File.Open(dir + "/" + name + ".history", true))
			{
				try
				{
					fs.Seek(0, System.IO.SeekOrigin.End);
					if (!string.IsNullOrEmpty(sln))
					{
						string content = String.Format(
							"<item CreatedTime=\"{0}\">{1}</item>",
							(DateTime.Now - BaseDate).TotalMilliseconds,
							Utility.TransferCharForXML(sln)
						);
						byte[] buffer = Encoding.UTF8.GetBytes(content);
						fs.Write(buffer, 0, buffer.Length);
					}
				}
				finally
				{
					fs.Close();
				}
			}

			using (System.IO.Stream fs = Core.IO.File.Create(dir + "/Bin/" + name + ".js"))
			{
				try
				{

					if (!string.IsNullOrEmpty(code))
					{
						byte[] buffer = Encoding.UTF8.GetBytes(code);
						fs.Write(buffer, 0, buffer.Length);
					}
				}
				finally
				{
					fs.Close();
				}
			}

			using (System.IO.Stream fs = Core.IO.File.Create(String.Format("{0}/Bin/{1}.css", dir, name)))
			{
				try
				{
					if (!string.IsNullOrEmpty(css))
					{
						byte[] buffer = Encoding.UTF8.GetBytes(css);
						fs.Write(buffer, 0, buffer.Length);
					}
				}
				finally
				{
					fs.Close();
				}
			}

			return Utility.RenderHashJson(
				Context,
				"Result", "OK"
			);
		}

		public string CreateProject(string path, string name,string sln)
		{
			CheckPermission(path, DirectoryPermission.Create);
			if (Directory.Exists(path + "/" + name)) throw new Exception(String.Format("无法保存项目，因为文件夹\"{0}\"已存在！", name));

			Directory.CreateDirectory(path + "/" + name);
			Directory.CreateDirectory(path + "/" + name + "/Bin");

			string fileName = String.Format("{0}/{1}/{1}.sln", path, name);
			using (System.IO.Stream fs = Core.IO.File.Create(fileName))
			{
				try
				{
					if (!string.IsNullOrEmpty(sln))
					{
						byte[] buffer = Encoding.UTF8.GetBytes(sln);
						fs.Write(buffer, 0, buffer.Length);
					}
				}
				finally
				{
					fs.Close();
				}
			}

			using (System.IO.Stream fs = Core.IO.File.Create(String.Format("{0}/{1}/Bin/{1}.css", path, name)))
			{
				try
				{
					byte[] buffer = Encoding.UTF8.GetBytes("/*\r\n请将相关的图片及其它资源保存到工程目录的Bin目录中\r\n图片URL格式：\r\nurl(\"相对Bin目录的路径\")\r\n*/\r\n");
						fs.Write(buffer, 0, buffer.Length);
				}
				finally
				{
					fs.Close();
				}
			}

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"NewItemInfo", new DirectoryInfo(path + "/" + name)
			);
		}

		public string GetSubDirectories(string path)
		{
			CheckPermission(path, DirectoryPermission.List);

			FileSystemInfo[] items = Directory.GetFileSystemInfos(path);

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"Items", items
			);
		}

		public string GetSubItems(string path)
		{
			CheckPermission(path, DirectoryPermission.List);

			FileSystemInfo[] items = Directory.GetFileSystemInfos(path);

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"Items", items
			);
		}

		public string Create(string path)
		{
			List<System.IO.FileSystemInfo> items = new List<System.IO.FileSystemInfo>();
			CheckPermission(Path.GetDirectoryName(path), DirectoryPermission.Create);
			Core.IO.Directory.CreateDirectory(path);

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"NewItemInfo", new DirectoryInfo(path)
			);
		}

		public string DeleteItems(string items)
		{
			string[] ps = items.Split('|');
			foreach (string path in ps)
			{
				CheckPermission(path, IOPermission.Delete);
				System.IO.FileAttributes attrs = Core.IO.File.GetAttributes(path);
				if ((attrs & System.IO.FileAttributes.Directory) == attrs)
				{
					Core.IO.Directory.Delete(path);
				}
				else
				{
					Core.IO.File.Delete(path);
				}

			}

			return Utility.RenderHashJson(
				Context,
				"Result", "OK"
			);
		}

		public string CreateThumbnailImage(string path)
		{
			CheckPermission(path,DirectoryPermission.List);
			DirectoryThumbnailImageInfo info = ThumbnailManagement.Instance.CreateThumbnailImage(path);

			return Utility.RenderHashJson(
				Context,
				"Result", "OK",
				"ThumbnailImageInfo", info
			);
		}
	}
}
