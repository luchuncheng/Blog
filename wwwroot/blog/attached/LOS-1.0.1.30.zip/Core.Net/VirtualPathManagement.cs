﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Data.Odbc;
using System.Collections.Generic;
using System.Collections;

namespace Core
{
	using IO;

	public class VirtualPathManagement
	{
		static VirtualPathManagement m_Instance = new VirtualPathManagement();

		public static VirtualPathManagement Instance
		{
			get { return m_Instance; }
		}

		private VirtualPathManagement()
		{
		}

		private DataTable _virtualPath = new DataTable();
		private OdbcDataAdapter _virtualPathDataAdapter = null;

		public void LoadVirtualPath()
		{
			_virtualPath.Columns.Add("Key", typeof(int));
			_virtualPath.Columns.Add("VirtualPath", typeof(string));
			_virtualPath.Columns.Add("RealPath", typeof(string));
			_virtualPath.Columns.Add("Owner", typeof(string));
			_virtualPath.Columns.Add("RealPathType", typeof(int));
			_virtualPath.Columns.Add("Length", typeof(int));

			OdbcConnection conn = new OdbcConnection(Server.Instance.ConnectionString);
			//插入语句
			OdbcCommand insertCommand = new OdbcCommand("insert into VirtualPath (VirtualPath,RealPath,Owner,RealPathType,Length) values (?,?,?,?,?)", conn);
			insertCommand.Parameters.Add("VirtualPath", OdbcType.Text, 512, "VirtualPath");
			insertCommand.Parameters.Add("RealPath", OdbcType.Text, 512, "RealPath");
			insertCommand.Parameters.Add("Owner", OdbcType.Text, 512, "Owner");
			insertCommand.Parameters.Add("RealPathType", OdbcType.Int, 4, "RealPathType");
			insertCommand.Parameters.Add("Length", OdbcType.Int, 4, "Length");
			//更新语句
			OdbcCommand updateCommand = new OdbcCommand("update VirtualPath set VirtualPath=?,RealPath=?,Owner=?,RealPathType=?,Length=? where Key=?", conn);
			updateCommand.Parameters.Add("VirtualPath", OdbcType.Text, 512, "VirtualPath");
			updateCommand.Parameters.Add("RealPath", OdbcType.Text, 512, "RealPath");
			updateCommand.Parameters.Add("Owner", OdbcType.Text, 512, "Owner");
			updateCommand.Parameters.Add("RealPathType", OdbcType.Int, 4, "RealPathType");
			updateCommand.Parameters.Add("Length", OdbcType.Int, 4, "Length");
			updateCommand.Parameters.Add("Key", OdbcType.Int, 4, "Key").SourceVersion = DataRowVersion.Original;
			//删除语句
			OdbcCommand deleteCommand = new OdbcCommand("delete from VirtualPath where Key=?", conn);
			deleteCommand.Parameters.Add("Key", OdbcType.Int, 4, "Key").SourceVersion = DataRowVersion.Original;

			_virtualPathDataAdapter = new OdbcDataAdapter("select * from VirtualPath", conn);
			_virtualPathDataAdapter.InsertCommand = insertCommand;
			_virtualPathDataAdapter.UpdateCommand = updateCommand;
			_virtualPathDataAdapter.DeleteCommand = deleteCommand;

			_virtualPathDataAdapter.Fill(_virtualPath);

		}

		public bool ExistVirtualPath(string path)
		{
			//String user = Path.GetUser(path);
			//String relPath = Path.GetRelativePath(path);

			//DataRow[] rows = _virtualPath.Select(string.Format("VirtualPath='{0}' and (Owner='{1}' or Owner='*')", relPath, user));

			//return rows.Length > 0;
			return false;
		}

		public bool IsVirtualPath(string path)
		{
			//String user = Path.GetUser(path);
			//String relPath = Path.GetRelativePath(path);

			//DataRow[] rows = _virtualPath.Select(string.Format("Owner='{1}' or Owner='*'", relPath, user));

			//foreach (DataRow row in rows)
			//{
			//    if (Path.IsParent(row["VirtualPath"] as string, relPath)) return true;
			//}

			return false;
		}

		public void UpdateVirtualPath(string path, string newPath)
		{
			//String user = Path.GetUser(path);
			//String relPath = Path.GetRelativePath(path);
			//String newUser = Path.GetUser(newPath);
			//String newRelarivePath = Path.GetRelativePath(newPath);

			//if (string.Compare(user, newUser, true) == 0)
			//{

			//    DataRow[] rows = _virtualPath.Select(string.Format("VirtualPath='{0}' and Owner='{1}'", relPath, user));

			//    if (rows.Length > 0)
			//    {
			//        rows[0]["VirtualPath"] = newRelarivePath;
			//        rows[0]["Length"] = newRelarivePath.Length;
			//        _virtualPathDataAdapter.Update(_virtualPath);
			//        _virtualPath.AcceptChanges();
			//    }
			//}
		}

		public void DeleteVirtualPath(string path)
		{
			//DataRow[] rows = _virtualPath.Select(string.Format("VirtualPath='{0}' and Owner='{1}'", Path.GetRelativePath(path), Path.GetUser(path)));
			//if (rows.Length > 0)
			//{
			//    rows[0].Delete();
			//    _virtualPathDataAdapter.Update(_virtualPath);
			//    _virtualPath.AcceptChanges();
			//}
		}

		public FilePath MapPath(string path)
		{
			FilePath targetPath;

			String user = Path.GetUser(path);
			String relPath = Path.GetRelativePath(path);
			string[] pathNodes = relPath.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);

			targetPath.Path = Server.Instance.UserFileRoot + "\\" + user;
			if (!string.IsNullOrEmpty(relPath)) targetPath.Path += "\\" + relPath.Replace('/', '\\');
			targetPath.Type = FilePathType.Local;

			if (pathNodes.Length > 0)
			{
				AccountInfo info = String.IsNullOrEmpty(user) ? null : AccountManagement.Instance.GetUserInfo(user);
				if (info == null)
				{
					switch (pathNodes[0].ToUpper())
					{
					case "SYSTEM":
					case "THEMES":
						{
							targetPath.Path = Server.Instance.BaseDirectory;
							targetPath.Path = Path.Join("\\", targetPath.Path, Path.Join("\\", pathNodes, 0));
							break;
						}
					case "SESSION":
						{
							targetPath.Path = Path.Join("\\", Server.Instance.LogRoot, Path.Join("\\", pathNodes, 1));
							break;
						}
					case "PUBLIC":
						{
							targetPath.Path = Server.Instance.PublicRoot;
							targetPath.Path = Path.Join("\\", targetPath.Path, Path.Join("\\", pathNodes, 1));
							break;
						}
					}
				}
				else if (info.Type == 0)
				{
					switch (pathNodes[0].ToUpper())
					{
					case "HOME":
						{
							if (info.IsRole("管理员") && pathNodes.Length > 1 && pathNodes[1] == "系统文件")
							{
								targetPath.Path = Path.Join("\\", Server.Instance.BaseDirectory, Path.Join("\\", pathNodes, 2));
							}
							if (info.IsRole("管理员") && pathNodes.Length > 1 && pathNodes[1] == "公共资源")
							{
								targetPath.Path = Path.Join("\\", Server.Instance.PublicRoot, Path.Join("\\", pathNodes, 2));
							}
#if DEBUG
							if (info.IsRole("管理员") && pathNodes.Length > 1 && pathNodes[1] == "Projects")
							{
								targetPath.Path = Path.Join("\\", System.IO.Path.GetDirectoryName(Server.Instance.BaseDirectory), Path.Join("\\", pathNodes, 1));
							}
#endif
							break;
						}
					case "SYSTEM":
					case "THEMES":
						{
							targetPath.Path = Server.Instance.BaseDirectory;
							targetPath.Path = Path.Join("\\", targetPath.Path, Path.Join("\\", pathNodes, 0));
							break;
						}
					case "SESSION":
						{
							targetPath.Path = Path.Join("\\", Server.Instance.LogRoot, Path.Join("\\", pathNodes, 1));
							break;
						}
					case "PUBLIC":
						{
							targetPath.Path = Server.Instance.PublicRoot;
							targetPath.Path = Path.Join("\\", targetPath.Path, Path.Join("\\", pathNodes, 1));
							break;
						}
					case "SHARE":
						{
							if (pathNodes.Length >= 2)
							{
								string groupName = pathNodes[1];
								AccountInfo groupInfo = AccountManagement.Instance.GetUserInfo(groupName);

								if (groupInfo.ContainsMember(user))
								{
									String realPath = String.Format("/{0}/Home", groupName);
									targetPath = VirtualPathManagement.Instance.MapPath(realPath);
									if (targetPath.Type == FilePathType.Local && pathNodes.Length > 2)
									{
										targetPath.Path = Path.Join("\\", targetPath.Path, Path.Join("\\", pathNodes, 2));
									}
								}
							}
							break;
						}
					case "GROUPS":
					case "CONFIG":
					case "MESSAGE":
						{
							break;
						}
					default:
						{
							/*
							DataRow[] rows = _virtualPath.Select(
								string.Format("Owner='{0}' or Owner='*'", user)
							);

							foreach (DataRow row in rows)
							{
								string virtualPath = row["VirtualPath"].ToString();
								if (Path.IsEqual(virtualPath, relPath) || Path.IsParent(virtualPath, relPath))
								{
									string rp = Path.GetRelativePath(virtualPath, relPath);
									switch ((int)row["RealPathType"])
									{
									case 0:
										targetPath.Type = FilePathType.Local;
										targetPath.Path = LOS.IO.Path.Join("\\", Server.Instance.FileRoot, row["RealPath"] as string, rp.Replace('/', '\\'));
										break;
									case 2:
										targetPath = VirtualPathManager.Instance.MapPath(row["RealPath"] as string);
										if (targetPath.Type == FilePathType.Local)
											targetPath.Path = Path.Join("\\", targetPath.Path, rp.Replace('/', '\\'));
										break;
									}
								}
							}
							 */
							break;
						}
					}
				}
				else
				{
					switch (pathNodes[0].ToUpper())
					{
					case "SYSTEM":
					case "THEMES":
						{
							targetPath.Path = Server.Instance.BaseDirectory;
							targetPath.Path = Path.Join("\\", targetPath.Path, Path.Join("\\", pathNodes, 0));
							break;
						}
					case "PUBLIC":
						{
							targetPath.Path = Server.Instance.PublicRoot;
							targetPath.Path = Path.Join("\\", targetPath.Path, Path.Join("\\", pathNodes, 1));
							break;
						}
					case "SESSION":
						{
							targetPath.Path = Path.Join("\\", Server.Instance.LogRoot, Path.Join("\\", pathNodes, 1));
							break;
						}
					default:
						{
							String rp = String.Format("/{0}/Groups/{1}/{2}", info.Creator, user, Path.Join("\\", pathNodes, 0));
							targetPath = MapPath(rp);
							break;
						}
					}
				}
			}
#if DEBUG
			if (pathNodes.Length > 2 && pathNodes[0] == "System" && pathNodes[1] == Server.Instance.Version.ToString())
			{
				if (pathNodes[2] == "IM")
				{
					targetPath.Path = Path.Join("\\", System.IO.Path.GetDirectoryName(Server.Instance.BaseDirectory), "Projects/IM/Bin", Path.Join("\\", pathNodes, 3));
				}
				else if (pathNodes[2] == "Notepad")
				{
					targetPath.Path = Path.Join("\\", System.IO.Path.GetDirectoryName(Server.Instance.BaseDirectory), "Projects/Notepad/Bin", Path.Join("\\", pathNodes, 3));
				}
				else if (pathNodes[2] == "Setting")
				{
					targetPath.Path = Path.Join("\\", System.IO.Path.GetDirectoryName(Server.Instance.BaseDirectory), "Projects/Setting/Bin", Path.Join("\\", pathNodes, 3));
				}
				else if (pathNodes[2] == "Finance")
				{
					targetPath.Path = Path.Join("\\", System.IO.Path.GetDirectoryName(Server.Instance.BaseDirectory), "Projects/Finance/Bin", Path.Join("\\", pathNodes, 3));
				}
				else if (pathNodes[2] == "CHH")
				{
					targetPath.Path = Path.Join("\\", System.IO.Path.GetDirectoryName(Server.Instance.BaseDirectory), "Projects/CHH/Bin", Path.Join("\\", pathNodes, 3));
				}
				else if (pathNodes[2] == "BBS")
				{
					targetPath.Path = Path.Join("\\", System.IO.Path.GetDirectoryName(Server.Instance.BaseDirectory), "Projects/BBS/Bin", Path.Join("\\", pathNodes, 3));
				}
			}
#endif
			targetPath.Path = Path.Format(targetPath.Path, '\\');
			return targetPath;
		}

		static String[] RootVirtualDirectorys = new String[] { "System", "Themes", "Public" };

		public string[] GetSubVirtualPathNames(string path)
		{
			String user = Path.GetUser(path);
			String relPath = Path.GetRelativePath(path);
			if (String.IsNullOrEmpty(relPath))
			{
				return RootVirtualDirectorys;
			}
			else if (String.Compare("Groups", relPath, true) == 0)
			{
				return new string[0];
			}
			else if (String.Compare("Share", relPath, true) == 0)
			{
				AccountInfo info = AccountManagement.Instance.GetUserInfo(user);
				return info.Groups;
			}
			else
			{
				string[] pathNodes = relPath.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
				AccountInfo info = AccountManagement.Instance.GetUserInfo(user);
				if (info.IsRole("管理员") && pathNodes.Length == 1 && pathNodes[0] == "Home")
				{
#if DEBUG
					return new string[] { "系统文件", "公共资源", "Projects" };
#else
					return new string[] { "系统文件", "公共资源" };
#endif
				}
				return new string[0];
				/*
				DataRow[] rows = _virtualPath.Select(
					string.Format("(Owner='*' or Owner='{0}') and RealPathType<>3", user)
				);
				List<string> subDirectories = new List<string>();
				Hashtable hash = new Hashtable();
				foreach (DataRow row in rows)
				{
					string virtualPath = row["VirtualPath"].ToString();
					if (Path.IsParent(relPath, virtualPath))
					{
						string rp = Path.GetRelativePath(relPath, virtualPath);
						if (rp.IndexOf("/") == -1 && !hash.ContainsKey(rp))
						{
							hash.Add(rp, rp);
							subDirectories.Add(rp);
						}
					}
				}
				return subDirectories.ToArray();
				*/
			}
		}

		public void Initialize()
		{
			//LoadVirtualPath();
		}

		public void Dispose()
		{
			//_virtualPathDataAdapter.Dispose();
		}

	}
}
