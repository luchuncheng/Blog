﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Data.Odbc;
using System.Collections.Generic;
using System.Collections;
using System.Data.SQLite;
using System.Threading;
using System.Text;

namespace Core
{
	using IO;

	public class AccountManagement
	{
		static AccountManagement m_Instance = new AccountManagement();

		public static AccountManagement Instance
		{
			get { return m_Instance; }
		}

		Hashtable m_UserInfoCache = new Hashtable();
		Hashtable m_UserInfoCacheByID = new Hashtable();
		Lock m_Lock = new Lock("AccountManagement", 199);

		private AccountManagement()
		{
		}

		private AccountInfo RefreshUserInfo(string userName)
		{
			string key = userName.ToUpper();
			SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
			SQLiteCommand cmd = new SQLiteCommand();
			cmd.Connection = conn;
			cmd.CommandText = string.Format(
				"select * from Users u where u.UpperName=?",
				userName
			);

			cmd.Parameters.Add("User", DbType.String).Value = userName.ToUpper();

			SQLiteDataAdapter ada = new SQLiteDataAdapter();
			ada.SelectCommand = cmd;

			DataTable dt = new DataTable();
			ada.Fill(dt);
			ada.Dispose();

			if (dt.Rows.Count > 0)
			{
				DataTable dtFriends = GetFriends(userName);
				List<FriendInfo> friends = new List<FriendInfo>(), managers = new List<FriendInfo>();
				if (String.Compare(userName, "administrator", true) != 0 && (Int64)dt.Rows[0]["Type"] == 0)
				{
					friends.Add(new FriendInfo("administrator", new DateTime(2009, 1, 1), 0, 0));
				}
				FriendInfo creator = null;
				foreach (DataRow row in dtFriends.Rows)
				{
					string name = row["Name"] as string;
					DateTime renewTime = (DateTime)row["RenewTime"];
					FriendInfo fi = new FriendInfo(name, renewTime, (Int64)row["Relationship"], (Int64)row["Type"]);
					friends.Add(fi);
					switch ((Int64)row["Relationship"])
					{
					case 2:
						managers.Add(fi);
						break;
					case 3:
						managers.Add(fi);
						creator = fi;
						break;
					}
				}


				if (m_UserInfoCache.ContainsKey(key))
				{
					AccountInfo info = m_UserInfoCache[key] as AccountInfo;
					info.Reset(
						dt.Rows[0]["Name"] as string,
						dt.Rows[0]["NickName"] as string,
						(Int64)dt.Rows[0]["Key"],
						(Int64)dt.Rows[0]["Type"],
						GetUserRoles(userName),
						friends.ToArray(),
						(Int64)dt.Rows[0]["Type"] == 1 ? managers.ToArray() : null,
						creator,
						dt.Rows[0]["EMail"] as String,
						dt.Rows[0]["InviteCode"] as String,
						((Int64)dt.Rows[0]["AcceptStrangerIM"]) != 0,
						((Int64)dt.Rows[0]["MsgFileLimit"]),
						((Int64)dt.Rows[0]["MsgImageLimit"]),
						((Int64)dt.Rows[0]["DiskSize"]),
						((Int64)dt.Rows[0]["IsTemp"]),
						((DateTime)dt.Rows[0]["RegisterTime"]),
						dt.Rows[0]["HomePage"] as string
					);
					return info;
				}
				else
				{
					AccountInfo info = new AccountInfo(
						dt.Rows[0]["Name"] as string,
						dt.Rows[0]["NickName"] as string,
						(Int64)dt.Rows[0]["Key"],
						(Int64)dt.Rows[0]["Type"],
						GetUserRoles(userName),
						friends.ToArray(),
						(Int64)dt.Rows[0]["Type"] == 1 ? managers.ToArray() : null,
						creator,
						dt.Rows[0]["EMail"] as String,
						dt.Rows[0]["InviteCode"] as String,
						((Int64)dt.Rows[0]["AcceptStrangerIM"]) != 0,
						((Int64)dt.Rows[0]["MsgFileLimit"]),
						((Int64)dt.Rows[0]["MsgImageLimit"]),
						((Int64)dt.Rows[0]["DiskSize"]),
						((Int64)dt.Rows[0]["IsTemp"]),
						((DateTime)dt.Rows[0]["RegisterTime"]),
						dt.Rows[0]["HomePage"] as string
					);

					m_UserInfoCache[key] = info;
					m_UserInfoCacheByID[info.ID] = info;

					return info;
				}
			}
			else
			{
				return null;
			}
		}

		private AccountInfo RefreshUserInfo(int id)
		{
			SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
			SQLiteCommand cmd = new SQLiteCommand();
			cmd.Connection = conn;
			cmd.CommandText = "select * from Users u where u.Key=?";

			cmd.Parameters.Add("User", DbType.Int64).Value = id;

			SQLiteDataAdapter ada = new SQLiteDataAdapter();
			ada.SelectCommand = cmd;

			DataTable dt = new DataTable();
			ada.Fill(dt);
			ada.Dispose();

			if (dt.Rows.Count > 0)
			{
				string userName = dt.Rows[0]["Name"] as string;

				DataTable dtFriends = GetFriends(userName);
				List<FriendInfo> friends = new List<FriendInfo>(), managers = new List<FriendInfo>();
				if (String.Compare(userName, "administrator", true) != 0 && (Int64)dt.Rows[0]["Type"] == 0)
				{
					friends.Add(new FriendInfo("administrator", new DateTime(2009, 1, 1), 0, 0));
				}
				FriendInfo creator = null;
				foreach (DataRow row in dtFriends.Rows)
				{
					string name = row["Name"] as string;
					DateTime renewTime = (DateTime)row["RenewTime"];
					FriendInfo fi = new FriendInfo(name, renewTime, (Int64)row["Relationship"], (Int64)row["Type"]);
					friends.Add(fi);
					switch ((Int64)row["Relationship"])
					{
					case 2:
						managers.Add(fi);
						break;
					case 3:
						managers.Add(fi);
						creator = fi;
						break;
					}
				}


				if (m_UserInfoCache.ContainsKey(userName.ToUpper()))
				{
					AccountInfo info = m_UserInfoCache[userName.ToUpper()] as AccountInfo;
					info.Reset(
						dt.Rows[0]["Name"] as string,
						dt.Rows[0]["NickName"] as string,
						(Int64)dt.Rows[0]["Key"],
						(Int64)dt.Rows[0]["Type"],
						GetUserRoles(userName),
						friends.ToArray(),
						(Int64)dt.Rows[0]["Type"] == 1 ? managers.ToArray() : null,
						creator,
						dt.Rows[0]["EMail"] as String,
						dt.Rows[0]["InviteCode"] as String,
						((Int64)dt.Rows[0]["AcceptStrangerIM"]) != 0,
						((Int64)dt.Rows[0]["MsgFileLimit"]),
						((Int64)dt.Rows[0]["MsgImageLimit"]),
						((Int64)dt.Rows[0]["DiskSize"]),
						((Int64)dt.Rows[0]["IsTemp"]),
						((DateTime)dt.Rows[0]["RegisterTime"]),
						dt.Rows[0]["HomePage"] as string
					);
					return info;
				}
				else
				{
					AccountInfo info = new AccountInfo(
						dt.Rows[0]["Name"] as string,
						dt.Rows[0]["NickName"] as string,
						(Int64)dt.Rows[0]["Key"],
						(Int64)dt.Rows[0]["Type"],
						GetUserRoles(userName),
						friends.ToArray(),
						(Int64)dt.Rows[0]["Type"] == 1 ? managers.ToArray() : null,
						creator,
						dt.Rows[0]["EMail"] as String,
						dt.Rows[0]["InviteCode"] as String,
						((Int64)dt.Rows[0]["AcceptStrangerIM"]) != 0,
						((Int64)dt.Rows[0]["MsgFileLimit"]),
						((Int64)dt.Rows[0]["MsgImageLimit"]),
						((Int64)dt.Rows[0]["DiskSize"]),
						((Int64)dt.Rows[0]["IsTemp"]),
						((DateTime)dt.Rows[0]["RegisterTime"]),
						dt.Rows[0]["HomePage"] as string
					);

					m_UserInfoCache[userName.ToUpper()] = info;
					m_UserInfoCacheByID[info.ID] = info;

					return info;
				}
			}
			else
			{
				return null;
			}
		}

		private String[] GetGroupManagers(string name)
		{
			DataTable result = new DataTable();

			SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
			SQLiteCommand cmd = new SQLiteCommand();
			cmd.Connection = conn;
			cmd.CommandText =
				@"select 
					guest.Name as Name
				from 
					UserRelationship r,
					Users host,
					Users guest
				where 
					r.Relationship=2 and
					r.HostKey=host.Key and
					r.GuestKey=guest.Key and
					host.UpperName=?
				";

			cmd.Parameters.Add("user", DbType.String).Value = name.ToUpper();

			SQLiteDataAdapter ada = new SQLiteDataAdapter();
			ada.SelectCommand = cmd;

			ada.Fill(result);
			ada.Dispose();

			List<String> names = new List<string>();
			foreach (DataRow row in result.Rows) names.Add(row["Name"] as string);

			return names.ToArray();
		}

		private Int64 GetRelationship(string user1, string user2)
		{
			SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
			SQLiteCommand cmd = new SQLiteCommand();
			cmd.Connection = conn;
			cmd.CommandText = @"
				select *
				from Users host,Users guest,UserRelationship r
				where host.UpperName=? and guest.UpperName=? and r.HostKey=host.Key and r.GuestKey=guest.Key
			";

			cmd.Parameters.Add("User1", DbType.String).Value = user1.ToUpper();
			cmd.Parameters.Add("User2", DbType.String).Value = user2.ToUpper();

			DataTable result = new DataTable();

			SQLiteDataAdapter ada = new SQLiteDataAdapter();

			ada.SelectCommand = cmd;
			ada.Fill(result);
			ada.Dispose();

			return result.Rows.Count > 0 ? (Int64)result.Rows[0]["Relationship"] : -1;
		}

		public bool Validate(string userId, string password)
		{
			m_Lock.Enter("Validate");
			try
			{
				SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
				SQLiteCommand cmd = new SQLiteCommand();
				cmd.Connection = conn;
				cmd.CommandText = string.Format(
					"select * from Users where UpperName=? and Password=?",
					userId, password
				);

				cmd.Parameters.Add("User", DbType.String).Value = userId.ToUpper();
				cmd.Parameters.Add("Password", DbType.String).Value = Utility.MD5(password);

				SQLiteDataAdapter ada = new SQLiteDataAdapter();
				ada.SelectCommand = cmd;

				DataTable dt = new DataTable();
				ada.Fill(dt);
				ada.Dispose();

				return dt.Rows.Count > 0;
			}
			finally
			{
				m_Lock.Exit("Validate");
			}
		}

		public AccountInfo GetUserInfo(string user)
		{
			m_Lock.Enter("GetUserInfo");
			try
			{
				string key = user.ToUpper();
				if (m_UserInfoCache.ContainsKey(key)) return m_UserInfoCache[key] as AccountInfo;
				return RefreshUserInfo(user);
			}
			finally
			{
				m_Lock.Exit("GetUserInfo");
			}
		}

		public AccountInfo GetUserInfo(int userId)
		{
			m_Lock.Enter("GetUserInfo");
			try
			{
				if (m_UserInfoCacheByID.ContainsKey(userId))
				{
					return m_UserInfoCacheByID[userId] as AccountInfo;
				}
				else
				{
					return RefreshUserInfo(userId);
				}
			}
			finally
			{
				m_Lock.Exit("GetUserInfo");
			}
		}

		public String[] GetUserRoles(string userId)
		{
			m_Lock.Enter("GetUserRoles");
			try
			{
				SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
				SQLiteCommand cmd = new SQLiteCommand();
				cmd.Connection = conn;
				cmd.CommandText = string.Format(
					"select r.Name as RoleName from Users u,User_Role ur,Roles r where u.UpperName=? and u.Key=ur.UserKey and ur.RoleKey=r.Key",
					userId
				);

				cmd.Parameters.Add("User", DbType.String).Value = userId.ToUpper();

				SQLiteDataAdapter ada = new SQLiteDataAdapter();
				ada.SelectCommand = cmd;

				DataTable dt = new DataTable();
				ada.Fill(dt);
				ada.Dispose();

				List<string> names = new List<string>();
				foreach (DataRow row in dt.Rows) names.Add(row["RoleName"] as string);

				return names.ToArray();
			}
			finally
			{
				m_Lock.Exit("GetUserInfo");
			}
		}

		public void UpdateInviteCode(string name, string inviteCode)
		{
			m_Lock.Enter("UpdateInviteCode");
			try
			{

				SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
				SQLiteCommand cmd = new SQLiteCommand();
				cmd.Connection = conn;
				cmd.CommandText = "Update Users set InviteCode=? where UpperName=?";

				cmd.Parameters.Add("InvaiteCode", DbType.String).Value = inviteCode;
				cmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();

				conn.Open();
				try
				{
					cmd.ExecuteNonQuery();
				}
				finally
				{
					conn.Close();
				}
				RefreshUserInfo(name);
			}
			finally
			{
				m_Lock.Exit("UpdateInviteCode");
			}
		}

		public DataTable GetFriends(string user)
		{
			m_Lock.Enter("GetFriends");
			try
			{
				DataTable result = new DataTable();

				SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
				SQLiteCommand cmd = new SQLiteCommand();
				cmd.Connection = conn;
				cmd.CommandText =
					@"select 
					guest.Name as Name,
					guest.Type as Type,
					r.RenewTime as RenewTime,
					r.Relationship as Relationship
				from 
					UserRelationship r,
					Users host,
					Users guest
				where 
					r.HostKey=host.Key and
					r.GuestKey=guest.Key and
					host.UpperName=?
				";

				cmd.Parameters.Add("user", DbType.String).Value = user.ToUpper();

				SQLiteDataAdapter ada = new SQLiteDataAdapter();
				ada.SelectCommand = cmd;

				ada.Fill(result);
				ada.Dispose();

				return result;
			}
			finally
			{
				m_Lock.Exit("GetFriends");
			}
		}

		class AfterUpdateUserInfoParam
		{
			public String User;
			public AfterUpdateUserInfoParam(String user)
			{
				User = user;
			}
		}

		static void AfterUpdateUserInfo(object data)
		{
			AfterUpdateUserInfoParam param = (AfterUpdateUserInfoParam)data;
			AccountInfo info = AccountManagement.Instance.GetUserInfo(param.User);
			foreach (string s in info.Friends)
			{
				try
				{
					if (AccountManagement.Instance.GetUserInfo(s).Type == 0)
						SessionManagement.Instance.SendCommand(s, "ManagementCommand", Utility.RenderHashJson(null, "Action", "RefreshFriends", "Data", JsonText.EmptyObject));
				}
				catch
				{
				}
			}
		}

		/// <summary>
		/// 更新用户信息
		/// </summary>
		/// <param name="name"></param>
		/// <param name="values"></param>
		public void UpdateUserInfo(string name, Hashtable values)
		{
			m_Lock.Enter("UpdateUserInfo");
			try
			{

				SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);

				conn.Open();
				try
				{
					if (values.ContainsKey("Password"))
					{
						if (!values.ContainsKey("PreviousPassword")) throw new Exception("原密码错误！");

						SQLiteCommand checkPwdCmd = new SQLiteCommand();
						checkPwdCmd.Connection = conn;
						checkPwdCmd.CommandText = "select Key from Users where UpperName = ? and Password = ?";

						checkPwdCmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
						checkPwdCmd.Parameters.Add("Password", DbType.String).Value = Utility.MD5(values["PreviousPassword"].ToString());

						object val = checkPwdCmd.ExecuteScalar();

						if (val == null) throw new Exception("原密码错误！");
					}

					StringBuilder cmdText = new StringBuilder();
					cmdText.Append("update Users set Name = Name");
					if (values.ContainsKey("Nickname")) cmdText.Append(",Nickname = ?");
					if (values.ContainsKey("Password")) cmdText.Append(",Password = ?");
					if (values.ContainsKey("EMail")) cmdText.Append(",EMail = ?");
					if (values.ContainsKey("InviteCode")) cmdText.Append(",InviteCode = ?");
					if (values.ContainsKey("AcceptStrangerIM")) cmdText.Append(",AcceptStrangerIM = ?");
					if (values.ContainsKey("MsgFileLimit")) cmdText.Append(",MsgFileLimit = ?");
					if (values.ContainsKey("MsgImageLimit")) cmdText.Append(",MsgImageLimit = ?");
					if (values.ContainsKey("HomePage")) cmdText.Append(",HomePage = ?");
					cmdText.Append(" where UpperName=?");
					if (values.ContainsKey("PreviousPassword")) cmdText.Append(" and Password = ?");
					SQLiteCommand cmd = new SQLiteCommand();
					cmd.Connection = conn;
					cmd.CommandText = cmdText.ToString();

					if (values.ContainsKey("Nickname")) cmd.Parameters.Add("Nickname", DbType.String).Value = values["Nickname"];
					if (values.ContainsKey("Password")) cmd.Parameters.Add("Password", DbType.String).Value = Utility.MD5(values["Password"] as string);
					if (values.ContainsKey("EMail")) cmd.Parameters.Add("EMail", DbType.String).Value = values["EMail"];
					if (values.ContainsKey("InviteCode")) cmd.Parameters.Add("InviteCode", DbType.String).Value = values["InviteCode"];

					if (values.ContainsKey("AcceptStrangerIM")) cmd.Parameters.Add("AcceptStrangerIM", DbType.Int64).Value = ((bool)values["AcceptStrangerIM"]) ? 1 : 0;
					if (values.ContainsKey("MsgFileLimit")) cmd.Parameters.Add("MsgFileLimit", DbType.Int64).Value = (Int64)(Double)values["MsgFileLimit"];
					if (values.ContainsKey("MsgImageLimit")) cmd.Parameters.Add("MsgImageLimit", DbType.Int64).Value = (Int64)(Double)values["MsgImageLimit"];

					if (values.ContainsKey("HomePage")) cmd.Parameters.Add("HomePage", DbType.String).Value = values["HomePage"];
					
					cmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
					if (values.ContainsKey("PreviousPassword")) cmd.Parameters.Add("PreviousPassword", DbType.String).Value = Utility.MD5(values["PreviousPassword"] as string);

					cmd.ExecuteNonQuery();
				}
				finally
				{
					conn.Close();
				}

				RefreshUserInfo(name);
				ThreadPool.QueueUserWorkItem(new WaitCallback(AfterUpdateUserInfo), new AfterUpdateUserInfoParam(name));
			}
			finally
			{
				m_Lock.Exit("UpdateUserInfo");
			}
		}

		class AfterAddFriendParam
		{
			public AccountInfo User, Friend;
			public AfterAddFriendParam(AccountInfo user, AccountInfo friend)
			{
				User = user;
				Friend = friend;
			}
		}

		static void AfterAddFriend(object data)
		{
			try
			{
				AfterAddFriendParam param = data as AfterAddFriendParam;

				if (param.User.Type == 1)
				{
					//MessageManager.Instance.Delete(userInfo.Creator, index);
					MessageManagement.Instance.Add(param.Friend.Name, "administrator", String.Format("NOTIFY:您已加入群\"{0}\"", param.User.NickName), 1);
					MessageManagement.Instance.Add(param.User.Name, "administrator", String.Format("NOTIFY:\"{0}\"已加入群\"{1}\"", param.Friend.Name, param.User.NickName), 1);
				}
				else
				{
					//MessageManager.Instance.Delete(user, index);
					MessageManagement.Instance.Add(param.Friend.Name, "administrator", String.Format("NOTIFY:\"{0}\"已添加您为好友！", param.User.Name), 1);
					MessageManagement.Instance.Add(param.User.Name, "administrator", String.Format("NOTIFY:您已添加\"{0}\"为好友！", param.Friend.Name), 1);
					SessionManagement.Instance.SendCommand(param.User.Name, "ManagementCommand", Utility.RenderHashJson(null, "Action", "RefreshFriends", "Data", JsonText.EmptyObject));
				}
				SessionManagement.Instance.SendCommand(param.Friend.Name, "ManagementCommand", Utility.RenderHashJson(null, "Action", "RefreshFriends", "Data", JsonText.EmptyObject));
			}
			catch
			{
			}
		}

		/// <summary>
		/// 添加好友
		/// </summary>
		/// <param name="user"></param>
		/// <param name="friend"></param>
		/// <param name="index"></param>
		public void AddFriend(string user, string friend, int index)
		{
			m_Lock.Enter("AddFriend");
			try
			{
				if (GetRelationship(user, friend) == -1)
				{
					AddFriend(user, friend);
				}
			}
			finally
			{
				m_Lock.Exit("AddFriend");
			}
		}

		public void AddFriend(string user, string friend)
		{
			m_Lock.Enter("AddFriend");
			try
			{
				AccountInfo userInfo = AccountManagement.Instance.GetUserInfo(user);
				AccountInfo friendInfo = AccountManagement.Instance.GetUserInfo(friend);

				if (String.Compare(user, friend, true) != 0 && !userInfo.ContainsFriend(friend))
				{
					SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
					SQLiteCommand cmd = new SQLiteCommand();
					cmd.Connection = conn;
					cmd.CommandText = @"
						insert into UserRelationship (HostKey,GuestKey,Relationship,RenewTime)
						select host.Key as HostKey,guest.Key as GuestKey,0,? as Relationship
						from Users host,Users guest
						where (host.UpperName=? or host.UpperName=?) and (guest.UpperName=? or guest.UpperName=?) and host.Key<>guest.Key
					";

					cmd.Parameters.Add("RenewTime", DbType.DateTime).Value = DateTime.Now;
					cmd.Parameters.Add("Host1", DbType.String).Value = user.ToUpper();
					cmd.Parameters.Add("Client1", DbType.String).Value = friend.ToUpper();
					cmd.Parameters.Add("Host2", DbType.String).Value = user.ToUpper();
					cmd.Parameters.Add("Client2", DbType.String).Value = friend.ToUpper();

					conn.Open();
					try
					{
						cmd.ExecuteNonQuery();
					}
					finally
					{
						conn.Close();
					}

					RefreshUserInfo(user);
					RefreshUserInfo(friend);

					ThreadPool.QueueUserWorkItem(new WaitCallback(AfterAddFriend), new AfterAddFriendParam(userInfo, friendInfo));
				}
			}
			finally
			{
				m_Lock.Exit("AddFriend");
			}
		}

		class AfterDeleteFriendParam
		{
			public AccountInfo User, Friend;
			public AfterDeleteFriendParam(AccountInfo user, AccountInfo friend)
			{
				User = user;
				Friend = friend;
			}
		}

		static void AfterDeleteFriend(object data)
		{
			try
			{
				AfterDeleteFriendParam param = data as AfterDeleteFriendParam;
				if (param.Friend.Type == 1)
				{
					MessageManagement.Instance.Add(param.User.Name, "administrator", String.Format("NOTIFY:您已退出群\"{0}\"", param.Friend.NickName), 1);
					MessageManagement.Instance.Add(param.Friend.Name, "administrator", String.Format("NOTIFY:\"{0}\"已退出群\"{1}\"", param.User.Name, param.Friend.NickName), 1);
				}
				else
				{
					MessageManagement.Instance.Add(param.Friend.Name, "administrator", String.Format("NOTIFY:\"{0}\"已将您从好友中删除！", param.User.Name), 1);
					SessionManagement.Instance.SendCommand(param.Friend.Name, "ManagementCommand", Utility.RenderHashJson(null, "Action", "RefreshFriends", "Data", JsonText.EmptyObject));
				}
				SessionManagement.Instance.SendCommand(param.User.Name, "ManagementCommand", Utility.RenderHashJson(null, "Action", "RefreshFriends", "Data", JsonText.EmptyObject));
			}
			catch
			{
			}
		}

		/// <summary>
		/// 删除好友
		/// </summary>
		/// <param name="user"></param>
		/// <param name="friend"></param>
		public void DeleteFriend(string user, string friend)
		{
			m_Lock.Enter("DeleteFriend");
			try
			{
				if (GetRelationship(user, friend) != -1)
				{
					AccountInfo userInfo = GetUserInfo(user);
					AccountInfo friendInfo = GetUserInfo(friend);

					SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
					SQLiteCommand cmd = new SQLiteCommand();
					cmd.Connection = conn;
					cmd.CommandText = @"
						delete from UserRelationship
						where (HostKey=? and GuestKey=?) or (HostKey=? and GuestKey=?)
					";

					cmd.Parameters.Add("Host1", DbType.Int64).Value = userInfo.ID;
					cmd.Parameters.Add("Client1", DbType.Int64).Value = friendInfo.ID;
					cmd.Parameters.Add("Host2", DbType.Int64).Value = friendInfo.ID;
					cmd.Parameters.Add("Client2", DbType.Int64).Value = userInfo.ID;

					conn.Open();
					try
					{
						cmd.ExecuteNonQuery();
					}
					finally
					{
						conn.Close();
					}

					RefreshUserInfo(user);
					RefreshUserInfo(friend);

					ThreadPool.QueueUserWorkItem(new WaitCallback(AfterDeleteFriend), new AfterDeleteFriendParam(userInfo, friendInfo));
				}
			}
			finally
			{
				m_Lock.Exit("DeleteFriend");
			}
		}

		class AfterDeleteGroupParam
		{
			public String GroupName;
			public string[] Members;
			public AfterDeleteGroupParam(String groupName, string[] members)
			{
				GroupName = groupName;
				Members = members;
			}
		}

		static void AfterDeleteGroup(object data)
		{
			AfterDeleteGroupParam param = data as AfterDeleteGroupParam;
			foreach (String member in param.Members)
			{
				try
				{
					MessageManagement.Instance.Add(member, "administrator", String.Format("NOTIFY:群\"{0}\"已解散！", param.GroupName), 1);
					SessionManagement.Instance.SendCommand(member, "ManagementCommand", Utility.RenderHashJson(null, "Action", "RefreshFriends", "Data", JsonText.EmptyObject));
				}
				catch
				{
				}
			}
		}

		/// <summary>
		/// 删除群
		/// </summary>
		/// <param name="name"></param>
		/// <param name="creator"></param>
		public void DeleteGroup(String name, String creator)
		{
			m_Lock.Enter("DeleteGroup");
			try
			{
				AccountInfo info = GetUserInfo(name);
				List<String> members = new List<string>();
				foreach (string s in info.Friends) members.Add(s);

				SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
				conn.Open();
				SQLiteTransaction tran = conn.BeginTransaction();
				try
				{
					SQLiteCommand selectCmd = new SQLiteCommand(
						@"select Key from Users where UpperName=?", conn
					);
					selectCmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
					object key = selectCmd.ExecuteScalar();
					if (key == null) throw new Exception(String.Format("群 {0} 不存在！", name));

					SQLiteCommand deleteUR = new SQLiteCommand(
						@"delete from User_Role where UserKey=?", conn
					);
					deleteUR.Parameters.Add("Key", DbType.Int64).Value = key;
					deleteUR.ExecuteNonQuery();

					SQLiteCommand deleteRelationship = new SQLiteCommand(
						@"delete from UserRelationship where HostKey=? or GuestKey=?", conn
					);
					deleteRelationship.Parameters.Add("Key1", DbType.Int64).Value = key;
					deleteRelationship.Parameters.Add("Key2", DbType.Int64).Value = key;
					deleteRelationship.ExecuteNonQuery();

					SQLiteCommand deleteUser = new SQLiteCommand(
						@"delete from Users where Key=?", conn
					);
					deleteUser.Parameters.Add("Key", DbType.Int64).Value = key;
					deleteUser.ExecuteNonQuery();

					tran.Commit();
				}
				catch
				{
					tran.Rollback();
					throw;
				}
				finally
				{
					conn.Close();
				}

				string groupRoot = String.Format("/{0}/Groups/{1}", creator, name);
				Directory.Delete(groupRoot);

				RefreshUserInfo(creator);

				ThreadPool.QueueUserWorkItem(new WaitCallback(AfterDeleteGroup), new AfterDeleteGroupParam(name, members.ToArray()));
			}
			finally
			{
				m_Lock.Exit("CreateGroup");
			}
		}

		class AfterCreateGroupParam
		{
			public String Creator;
			public AfterCreateGroupParam(String creator)
			{
				Creator = creator;
			}
		}

		static void AfterCreateGroup(object data)
		{
			try
			{
				AfterCreateGroupParam param = data as AfterCreateGroupParam;
				SessionManagement.Instance.SendCommand(param.Creator, "ManagementCommand", Utility.RenderHashJson(null, "Action", "RefreshFriends", "Data", JsonText.EmptyObject));
			}
			catch
			{
			}
		}

		public string CreateTempraryUser()
		{
			m_Lock.Enter("CreateTempraryUser");
			try
			{

				SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
				conn.Open();
				try
				{
					SQLiteTransaction tran = conn.BeginTransaction();
					try
					{
						String name = "U";
						while (true)
						{
							name = String.Format("U{0}", ((new Random()).Next() + DateTime.Now.Ticks) % 1000000000 + 1000000000);
							SQLiteCommand selectCmd = new SQLiteCommand(
								@"select Key from Users where UpperName=?", conn
							);
							selectCmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
							object key = selectCmd.ExecuteScalar();
							if (key == null) break;
						}
						String nickname = "游客"+name;

						SQLiteCommand insertUser = new SQLiteCommand(
							@"
							insert into Users (Name,UpperName,Password,Nickname,Type,EMail,InviteCode,IsTemp,RegisterTime) values (?,?,?,?,?,?,?,1,?)
							", conn
						);
						insertUser.Parameters.Add("Name", DbType.String).Value = name;
						insertUser.Parameters.Add("UpperName", DbType.String).Value = name.ToUpper();
						insertUser.Parameters.Add("Password", DbType.String).Value = "";
						insertUser.Parameters.Add("Nickname", DbType.String).Value = nickname;
						insertUser.Parameters.Add("Type", DbType.Int64).Value = 0;
						insertUser.Parameters.Add("EMail", DbType.String).Value = "";
						insertUser.Parameters.Add("InviteCode", DbType.String).Value = Guid.NewGuid().ToString().ToUpper().Replace("-", "");
						insertUser.Parameters.Add("RegisterTime", DbType.DateTime).Value = DateTime.Now;
						insertUser.ExecuteNonQuery();

						SQLiteCommand insertUR = new SQLiteCommand(
							@"
							insert into User_Role (UserKey,RoleKey)
							select Key as UserKey,2 as RoleKey from Users where UpperName=?
							", conn
						);
						insertUR.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
						insertUR.ExecuteNonQuery();

						Directory.CreateDirectory(String.Format("/{0}", name));
						try
						{
							Directory.CreateDirectory(String.Format("/{0}/Config", name));
							Directory.CreateDirectory(String.Format("/{0}/Groups", name));
							Directory.CreateDirectory(String.Format("/{0}/Home", name));
							Directory.CreateDirectory(String.Format("/{0}/Message", name));
							Directory.CreateDirectory(String.Format("/{0}/Temp", name));
							Directory.CreateDirectory(String.Format("/{0}/Share", name));
						}
						catch
						{
							Directory.Delete(String.Format("/{0}", name));
							throw;
						}

						tran.Commit();

						return name;
					}
					catch
					{
						tran.Rollback();
						throw;
					}
				}
				finally
				{
					conn.Close();
				}
			}
			finally
			{
				m_Lock.Exit("CreateTempraryUser");
			}
		}

		public void CreateUser(String name, String nickname, String password, String email)
		{
			m_Lock.Enter("CreateUser");
			try
			{
				SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
				conn.Open();
				try
				{
					SQLiteTransaction tran = conn.BeginTransaction();
					try
					{
						SQLiteCommand selectCmd = new SQLiteCommand(
							@"select Key from Users where UpperName=?", conn
						);
						selectCmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
						object key = selectCmd.ExecuteScalar();
						if (key != null && key != DBNull.Value)
						{
							throw new Exception(String.Format("用户\"{0}\"已存在！", name));
						}

						SQLiteCommand insertUser = new SQLiteCommand(
							@"
						insert into Users (Name,UpperName,Password,Nickname,Type,EMail,InviteCode,IsTemp,RegisterTime) values (?,?,?,?,?,?,?,0,?)
						", conn
						);
						insertUser.Parameters.Add("Name", DbType.String).Value = name;
						insertUser.Parameters.Add("UpperName", DbType.String).Value = name.ToUpper();
						insertUser.Parameters.Add("Password", DbType.String).Value = Utility.MD5(password);
						insertUser.Parameters.Add("Nickname", DbType.String).Value = nickname;
						insertUser.Parameters.Add("Type", DbType.Int64).Value = 0;
						insertUser.Parameters.Add("EMail", DbType.String).Value = email;
						insertUser.Parameters.Add("InviteCode", DbType.String).Value = Guid.NewGuid().ToString().ToUpper().Replace("-", "");
						insertUser.Parameters.Add("RegisterTime", DbType.DateTime).Value = DateTime.Now;
						insertUser.ExecuteNonQuery();

						SQLiteCommand insertUR = new SQLiteCommand(
							@"
						insert into User_Role (UserKey,RoleKey)
						select Key as UserKey,2 as RoleKey from Users where UpperName=?
						", conn
						);
						insertUR.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
						insertUR.ExecuteNonQuery();

						Directory.CreateDirectory(String.Format("/{0}", name));
						try
						{
							Directory.CreateDirectory(String.Format("/{0}/Config", name));
							Directory.CreateDirectory(String.Format("/{0}/Groups", name));
							Directory.CreateDirectory(String.Format("/{0}/Home", name));
							Directory.CreateDirectory(String.Format("/{0}/Message", name));
							Directory.CreateDirectory(String.Format("/{0}/Temp", name));
							Directory.CreateDirectory(String.Format("/{0}/Share", name));
						}
						catch
						{
							Directory.Delete(String.Format("/{0}", name));
							throw;
						}

						tran.Commit();
					}
					catch
					{
						tran.Rollback();
						throw;
					}
				}
				finally
				{
					conn.Close();
				}
			}
			finally
			{
				m_Lock.Exit("CreateUser");
			}
		}

		/// <summary>
		/// 创建群
		/// </summary>
		/// <param name="creator"></param>
		/// <param name="name"></param>
		/// <param name="nickname"></param>
		public void CreateGroup(String creator, String name, String nickname)
		{
			m_Lock.Enter("CreateGroup");
			try
			{
				SQLiteConnection conn = new SQLiteConnection(Server.Instance.ConnectionString);
				conn.Open();
				SQLiteTransaction tran = conn.BeginTransaction();
				try
				{
					SQLiteCommand selectCmd = new SQLiteCommand(
						@"select Key from Users where UpperName=?", conn
					);
					selectCmd.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
					object key = selectCmd.ExecuteScalar();
					if (key != null && key != DBNull.Value)
					{
						throw new Exception(String.Format("群\"{0}\"已存在！", name));
					}

					SQLiteCommand insertUser = new SQLiteCommand(
						@"
						insert into Users (Name,UpperName,Password,Nickname,Type,EMail,InviteCode,IsTemp,RegisterTime) values (?,?,?,?,?,?,?,0,?)
						", conn
					);
					insertUser.Parameters.Add("Name", DbType.String).Value = name;
					insertUser.Parameters.Add("UpperName", DbType.String).Value = name.ToUpper();
					insertUser.Parameters.Add("Password", DbType.String).Value = "";
					insertUser.Parameters.Add("Nickname", DbType.String).Value = nickname;
					insertUser.Parameters.Add("Type", DbType.Int64).Value = 1;
					insertUser.Parameters.Add("EMail", DbType.String).Value = "";
					insertUser.Parameters.Add("InviteCode", DbType.String).Value = Guid.NewGuid().ToString().ToUpper().Replace("-", "");
					insertUser.Parameters.Add("RegisterTime", DbType.DateTime).Value = DateTime.Now;
					insertUser.ExecuteNonQuery();

					SQLiteCommand insertUR = new SQLiteCommand(
						@"
						insert into User_Role (UserKey,RoleKey)
						select Key as UserKey,2 as RoleKey from Users where UpperName=?
						", conn
					);
					insertUR.Parameters.Add("Name", DbType.String).Value = name.ToUpper();
					insertUR.ExecuteNonQuery();

					SQLiteCommand insertRelationship = new SQLiteCommand(
						@"
						insert into UserRelationship (RenewTime,HostKey,GuestKey,Relationship)
						select ? as RenewTime,(select Key from Users where UpperName=?) as HostKey,(select Key from Users where UpperName=?) as GuestKey,3 as Relationship
						",
						conn
					);
					insertRelationship.Parameters.Add("RenewTime", DbType.DateTime).Value = DateTime.Now;
					insertRelationship.Parameters.Add("Host", DbType.String);
					insertRelationship.Parameters.Add("Guest", DbType.String);

					insertRelationship.Parameters["Host"].Value = name.ToUpper();
					insertRelationship.Parameters["Guest"].Value = creator.ToUpper();
					insertRelationship.ExecuteNonQuery();

					insertRelationship.Parameters["Host"].Value = creator.ToUpper();
					insertRelationship.Parameters["Guest"].Value = name.ToUpper();
					insertRelationship.ExecuteNonQuery();

					string groupRoot = String.Format("/{0}/Groups/{1}", creator, name);

					Directory.CreateDirectory(groupRoot);
					try
					{
						Directory.CreateDirectory(String.Format("{0}/Config", groupRoot));
						Directory.CreateDirectory(String.Format("{0}/Home", groupRoot));
						Directory.CreateDirectory(String.Format("{0}/Message", groupRoot));
						Directory.CreateDirectory(String.Format("{0}/Temp", groupRoot));
					}
					catch
					{
						Directory.Delete(String.Format("/{0}", groupRoot));
						throw;
					}

					tran.Commit();
				}
				catch
				{
					tran.Rollback();
					throw;
				}
				finally
				{
					conn.Close();
				}

				RefreshUserInfo(creator);
				ThreadPool.QueueUserWorkItem(new WaitCallback(AfterCreateGroup), new AfterCreateGroupParam(creator));
			}
			finally
			{
				m_Lock.Exit("CreateGroup");
			}
		}
	}

	public class AccountInfo : IRenderJson
	{
		Lock m_Lock = new Lock("UserInfo", 198);

		private String m_Name, m_NickName;
		private Int64 m_ID, m_Type;
		private String[] m_Roles;
		private FriendInfo[] m_Friends;
		private FriendInfo m_Creator;
		private String m_EMail, m_InviteCode;
		private Int64 m_DiskSize;
		private bool m_IsTemp;

		Hashtable m_FriendIndex = null;
		Hashtable m_Managers = null;

		bool m_AcceptStrangerIM;
		Int64 m_IMFileLimit, m_IMImageLimit;

		DateTime m_RegisterTime = DateTime.Now;

		String m_HomePage = String.Empty;

		public AccountInfo(
			String name, String nickname, Int64 id, Int64 type, String[] roles, 
			FriendInfo[] friends, FriendInfo[] managers, FriendInfo creator,
			String email, String inviteCode,
			bool acceptStrangerIM, Int64 imf_limite, Int64 imimage_limit,
			Int64 diskSize, Int64 isTemp,
			DateTime registerTime,
			String homePage
		)
		{
			Reset(name, nickname, id, type, roles, friends, managers, creator, email, inviteCode, acceptStrangerIM, imf_limite, imimage_limit, diskSize, isTemp, registerTime, homePage);
		}

		public void Reset(
			String name, String nickname, Int64 id, Int64 type, String[] roles, 
			FriendInfo[] friends, FriendInfo[] managers, FriendInfo creator, 
			String email, String inviteCode,
			bool acceptStrangerIM, Int64 imf_limite, Int64 imimage_limit,
			Int64 diskSize,Int64 isTemp,
			DateTime registerTime,
			String homePage
		)
		{
			m_Lock.Enter("Reset");
			try
			{
				m_FriendIndex = new Hashtable();
				m_Managers = new Hashtable();
				m_Name = name;
				m_NickName = nickname;
				m_ID = id;
				m_Type = type;
				m_Roles = roles;
				m_Friends = friends;
				m_Creator = creator;
				m_EMail = email;
				m_InviteCode = inviteCode;

				m_AcceptStrangerIM = acceptStrangerIM;
				m_IMFileLimit = imf_limite;
				m_IMImageLimit = imimage_limit;

				m_IsTemp = (isTemp != 0);

				m_HomePage = homePage;

				m_DiskSize = diskSize;

				foreach (FriendInfo friend in friends)
				{
					m_FriendIndex.Add(friend.Name.ToUpper(), friend);
				}

				if (managers != null)
				{
					foreach (FriendInfo friend in managers)
					{
						m_Managers.Add(friend.Name.ToUpper(), friend);
					}
				}

				m_RegisterTime = registerTime;
			}
			finally
			{
				m_Lock.Exit("Reset");
			}
		}

		public String[] Friends
		{
			get
			{
				m_Lock.Enter("Friends");
				try
				{
					String[] array = new String[m_Friends.Length];
					for (int i = 0; i < m_Friends.Length; i++) array[i] = m_Friends[i].Name;
					return array;
				}
				finally
				{
					m_Lock.Exit("Friends");
				}
			}
		}

		public String[] Roles
		{
			get
			{
				m_Lock.Enter("Roles");
				try
				{
					String[] array = new String[m_Roles.Length];
					m_Roles.CopyTo(array, 0);
					return array;
				}
				finally
				{
					m_Lock.Exit("Roles");
				}
			}
		}

		public Boolean IsTemp
		{
			get
			{
				m_Lock.Enter("IsTemp");
				try
				{
					return m_IsTemp;
				}
				finally
				{
					m_Lock.Exit("IsTemp");
				}
			}
		}

		public String Creator
		{
			get
			{
				m_Lock.Enter("Creator");
				try
				{
					return m_Creator.Name;
				}
				finally
				{
					m_Lock.Exit("Creator");
				}
			}
		}

		public String[] Groups
		{
			get
			{
				m_Lock.Enter("Groups");
				try
				{
					List<String> groups = new List<string>();
					foreach (FriendInfo friend in m_Friends)
					{
						if(friend.PeerType == 1) groups.Add(friend.Name);
					}
					return groups.ToArray();
				}
				finally
				{
					m_Lock.Exit("Groups");
				}
			}
		}

		public Int64 Type
		{
			get
			{
				m_Lock.Enter("Type");
				try
				{
					return m_Type;
				}
				finally
				{
					m_Lock.Exit("Type");
				}
			}
		}

		public bool AcceptStrangerIM
		{
			get
			{
				m_Lock.Enter("AcceptStrangerIM");
				try
				{
					return m_AcceptStrangerIM;
				}
				finally
				{
					m_Lock.Exit("AcceptStrangerIM");
				}
			}
		}

		public Int64 MsgFileLimit
		{
			get
			{
				m_Lock.Enter("IMFileLimit");
				try
				{
					return m_IMFileLimit;
				}
				finally
				{
					m_Lock.Exit("IMFileLimit");
				}
			}
		}

		public Int64 MsgImageLimit
		{
			get
			{
				m_Lock.Enter("IMImageLimit");
				try
				{
					return m_IMImageLimit;
				}
				finally
				{
					m_Lock.Exit("IMImageLimit");
				}
			}
		}

		public String NickName
		{
			get
			{
				m_Lock.Enter("NickName");
				try
				{
					return m_NickName;
				}
				finally
				{
					m_Lock.Exit("NickName");
				}
			}
		}

		public String EMail
		{
			get
			{
				m_Lock.Enter("EMail");
				try
				{
					return m_EMail;
				}
				finally
				{
					m_Lock.Exit("EMail");
				}
			}
		}

		public String HomePage
		{
			get
			{
				m_Lock.Enter("HomePage");
				try
				{
					return m_HomePage;
				}
				finally
				{
					m_Lock.Exit("HomePage");
				}
			}
		}

		public String Name
		{
			get
			{
				m_Lock.Enter("Name");
				try
				{
					return m_Name;
				}
				finally
				{
					m_Lock.Exit("Name");
				}
			}
		}

		public Int64 DiskSize
		{
			get
			{
				if (Type == 1)
				{
					return AccountManagement.Instance.GetUserInfo(m_Creator.Name).DiskSize;
				}
				else
				{
					m_Lock.Enter("DiskSize");
					try
					{
						return m_DiskSize * 1024 * 1024;
					}
					finally
					{
						m_Lock.Exit("DiskSize");
					}
				}
			}
		}

		public String InviteCode
		{
			get
			{
				m_Lock.Enter("InviteCode");
				try
				{
					return m_InviteCode;
				}
				finally
				{
					m_Lock.Exit("InviteCode");
				}
			}
		}

		public Int64 ID
		{
			get
			{
				m_Lock.Enter("ID");
				try
				{
					return m_ID;
				}
				finally
				{
					m_Lock.Exit("ID");
				}
			}
		}

		public DateTime RegisterTime
		{
			get
			{
				m_Lock.Enter("RegisterTime");
				try
				{
					return m_RegisterTime;
				}
				finally
				{
					m_Lock.Exit("RegisterTime");
				}
			}
		}

		public bool IsRole(string role)
		{
			m_Lock.Enter("IsRole");
			try
			{
				foreach (string s in Roles)
				{
					if (s == role) return true;
				}
				return false;
			}
			finally
			{
				m_Lock.Exit("IsRole");
			}
		}

		public bool ContainsFriend(string name)
		{
			m_Lock.Enter("ContainsFriend");
			try
			{
				return m_FriendIndex.ContainsKey(name.ToUpper());
			}
			finally
			{
				m_Lock.Exit("ContainsFriend");
			}
		}

		public bool ContainsMember(string name)
		{
			m_Lock.Enter("ContainsMember");
			try
			{
				return m_FriendIndex.ContainsKey(name.ToUpper());
			}
			finally
			{
				m_Lock.Exit("ContainsMember");
			}
		}

		public bool IsManagedBy(string name)
		{
			m_Lock.Enter("IsManagedBy");
			try
			{
				return Type == 1 && m_Managers.ContainsKey(name.ToUpper());
			}
			finally
			{
				m_Lock.Exit("IsManagedBy");
			}
		}

		public bool IsCreatedBy(string name)
		{
			m_Lock.Enter("IsCreatedBy");
			try
			{
				return Type == 1 && String.Compare(name, m_Creator.Name, true) == 0;
			}
			finally
			{
				m_Lock.Exit("IsCreatedBy");
			}
		}

		public DateTime GetGroupMemberRenewTime(string user)
		{
			m_Lock.Enter("GetGroupMemberRenewTime");
			try
			{
				string key = user.ToUpper();
				return (m_FriendIndex[key] as FriendInfo).RenewTime;
			}
			finally
			{
				m_Lock.Exit("GetGroupMemberRenewTime");
			}
		}

		void IRenderJson.RenderJson(StringBuilder builder, HttpContext context)
		{
			String[] friends = Friends;

			StringBuilder friendsJson = new StringBuilder();
			friendsJson.Append("[");
			for (int i = 0; i < friends.Length; i++)
			{
				AccountInfo friendInfo = AccountManagement.Instance.GetUserInfo(friends[i]);

				if (i > 0) friendsJson.Append(",");
				friendsJson.Append("{");
				friendsJson.Append("\"ID\":");
				Utility.RenderJson(friendsJson, friendInfo.ID, context);
				friendsJson.Append(",\"Type\":");
				Utility.RenderJson(friendsJson, friendInfo.Type, context);
				friendsJson.Append(",\"Name\":");
				Utility.RenderJson(friendsJson, friendInfo.Name, context);
				friendsJson.Append(",\"Nickname\":");
				Utility.RenderJson(friendsJson, friendInfo.NickName, context);
				if (friendInfo.Type == 1)
				{
					friendsJson.Append(",\"Creator\":");
					Utility.RenderJson(friendsJson, friendInfo.Creator, context);
				}
				friendsJson.Append("}");
			}
			friendsJson.Append("]");

			Int64 diskSize = DiskSize;

			m_Lock.Enter("RenderJson");
			try
			{
				String currentUser = ((context == null || !context.User.Identity.IsAuthenticated) ? "" : context.User.Identity.Name);

				if (m_Type == 1)
				{
					builder.Append("{");
					builder.Append("\"ID\":");
					Utility.RenderJson(builder, m_ID, context);
					builder.Append(",\"Name\":");
					Utility.RenderJson(builder, m_Name, context);
					builder.Append(",\"Nickname\":");
					Utility.RenderJson(builder, m_NickName, context);
					builder.Append(",\"Type\":");
					Utility.RenderJson(builder, m_Type, context);
					builder.Append(",\"Creator\":");
					Utility.RenderJson(builder, m_Creator.Name, context);
					builder.Append(",\"RegisterTime\":");
					Utility.RenderJson(builder, m_RegisterTime, context);
					if (ContainsMember(currentUser))
					{
						builder.Append(",\"AcceptStrangerIM\":");
						Utility.RenderJson(builder, m_AcceptStrangerIM, context);
						builder.Append(",\"MsgFileLimit\":");
						Utility.RenderJson(builder, m_IMFileLimit, context);
						builder.Append(",\"MsgImageLimit\":");
						Utility.RenderJson(builder, m_IMImageLimit, context);

						builder.Append(",\"DiskSize\":");
						Utility.RenderJson(builder, diskSize, context);

						builder.Append(",\"Members\":");
						builder.Append(friendsJson);
					}
					if (IsCreatedBy(currentUser))
					{
						builder.Append(",\"InviteCode\":");
						Utility.RenderJson(builder, m_InviteCode, context);
					}
					builder.Append("}");
				}
				else
				{
					builder.Append("{");
					builder.Append("\"ID\":");
					Utility.RenderJson(builder, m_ID, context);
					builder.Append(",\"Name\":");
					Utility.RenderJson(builder, m_Name, context);
					builder.Append(",\"Nickname\":");
					Utility.RenderJson(builder, m_NickName, context);
					builder.Append(",\"IsTemp\":");
					Utility.RenderJson(builder, m_IsTemp, context);
					builder.Append(",\"Type\":");
					Utility.RenderJson(builder, m_Type, context);
					builder.Append(",\"Roles\":");
					Utility.RenderJson(builder, m_Roles, context);
					builder.Append(",\"RegisterTime\":");
					Utility.RenderJson(builder, m_RegisterTime, context);
					if (String.Compare(m_Name, currentUser, true) == 0)
					{
						builder.Append(",\"HomePage\":");
						Utility.RenderJson(builder, m_HomePage, context);
						builder.Append(",\"AcceptStrangerIM\":");
						Utility.RenderJson(builder, m_AcceptStrangerIM, context);
						builder.Append(",\"MsgFileLimit\":");
						Utility.RenderJson(builder, m_IMFileLimit, context);
						builder.Append(",\"MsgImageLimit\":");
						Utility.RenderJson(builder, m_IMImageLimit, context);
						builder.Append(",\"EMail\":");
						Utility.RenderJson(builder, m_EMail, context);
						builder.Append(",\"Friends\":");
						builder.Append(friendsJson);
						builder.Append(",\"InviteCode\":");
						Utility.RenderJson(builder, m_InviteCode, context);

						builder.Append(",\"DiskSize\":");
						Utility.RenderJson(builder, diskSize, context);
					}
					builder.Append("}");
				}
			}
			finally
			{
				m_Lock.Exit("RenderJson");
			}
		}
	}

	public class FriendInfo
	{
		public String Name;
		public DateTime RenewTime;
		public Int64 Relationthip;
		public Int64 PeerType;

		public FriendInfo(string name, DateTime renewTime, Int64 relationthip, Int64 peerType)
		{
			Name = name;
			RenewTime = renewTime;
			Relationthip = relationthip;
			PeerType = peerType;
		}
	}
}
