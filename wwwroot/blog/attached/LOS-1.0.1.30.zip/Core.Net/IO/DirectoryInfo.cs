﻿using System;
using System.Collections.Generic;
using System.Text;
using SIO = System.IO;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Checksums;

namespace Core.IO
{
	public class DirectoryInfo : FileSystemInfo, IRenderJson
	{
		SIO.DirectoryInfo _info = null;
		string _fullName;
		FilePath _path;
		string _name;

		public DirectoryInfo(string fullName)
		{
			_fullName = fullName;
			_name = Path.GetFileName(fullName);
			_path = VirtualPathManagement.Instance.MapPath(fullName);
			if (_path.Type == FilePathType.Local)
			{
				_info = new SIO.DirectoryInfo(_path.Path);
			}
		}

		public override string Name
		{
			get { return _name; }
		}

		public override string FullName
		{
			get
			{
				return _fullName;
			}
		}

		public override FilePathType PathType
		{
			get { return _path.Type; }
		}

		public override FileAttributes Attributes
		{
			get { return (FileAttributes)_info.Attributes; }
		}

		public override DateTime CreationTimeUtc
		{
			get { return _info.CreationTimeUtc; }
		}

		public override DateTime CreationTime
		{
			get { return _info.CreationTime; }
		}

		public override DateTime LastAccessTime
		{
			get { return _info.LastAccessTime; }
		}

		public override DateTime LastAccessTimeUtc
		{
			get { return _info.LastAccessTimeUtc; }
		}

		public override DateTime LastWriteTime
		{
			get { return _info.LastWriteTime; }
		}

		public override DateTime LastWriteTimeUtc
		{
			get { return _info.LastWriteTimeUtc; }
		}

		public FileSystemInfo[] GetFileSystemInfos()
		{
			List<FileSystemInfo> fss = new List<FileSystemInfo>();
			if (PathType == FilePathType.Local)
			{
				string[] subs = VirtualPathManagement.Instance.GetSubVirtualPathNames(FullName);
				foreach (string sub in subs)
				{
					fss.Add(new DirectoryInfo(FullName + "/" + sub));
				}

				foreach (SIO.DirectoryInfo dir in _info.GetDirectories())
				{
					fss.Add(new DirectoryInfo(FullName + "/" + dir.Name));
				}
				foreach (SIO.FileInfo file in _info.GetFiles())
				{
					fss.Add(File.GetFileInfo(FullName + "/" + file.Name));
				}
			}
			return fss.ToArray();
		}

		public FileSystemInfo[] GetDirectoryInfos()
		{
			List<FileSystemInfo> fss = new List<FileSystemInfo>();
			if (PathType == FilePathType.Local)
			{
				string[] subs = VirtualPathManagement.Instance.GetSubVirtualPathNames(FullName);
				foreach (string sub in subs)
				{
					fss.Add(new DirectoryInfo(FullName + "/" + sub));
				}

				foreach (SIO.DirectoryInfo dir in _info.GetDirectories())
				{
					fss.Add(new DirectoryInfo(FullName + "/" + dir.Name));
				}
			}
			return fss.ToArray();
		}

		void IRenderJson.RenderJson(StringBuilder builder, System.Web.HttpContext context)
		{
			Utility.RenderHashJson(
				builder, context,
				"FullName", FullName,
				"Name", Name,
				"Type", "D",
				"LastModifiedTime", LastWriteTime
			);
		}
	}

	public abstract class EmbedDirectoryInfo : FileSystemInfo, IRenderJson
	{
		SIO.FileInfo _info = null;
		string _fullName, _file, _res, _name;
		FilePath _path;

		public EmbedDirectoryInfo(string file,string res)
		{
			_fullName = String.IsNullOrEmpty(res) ? file : file + "/" + res;
			_name = Path.GetFileName(String.IsNullOrEmpty(res) ? file : res);
			_file = file;
			_res = res;

			_path = VirtualPathManagement.Instance.MapPath(file);
			if (_path.Type == FilePathType.Local)
			{
				_info = new SIO.FileInfo(_path.Path);
			}
		}

		protected SIO.FileInfo Info
		{
			get { return _info; }
		}

		public string FilePath
		{
			get { return _file; }
		}

		public string ResourcePath
		{
			get { return _res; }
		}

		public override string Name
		{
			get { return _name; }
		}

		public override string FullName
		{
			get
			{
				return _fullName;
			}
		}

		public override FilePathType PathType
		{
			get { return _path.Type; }
		}

		public override FileAttributes Attributes
		{
			get { return (FileAttributes)(_info.Attributes | SIO.FileAttributes.Directory); }
		}

		public override DateTime CreationTimeUtc
		{
			get { return _info.CreationTimeUtc; }
		}

		public override DateTime CreationTime
		{
			get { return _info.CreationTime; }
		}

		public override DateTime LastAccessTime
		{
			get { return _info.LastAccessTime; }
		}

		public override DateTime LastAccessTimeUtc
		{
			get { return _info.LastAccessTimeUtc; }
		}

		public override DateTime LastWriteTime
		{
			get { return _info.LastWriteTime; }
		}

		public override DateTime LastWriteTimeUtc
		{
			get { return _info.LastWriteTimeUtc; }
		}

		public abstract FileSystemInfo[] GetFileSystemInfos();

		public abstract FileSystemInfo[] GetDirectoryInfos();

		public abstract FileSystemInfo GetItemInfo(string res);

		public abstract SIO.Stream Open(string res);

		protected abstract void RenderJson(StringBuilder builder, System.Web.HttpContext context);

		void IRenderJson.RenderJson(StringBuilder builder, System.Web.HttpContext context)
		{
			RenderJson(builder, context);
		}
	}

	public class ZipDirectoryInfo : EmbedDirectoryInfo
	{
		public ZipDirectoryInfo(string file, string res)
			: base(file, res)
		{
		}

		private static SIO.Stream OpenFile(string path)
		{
			FilePath actualPath = VirtualPathManagement.Instance.MapPath(path);
			if (actualPath.Type == FilePathType.Local)
			{
				return SIO.File.Open(actualPath.Path, SIO.FileMode.Open, SIO.FileAccess.Read, SIO.FileShare.Read);
			}
			else
			{
				return null;
			}
		}

		private static bool IsSubItemOf(string parent, string child)
		{
			if (String.IsNullOrEmpty(parent))
			{
				return !String.IsNullOrEmpty(child) && child.IndexOf('/') == -1;
			}
			else
			{
				if (child.Length <= parent.Length + 2) return false;
				if (child[parent.Length] != '/') return false;
				if (child.IndexOf('/', parent.Length + 1) != -1) return false;
				return String.Compare(child, 0, parent, 0, parent.Length, true) == 0;
			}
		}

		public override FileSystemInfo[] GetFileSystemInfos()
		{
			List<FileSystemInfo> fsi = new List<FileSystemInfo>();
			using (ZipInputStream inputStream = new ZipInputStream(OpenFile(FilePath)))
			{
				try
				{
					ZipEntry theEntry;
					while ((theEntry = inputStream.GetNextEntry()) != null)
					{

						String name = theEntry.Name.Replace('\\', '/');
						if (name.EndsWith("/")) name = name.Substring(0, name.Length - 1); 
						if (IsSubItemOf(ResourcePath, name))
						{
							if (theEntry.IsFile) fsi.Add(new ZipFileInfo(FilePath, name, inputStream.Length));
							else if (theEntry.IsDirectory) fsi.Add(new ZipDirectoryInfo(FilePath, name));
						}
					}
				}
				finally
				{
					inputStream.Close();
				}
			}
			return fsi.ToArray();
		}

		public override FileSystemInfo[] GetDirectoryInfos()
		{
			List<FileSystemInfo> fsi = new List<FileSystemInfo>();
			using (ZipInputStream inputStream = new ZipInputStream(OpenFile(FilePath)))
			{
				try
				{
					ZipEntry theEntry;
					while ((theEntry = inputStream.GetNextEntry()) != null)
					{
						String name = theEntry.Name.Replace('\\', '/');
						if (name.EndsWith("/")) name = name.Substring(0, name.Length - 1); 
						if (IsSubItemOf(ResourcePath, name))
						{
							if (theEntry.IsDirectory) fsi.Add(new ZipDirectoryInfo(FilePath, name));
						}
					}
				}
				finally
				{
					inputStream.Close();
				}
			}
			return fsi.ToArray();
		}

		public override FileSystemInfo GetItemInfo(string res)
		{
			using (ZipInputStream inputStream = new ZipInputStream(OpenFile(FilePath)))
			{
				try
				{
					ZipEntry theEntry;
					while ((theEntry = inputStream.GetNextEntry()) != null)
					{
						String name = theEntry.Name.Replace('\\', '/');
						if (name.EndsWith("/")) name = name.Substring(0, name.Length - 1); 
						if (String.Compare(res, name, true) == 0)
						{
							if (theEntry.IsFile) return new ZipFileInfo(FilePath, name, inputStream.Length);
							else if (theEntry.IsDirectory) return new ZipDirectoryInfo(FilePath, name);
						}
					}
				}
				finally
				{
					inputStream.Close();
				}
			}
			return null;
		}

		public override SIO.Stream Open(string res)
		{
			ZipInputStream inputStream = new ZipInputStream(OpenFile(FilePath));
			try
			{
				ZipEntry theEntry;
				while ((theEntry = inputStream.GetNextEntry()) != null)
				{
					String name = theEntry.Name.Replace('\\', '/');
					if (name.EndsWith("/")) name = name.Substring(0, name.Length - 1);
					if (String.Compare(res, name, true) == 0)
					{
						if (theEntry.IsFile) return inputStream;
					}
				}
				inputStream.Close();
			}
			catch
			{
				inputStream.Close();
			}
			return null;
		}

		protected override void RenderJson(StringBuilder builder, System.Web.HttpContext context)
		{
			Utility.RenderHashJson(
				builder, context,
				"FullName", FullName,
				"Name", Name,
				"Type", String.IsNullOrEmpty(ResourcePath) && String.Compare(System.IO.Path.GetExtension(ResourcePath), ".run", true) != 0 ? "E" : "D",
				"Size", Info.Length,
				"LastModifiedTime", LastWriteTime
			);
		}
	}
}
