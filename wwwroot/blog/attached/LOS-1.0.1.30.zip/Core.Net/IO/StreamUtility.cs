﻿using System;
using System.Collections.Generic;
using System.Text;
using SIO = System.IO;

namespace Core.IO
{
	static class StreamUtility
	{
		static public void Write(SIO.Stream stream, Int32 value)
		{
			byte[] buffer = System.BitConverter.GetBytes(value);
			stream.Write(buffer, 0, buffer.Length);
		}

		static public void Write(SIO.Stream stream, Int64 value)
		{
			byte[] buffer = System.BitConverter.GetBytes(value);
			stream.Write(buffer, 0, buffer.Length);
		}

		static public void Write(SIO.Stream stream, UInt32 value)
		{
			byte[] buffer = System.BitConverter.GetBytes(value);
			stream.Write(buffer, 0, buffer.Length);
		}

		static public void Write(SIO.Stream stream, UInt64 value)
		{
			byte[] buffer = System.BitConverter.GetBytes(value);
			stream.Write(buffer, 0, buffer.Length);
		}


		static public void Write(SIO.Stream stream, String value,int size,Encoding encoding)
		{
			Byte[] buffer = new Byte[size];
			Int32 length = encoding.GetBytes(value, 0, value.Length, buffer, 0);
			Write(stream, length);
			stream.Write(buffer, 0, buffer.Length);
		}

		static public void Write(SIO.Stream stream, String value, Encoding encoding)
		{
			byte[] buffer = encoding.GetBytes(value);
			Write(stream, buffer.Length);
			stream.Write(buffer, 0, buffer.Length);
		}

		static public void Write(SIO.Stream stream, Byte[] buffer)
		{
			stream.Write(buffer, 0, buffer.Length);
		}

		static public Int32 ReadInt32(SIO.Stream stream)
		{
			byte[] buffer = new byte[sizeof(Int32)];
			stream.Read(buffer, 0, sizeof(Int32));
			return System.BitConverter.ToInt32(buffer, 0);
		}

		static public Int64 ReadInt64(SIO.Stream stream)
		{
			byte[] buffer = new byte[sizeof(Int64)];
			stream.Read(buffer, 0, sizeof(Int64));
			return System.BitConverter.ToInt64(buffer, 0);
		}

		static public UInt32 ReadUInt32(SIO.Stream stream)
		{
			byte[] buffer = new byte[sizeof(UInt32)];
			stream.Read(buffer, 0, sizeof(UInt32));
			return System.BitConverter.ToUInt32(buffer, 0);
		}

		static public UInt64 ReadUInt64(SIO.Stream stream)
		{
			byte[] buffer = new byte[sizeof(UInt64)];
			stream.Read(buffer, 0, sizeof(UInt64));
			return System.BitConverter.ToUInt64(buffer, 0);
		}

		static public String ReadString(SIO.Stream stream, int size, Encoding encoding)
		{
			Int32 length = ReadInt32(stream);
			Byte[] buffer = new byte[size];
			stream.Read(buffer, 0, size);
			return encoding.GetString(buffer, 0, length);
		}

		static public String ReadString(SIO.Stream stream, Encoding encoding)
		{
			Int32 length = ReadInt32(stream);
			Byte[] buffer = new byte[length];
			stream.Read(buffer, 0, length);
			return encoding.GetString(buffer, 0, length);
		}

		static public Byte[] ReadBytes(SIO.Stream stream, int size)
		{
			byte[] buffer = new byte[size];
			stream.Read(buffer, 0, size);
			return buffer;
		}
	}
}
