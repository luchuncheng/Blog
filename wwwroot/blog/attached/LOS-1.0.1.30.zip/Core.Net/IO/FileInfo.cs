﻿using System;
using System.Collections.Generic;
using System.Text;
using SIO=System.IO;

namespace Core.IO
{
	public class FileInfo : FileSystemInfo, IRenderJson
	{
		SIO.FileInfo _info = null;
		string _fullName;
		FilePath _path;
		string _name;

		public FileInfo(string fullName)
		{
			_fullName = fullName;
			_name = Path.GetFileName(fullName);
			_path = VirtualPathManagement.Instance.MapPath(fullName);
			if (_path.Type == FilePathType.Local)
			{
				_info = new SIO.FileInfo(_path.Path);
			}
		}

		public override string Name
		{
			get { return _name; }
		}

		public override string FullName
		{
			get
			{
				return _fullName;
			}
		}
		public long Length
		{
			get { return _info.Length; }
		}

		public override FilePathType PathType
		{
			get { return _path.Type; }
		}

		public override FileAttributes Attributes
		{
			get { return (FileAttributes)_info.Attributes; }
		}

		public override DateTime CreationTimeUtc
		{
			get { return _info.CreationTimeUtc; }
		}

		public override DateTime CreationTime
		{
			get { return _info.CreationTime; }
		}

		public override DateTime LastAccessTime
		{
			get { return _info.LastAccessTime; }
		}

		public override DateTime LastAccessTimeUtc
		{
			get { return _info.LastAccessTimeUtc; }
		}

		public override DateTime LastWriteTime
		{
			get { return _info.LastWriteTime; }
		}

		public override DateTime LastWriteTimeUtc
		{
			get { return _info.LastWriteTimeUtc; }
		}

		void IRenderJson.RenderJson(StringBuilder builder, System.Web.HttpContext context)
		{
			//FileInfo info = obj as FileInfo;
			//builder.Append("{");
			//builder.AppendFormat("FullName:'{0}',", info.FullName);
			//builder.AppendFormat("Name:'{0}',", info.Name);
			//builder.AppendFormat("Type:'F',");
			//builder.AppendFormat("Size:{0},", info.Length);
			//builder.Append("LastModifiedTime:");
			//RenderJson(builder, info.LastWriteTime, context);
			//builder.Append("}");

			Utility.RenderHashJson(
				builder, context,
				"FullName", FullName,
				"Name", Name,
				"Type", "F",
				"Size", Length,
				"LastModifiedTime", LastWriteTime
			);
		}
	}

	public abstract class EmbedFileInfo : FileSystemInfo, IRenderJson
	{
		SIO.FileInfo _info = null;
		string _fullName;
		FilePath _path;
		string _name;
		Int64 _size;

		public EmbedFileInfo(string file,string res,Int64 size)
		{
			_fullName = file + "/" + res;
			_name = Path.GetFileName(res);
			_path = VirtualPathManagement.Instance.MapPath(file);
			if (_path.Type == FilePathType.Local)
			{
				_info = new SIO.FileInfo(_path.Path);
			}
			_size = size;
		}

		public override string Name
		{
			get { return _name; }
		}

		public override string FullName
		{
			get
			{
				return _fullName;
			}
		}
		public long Length
		{
			get { return _size; }
		}

		public override FilePathType PathType
		{
			get { return _path.Type; }
		}

		public override FileAttributes Attributes
		{
			get { return (FileAttributes)_info.Attributes; }
		}

		public override DateTime CreationTimeUtc
		{
			get { return _info.CreationTimeUtc; }
		}

		public override DateTime CreationTime
		{
			get { return _info.CreationTime; }
		}

		public override DateTime LastAccessTime
		{
			get { return _info.LastAccessTime; }
		}

		public override DateTime LastAccessTimeUtc
		{
			get { return _info.LastAccessTimeUtc; }
		}

		public override DateTime LastWriteTime
		{
			get { return _info.LastWriteTime; }
		}

		public override DateTime LastWriteTimeUtc
		{
			get { return _info.LastWriteTimeUtc; }
		}

		protected abstract void RenderJson(StringBuilder builder, System.Web.HttpContext context);

		void IRenderJson.RenderJson(StringBuilder builder, System.Web.HttpContext context)
		{
			RenderJson(builder, context);
		}
	}

	public class ZipFileInfo : EmbedFileInfo
	{
		public ZipFileInfo(string file, string res, Int64 size)
			: base(file, res, size)
		{
		}

		protected override void RenderJson(StringBuilder builder, System.Web.HttpContext context)
		{
			Utility.RenderHashJson(
				builder, context,
				"FullName", FullName,
				"Name", Name,
				"Type", "F",
				"Size", Length,
				"LastModifiedTime", LastWriteTime
			);
		}
	}
}
