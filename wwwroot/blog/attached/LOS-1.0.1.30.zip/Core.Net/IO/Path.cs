﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.IO
{
	public static class Path
	{
		public static string GetUser(string path)
		{
			if (path.StartsWith("/"))
			{
				int index = path.IndexOf('/', 1);
				return path.Substring(1, index == -1 ? path.Length - 1 : index - 1);
			}
			else
				return null;
		}

		public static string GetRelativePath(string path)
		{
			if (path.StartsWith("/"))
			{
				int index = path.IndexOf('/', 1);
				return index == -1 ? "" : path.Substring(index + 1);
			}
			else
			{
				return path;
			}
		}

		public static string GetDirectoryName(string path)
		{
			int index = path.LastIndexOf('/');
			return index == 0 ? "" : path.Substring(0, index);
		}

		public static string GetFileName(string path)
		{
			int index = path.LastIndexOf('/');
			return index == 0 ? "" : path.Substring(index + 1);
		}

		public static string GetFileNameWithoutExtension(string path)
		{
			string fileName = GetFileName(path);
			int index = fileName.LastIndexOf('.');
			return index == -1 ? fileName : fileName.Substring(0, index);
		}

		public static string GetExtension(string path)
		{
			string fileName = GetFileName(path);
			int index = fileName.LastIndexOf('.');
			return index == -1 ? "." : fileName.Substring(index);
		}

		public static string Join(string split, params string[] pns)
		{
			StringBuilder builder = new StringBuilder();
			foreach(string n in pns)
			{
				string s = n.Trim();
				if (!string.IsNullOrEmpty(s) && IsValidNode(s))
				{
					if (builder.Length > 0) builder.Append(split);
					builder.Append(s);
				}
			}
			return builder.ToString();
		}

		public static string Join(string split, string[] pns, int index)
		{
			StringBuilder builder = new StringBuilder();
			for (int i = index; i < pns.Length; i++)
			{
				string n = pns[i].Trim();
				if (!string.IsNullOrEmpty(n) && IsValidNode(n))
				{
					if (builder.Length > 0) builder.Append(split);
					builder.Append(n);
				}
			}
			return builder.ToString();
		}

		private static bool IsValidNode(string n)
		{
			foreach (char c in n)
			{
				if (c != '.') return true;
			}
			return false;
		}

		public static string Format(string path, char split)
		{
			string[] ns = path.Split(new char[] { split }, StringSplitOptions.RemoveEmptyEntries);
			StringBuilder builder = new StringBuilder();
			if (path[0] == split) builder.Append(split);
			foreach(string n in ns)
			{
				string s = n.Trim();
				if (!string.IsNullOrEmpty(s) && IsValidNode(s))
				{
					if (builder.Length > 0) builder.Append(split);
					builder.Append(s);
				}
			}
			return builder.ToString();
		}

		public static bool IsEqual(string p1, string p2)
		{
			return String.Compare(p1, p2, true) == 0;
		}

		public static bool IsParent(string parent,string child)
		{
			return string.IsNullOrEmpty(parent) || parent.Length < child.Length && 
				child.StartsWith(parent, StringComparison.OrdinalIgnoreCase) && 
				child[parent.Length] == '/';
		}

		public static string GetCategory(string path)
		{
			string[] ps = path.Split(new char[] { '/' }, 3, StringSplitOptions.RemoveEmptyEntries);
			return ps.Length >= 2 ? ps[1] : "";
		}

		public static string RemoveCategory(string path)
		{
			string[] ps = path.Split(new char[] { '/' }, 3, StringSplitOptions.RemoveEmptyEntries);
			return ps.Length > 2 ? String.Format("/{0}/{1}", ps[0], ps[2]) : String.Format("/{0}", ps[0]);
		}

		public static string GetRelativePath(string parent, string child)
		{
			if (string.IsNullOrEmpty(parent)) return child;
			else if (parent.Length == child.Length) return "";
			else return child.Substring(parent.Length + 1);
		}

		public static string GetRoot(string relativePath)
		{
			int index = relativePath.IndexOf("/");
			return index == -1 ? relativePath : relativePath.Substring(0, index);
		}

		public static bool IsPublicResource(string path)
		{
			string relPath = GetRelativePath(path);
			string[] pathNodes = relPath.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
			if (pathNodes.Length > 0 && String.Compare(pathNodes[0], "System", true) == 0) return true;
			if (pathNodes.Length > 0 && String.Compare(pathNodes[0], "Themes", true) == 0) return true;
			if (pathNodes.Length > 0 && String.Compare(pathNodes[0], "Public", true) == 0) return true;
			return false;
		}

		static private bool ExistFile(String path)
		{
			FilePath actualPath = VirtualPathManagement.Instance.MapPath(path);
			if (actualPath.Type == FilePathType.Local)
			{
				return System.IO.File.Exists(actualPath.Path);
			}
			else
			{
				return false;
			}
		}

		static public StorageType GetStorageType(String path)
		{
			int index = path.IndexOf(".ZIP", StringComparison.CurrentCultureIgnoreCase);

			if ((path.Length > index + 5 && path[index + 4] == '/'))
			{
				String file = path.Substring(0, index + 4);
				if (ExistFile(file))
				{
					String res = path.Substring(index + 5);
					return new StorageType(EmbedType.Embed, file, res, new ZipDirectoryInfo(file.ToString(), String.Empty));
				}
			} 
			
			index = path.IndexOf(".RUN", StringComparison.CurrentCultureIgnoreCase);

			if ((path.Length > index + 5 && path[index + 4] == '/'))
			{
				String file = path.Substring(0, index + 4);
				if (ExistFile(file))
				{
					String res = path.Substring(index + 5);
					return new StorageType(EmbedType.Embed, file, res, new ZipDirectoryInfo(file.ToString(), String.Empty));
				}
			}

			index = path.IndexOf(".CHM", StringComparison.CurrentCultureIgnoreCase);

			if ((path.Length > index + 5 && path[index + 4] == '/'))
			{
				String file = path.Substring(0, index + 4);
				if (ExistFile(file))
				{
					String res = path.Substring(index + 5);
					return new StorageType(EmbedType.CHM, file, res, null);
				}
			}

			string relative = GetRelativePath(path);
			if (relative.StartsWith("POST/", StringComparison.CurrentCultureIgnoreCase))
			{
				return new StorageType(EmbedType.POST, "", "", Microsoft.JScript.GlobalObject.unescape(relative.Substring(5, relative.Length - 5)));
			}
			if (relative.StartsWith("GET/", StringComparison.CurrentCultureIgnoreCase))
			{
				return new StorageType(EmbedType.GET, "", "", Microsoft.JScript.GlobalObject.unescape(relative.Substring(4, relative.Length - 4)));
			}

			return new StorageType(EmbedType.None);
		}
	}

	public enum EmbedType : int
	{
		None = 0,
		CHM = 1,
		Embed = 2,
		POST = 3,
		GET = 4
	}

	public class StorageType
	{
		public EmbedType Type;
		public String FilePath, ResourcePath;
		public Object Data;

		public StorageType(EmbedType type, String filePath, String resPath, Object data)
		{
			Type = type;
			FilePath = filePath;
			ResourcePath = resPath;
			Data = data;
		}

		public StorageType(EmbedType type)
		{
			Type = type;
			FilePath = null;
			ResourcePath = null;
		}
	}

	public enum FilePathType : int
	{
		Local = 0
	}

	public struct FilePath
	{
		public FilePathType Type;
		public string Path;
	}
}
