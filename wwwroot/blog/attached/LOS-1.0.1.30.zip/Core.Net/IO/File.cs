﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Checksums;
using Core;
using Core.Com;
using SIO = System.IO;

namespace Core.IO
{
	public static class File
	{

		public static void Delete(string path)
		{
			StorageType pt = Path.GetStorageType(path);
			if (pt.Type == EmbedType.None)
			{
				FilePath actualPath = VirtualPathManagement.Instance.MapPath(path);
				if (actualPath.Type == FilePathType.Local)
				{
					SIO.File.Delete(actualPath.Path);
				}
			}
			else if (pt.Type == EmbedType.Embed)
			{
				throw new Exception(String.Format("文件 \"{0}\" 为只读文件！", path));
			}
		}

		public static bool Exists(string path)
		{
			StorageType pt = Path.GetStorageType(path);
			if (pt.Type == EmbedType.None)
			{
				FilePath actualPath = VirtualPathManagement.Instance.MapPath(path);
				if (actualPath.Type == FilePathType.Local)
				{
					return SIO.File.Exists(actualPath.Path);
				}
				return false;
			}
			else if (pt.Type == EmbedType.Embed)
			{
				FileSystemInfo info = GetFileInfo(path);
				return info != null && (info.Attributes & FileAttributes.Directory) != FileAttributes.Directory;
			}
			return false;
		}

		public static SIO.FileAttributes GetAttributes(string path)
		{
			StorageType pt = Path.GetStorageType(path);
			if (pt.Type == EmbedType.None)
			{
				FilePath actualPath = VirtualPathManagement.Instance.MapPath(path);
				if (actualPath.Type == FilePathType.Local)
				{
					return SIO.File.GetAttributes(actualPath.Path);
				}
				else
					return (SIO.FileAttributes)0;
			}
			else if (pt.Type == EmbedType.Embed)
			{
				FileSystemInfo info = GetFileInfo(path);
				return (SIO.FileAttributes)info.Attributes;
			}
			return (SIO.FileAttributes)0;
		}

		public static SIO.Stream Create(string path)
		{
			StorageType pt = Path.GetStorageType(path);
			if (pt.Type == EmbedType.None)
			{
				FilePath actualPath = VirtualPathManagement.Instance.MapPath(path);
				if (actualPath.Type == FilePathType.Local)
				{
					return SIO.File.Create(actualPath.Path);
				}
				else
					return null;
			}
			else if (pt.Type == EmbedType.Embed)
			{
				throw new Exception(String.Format("文件夹 \"{0}\" 为只读文件夹！", Path.GetDirectoryName(path)));
			}
			return null;
		}

		public static FileSystemInfo GetFileInfo(string path)
		{
			StorageType pt = Path.GetStorageType(path);
			if (pt.Type == EmbedType.Embed)
			{
				return ((EmbedDirectoryInfo)pt.Data).GetItemInfo(pt.ResourcePath);
			}
			else if (pt.Type == EmbedType.None)
			{
				FilePath actualPath = VirtualPathManagement.Instance.MapPath(path);
				if (actualPath.Type == FilePathType.Local)
				{
					if (SIO.Directory.Exists(actualPath.Path))
					{
						return new DirectoryInfo(path);
					}
					else
					{
						if (String.Compare(Path.GetExtension(path), ".ZIP", true) == 0) return new ZipDirectoryInfo(path, String.Empty);
						return new FileInfo(path);
					}
				}
			}
			return null;
		}

		public static SIO.Stream Open(string path, bool createNew)
		{
			StorageType pt = Path.GetStorageType(path);

			if (pt.Type == EmbedType.CHM)
			{
				FilePath actualPath = VirtualPathManagement.Instance.MapPath(pt.FilePath);
				if (actualPath.Type == FilePathType.Local)
				{
					SIO.Stream stream = null;
					try
					{
						stream = CHH.Find(actualPath.Path, Microsoft.JScript.GlobalObject.unescape(pt.ResourcePath));
					}
					catch
					{
					}
					if (stream == null) throw new Exception(String.Format("文件\"{0}\"不存在！", path));
					return stream;
				}
				else
				{
					return null;
				}
			}
			else if (pt.Type == EmbedType.Embed)
			{
				if(!File.Exists(path) && createNew)
				{
					throw new Exception(String.Format("文件夹 \"{0}\" 为只读文件夹！", Path.GetDirectoryName(path)));
				}
				else
				{
					return ((EmbedDirectoryInfo)pt.Data).Open(pt.ResourcePath);
				}
			}
			else if (pt.Type == EmbedType.None)
			{
				FilePath actualPath = VirtualPathManagement.Instance.MapPath(path);
				if (actualPath.Type == FilePathType.Local)
				{
					SIO.FileMode mode = createNew ? SIO.FileMode.OpenOrCreate : SIO.FileMode.Open;
					return SIO.File.Open(actualPath.Path, mode, SIO.FileAccess.ReadWrite);
				}
				else
				{
					return null;
				}
			}
			else
			{
				return null;
			}
		}

		public static SIO.Stream Open(string path, SIO.FileMode mode,SIO.FileAccess access,SIO.FileShare share)
		{
			StorageType pt = Path.GetStorageType(path);

			if (pt.Type == EmbedType.CHM)
			{
				FilePath actualPath = VirtualPathManagement.Instance.MapPath(pt.FilePath);
				if (actualPath.Type == FilePathType.Local)
				{
					SIO.Stream stream = null;
					try
					{
						stream = CHH.Find(actualPath.Path, Microsoft.JScript.GlobalObject.unescape(pt.ResourcePath));
					}
					catch
					{
					}
					if (stream == null) throw new Exception(String.Format("文件\"{0}\"不存在！", path));
					return stream;
				}
				else
				{
					return null;
				}
			}
			else if (pt.Type == EmbedType.Embed)
			{
				return ((EmbedDirectoryInfo)pt.Data).Open(pt.ResourcePath);
			}
			else if (pt.Type == EmbedType.None)
			{
				FilePath actualPath = VirtualPathManagement.Instance.MapPath(path);
				if (actualPath.Type == FilePathType.Local)
				{
					return SIO.File.Open(actualPath.Path, mode, access, share);
				}
				else
				{
					return null;
				}
			}
			else if (pt.Type == EmbedType.GET)
			{
				String url = pt.Data as string;
				HttpWebRequest req = HttpWebRequest.Create(url) as HttpWebRequest;
				req.Timeout = 60 * 1000;
				HttpWebResponse response = req.GetResponse() as HttpWebResponse;
				return response.GetResponseStream();
			}
			else
			{
				return null;
			}
		}

		public static void UnZip(string fileName, string target)
		{
			if (!Directory.Exists(target)) Directory.CreateDirectory(target);
			if (!target.EndsWith("/")) target += "/";
			using (ZipInputStream inputStream = new ZipInputStream(File.Open(fileName,false)))
			{
				try
				{
					ZipEntry theEntry;
					while ((theEntry = inputStream.GetNextEntry()) != null)
					{
						if (theEntry.IsDirectory)
						{
							if (!Directory.Exists(target + theEntry.Name)) Directory.CreateDirectory(target + theEntry.Name);
						}
						else if (theEntry.IsFile)
						{
							string file = target + theEntry.Name.Replace('\\', '/');
							string dirName = Core.IO.Path.GetDirectoryName(file);
							if (!Directory.Exists(dirName)) Directory.CreateDirectory(dirName);
							using (SIO.Stream fileWrite = File.Create(file))
							{
								try
								{
									byte[] buffer = new byte[2048];
									int size;
									while (true)
									{
										size = inputStream.Read(buffer, 0, buffer.Length);
										if (size > 0)
											fileWrite.Write(buffer, 0, size);
										else
											break;
									}
								}
								catch (Exception)
								{
									throw;
								}
								finally
								{
									fileWrite.Close();
								}
							}
						}
					}
				}
				catch (Exception)
				{
					throw;
				}
				finally
				{
					inputStream.Close();
				}
			}
		}

		static public void Zip(string[] paths, string target, int level)
		{
			using (ZipOutputStream outputStream = new ZipOutputStream(File.Create(target)))
			{
				try
				{
					outputStream.SetLevel(level);
					foreach (string path in paths)
					{
						Zip(path, outputStream);
					}
				}
				finally
				{
					outputStream.Finish();
					outputStream.Close();
				}
			}
		}

		static public void Zip(string path, string target, int level)
		{
			using (ZipOutputStream outputStream = new ZipOutputStream(File.Create(target)))
			{
				try
				{
					outputStream.SetLevel(level);
					Zip(path, outputStream);
				}
				finally
				{
					outputStream.Finish();
					outputStream.Close();
				}
			}
		}

		static public void Zip(string path, ZipOutputStream output)
		{
			Zip(path, output, "");
		}

		static public void Zip(string path, ZipOutputStream output, string relativePath)
		{
			if (!string.IsNullOrEmpty(relativePath) && !relativePath.EndsWith("/"))
			{
				relativePath += "/";
			}

			if (Directory.Exists(path))
			{
				ZipEntry entry = new ZipEntry(relativePath + Path.GetFileName(path) + "/");
				entry.DateTime = DateTime.Now;
				output.PutNextEntry(entry);

				FileSystemInfo[] fsis = Directory.GetFileSystemInfos(path);
				foreach (FileSystemInfo fsi in fsis)
				{
					Zip(path + "/" + fsi.Name, output, relativePath + Path.GetFileName(path));
				}
			}
			else
			{
				Crc32 crc = new Crc32();
				//打开压缩文件
				SIO.Stream fs = File.Open(path, false);
				byte[] buffer = new byte[fs.Length];
				fs.Read(buffer, 0, buffer.Length);
				ZipEntry entry = new ZipEntry(relativePath + Path.GetFileName(path));
				entry.DateTime = DateTime.Now;
				fs.Close();
				crc.Reset();
				crc.Update(buffer);
				entry.Crc = crc.Value;
				output.PutNextEntry(entry);
				output.Write(buffer, 0, buffer.Length);
			}
		}

		static public void Move(string src, string des)
		{
			StorageType src_pt = Path.GetStorageType(src);
			if (src_pt.Type == EmbedType.Embed)
			{
				throw new Exception(String.Format("文件夹 \"{0}\" 为只读文件夹！", Path.GetDirectoryName(src)));
			}

			StorageType des_pt = Path.GetStorageType(des);
			if (des_pt.Type == EmbedType.Embed)
			{
				throw new Exception(String.Format("文件夹 \"{0}\" 为只读文件夹！", Path.GetDirectoryName(des)));
			}

			if (src_pt.Type == EmbedType.None && des_pt.Type == EmbedType.None)
			{
				FilePath srcFP = VirtualPathManagement.Instance.MapPath(src);
				FilePath desFP = VirtualPathManagement.Instance.MapPath(des);
				if (srcFP.Type == FilePathType.Local && desFP.Type == FilePathType.Local && !Path.IsEqual(desFP.Path, srcFP.Path))
				{
					SIO.File.Move(srcFP.Path, desFP.Path);
				}
			}
			else
			{
				using (SIO.Stream src_stream = Open(src, SIO.FileMode.Open, SIO.FileAccess.Read, SIO.FileShare.Read))
				{
					try
					{
						using (SIO.Stream des_stream = Open(des, SIO.FileMode.CreateNew, SIO.FileAccess.Write, SIO.FileShare.None))
						{
							try
							{
								Copy(src_stream, des_stream);
							}
							finally
							{
								des_stream.Close();
							}
						}
					}
					finally
					{
						src_stream.Close();
					}
				}
				File.Delete(src);
			}
		}

		static public void Copy(SIO.Stream src, SIO.Stream des)
		{
			Byte[] buffer = new Byte[4096];
			int count = 0;
			while (true)
			{
				count = src.Read(buffer, 0, buffer.Length);
				des.Write(buffer, 0, count);
				if (count < buffer.Length) break;
			}
		}

		static public void Copy(string src, string des)
		{
			StorageType src_pt = Path.GetStorageType(src);

			StorageType des_pt = Path.GetStorageType(des);
			if (des_pt.Type == EmbedType.Embed)
			{
				throw new Exception(String.Format("文件夹 \"{0}\" 为只读文件夹！", Path.GetDirectoryName(des)));
			}

			if (src_pt.Type == EmbedType.None && des_pt.Type == EmbedType.None)
			{
				FilePath srcFP = VirtualPathManagement.Instance.MapPath(src);
				FilePath desFP = VirtualPathManagement.Instance.MapPath(des);
				if (srcFP.Type == FilePathType.Local && desFP.Type == FilePathType.Local && !Path.IsEqual(desFP.Path, srcFP.Path))
				{
					SIO.File.Copy(srcFP.Path, desFP.Path);
				}
			}
			else
			{
				using (SIO.Stream src_stream = Open(src, SIO.FileMode.Open, SIO.FileAccess.Read, SIO.FileShare.Read))
				{
					try
					{
						using (SIO.Stream des_stream = Open(des, SIO.FileMode.CreateNew, SIO.FileAccess.Write, SIO.FileShare.None))
						{
							try
							{
								Copy(src_stream, des_stream);
							}
							finally
							{
								des_stream.Close();
							}
						}
					}
					finally
					{
						src_stream.Close();
					}
				}
			}
		}
	}
}
