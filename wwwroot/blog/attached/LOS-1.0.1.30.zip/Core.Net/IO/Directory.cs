﻿using System;
using System.Collections.Generic;
using System.Text;
using SIO = System.IO;

namespace Core.IO
{
	public static class Directory
	{
		public static void CreateDirectory(string path)
		{
			StorageType pt = Path.GetStorageType(path);
			if (pt.Type == EmbedType.None)
			{
				FilePath actualPath = VirtualPathManagement.Instance.MapPath(path);
				if (actualPath.Type == FilePathType.Local)
				{
					SIO.Directory.CreateDirectory(actualPath.Path);
				}
			}
			else if (pt.Type == EmbedType.Embed)
			{
				throw new Exception(String.Format("文件夹 \"{0}\" 为只读文件夹！", Path.GetDirectoryName(path)));
			}
		}

		public static void Delete(string path)
		{
			StorageType pt = Path.GetStorageType(path);
			if (pt.Type == EmbedType.None)
			{
				foreach (FileSystemInfo fsi in Directory.GetFileSystemInfos(path))
				{
					FileAttributes attrs = fsi.Attributes;
					if (fsi is DirectoryInfo && (attrs & FileAttributes.Directory) == FileAttributes.Directory)
					{
						Directory.Delete(fsi.FullName);
					}
					else
					{
						File.Delete(fsi.FullName);
					}
				}
				FilePath actualPath = VirtualPathManagement.Instance.MapPath(path);
				if (actualPath.Type == FilePathType.Local) SIO.Directory.Delete(actualPath.Path);
				VirtualPathManagement.Instance.DeleteVirtualPath(path);
			}
			else if (pt.Type == EmbedType.Embed)
			{
				throw new Exception(String.Format("文件夹 \"{0}\" 为只读文件夹！", path));
			}
		}

		public static bool Exists(string path)
		{
			StorageType pt = Path.GetStorageType(path);
			if (pt.Type == EmbedType.None)
			{
				FilePath actualPath = VirtualPathManagement.Instance.MapPath(path);
				if (actualPath.Type == FilePathType.Local)
				{
					return SIO.Directory.Exists(actualPath.Path);
				}
				return false;
			}
			else
			{
				FileSystemInfo info = File.GetFileInfo(path);
				return info != null && (info.Attributes & FileAttributes.Directory) == FileAttributes.Directory;
			}
		}

		public static FileSystemInfo[] GetFileSystemInfos(string path)
		{
			FileSystemInfo di = File.GetFileInfo(path);
			if (di is DirectoryInfo) return (di as DirectoryInfo).GetFileSystemInfos();
			else if (di is EmbedDirectoryInfo) return (di as EmbedDirectoryInfo).GetFileSystemInfos();
			else return new FileSystemInfo[0];
		}

		static public void Move(string src, string des)
		{
			StorageType src_pt = Path.GetStorageType(src);
			if (src_pt.Type == EmbedType.Embed)
			{
				throw new Exception(String.Format("文件夹 \"{0}\" 为只读文件夹！", Path.GetDirectoryName(src)));
			}

			StorageType des_pt = Path.GetStorageType(des);
			if (des_pt.Type == EmbedType.Embed)
			{
				throw new Exception(String.Format("文件夹 \"{0}\" 为只读文件夹！", Path.GetDirectoryName(des)));
			}

			if (Path.IsEqual(src, des)) return;

			if (VirtualPathManagement.Instance.ExistVirtualPath(src) && !VirtualPathManagement.Instance.IsVirtualPath(des))
			{
				VirtualPathManagement.Instance.UpdateVirtualPath(src, des);
			}
			else
			{
				if (!Directory.Exists(des)) Directory.CreateDirectory(des);

				foreach (FileSystemInfo fsi in GetFileSystemInfos(src))
				{
					FileAttributes attrs = fsi.Attributes;
					if ((attrs & FileAttributes.Directory) == FileAttributes.Directory)
					{
						Directory.Move(fsi.FullName, des + "/" + fsi.Name);
					}
					else
					{
						File.Move(fsi.FullName, des + "/" + fsi.Name);
					}
				}
				Directory.Delete(src);
			}
		}

		public static void Copy(string src, string des)
		{
			StorageType pt = Path.GetStorageType(des);
			if (pt.Type == EmbedType.Embed)
			{
				throw new Exception(String.Format("文件夹 \"{0}\" 为只读文件夹！", Path.GetDirectoryName(des)));
			}

			if (Path.IsEqual(src, des)) return;

			if (!Directory.Exists(des)) Directory.CreateDirectory(des);

			foreach (FileSystemInfo fsi in GetFileSystemInfos(src))
			{
				FileAttributes attrs = fsi.Attributes;
				if ((attrs & FileAttributes.Directory) == FileAttributes.Directory)
				{
					Directory.Copy(fsi.FullName, des + "/" + fsi.Name);
				}
				else
				{
					File.Copy(fsi.FullName, des + "/" + fsi.Name);
				}
			}
		}
	}
}
