﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using SIO = System.IO;

namespace Core
{
	using IO;

	public class StorageManagement
	{
		static StorageManagement m_Instance = new StorageManagement();

		static public StorageManagement Instance
		{
			get { return m_Instance; }
		}

		Hashtable m_StorageFiles = new Hashtable();

#if DEBUG
		CacheManager m_Cache = new CacheManager(4);
#else
		CacheManager m_Cache = new CacheManager(128);
#endif

		Lock m_Lock = new Lock("StorageManagement", 220);
		
		public StorageManagement()
		{
		}

		public Int64 GetDirectorySize(string user, string filename)
		{
			UserStorageFile usf = null;
			m_Lock.Enter("GetDirectorySize");
			try
			{
				string key =user.ToUpper();
				if (!m_StorageFiles.ContainsKey(key))
				{
					m_StorageFiles.Add(key, new UserStorageFile(user));
				}
				usf = m_StorageFiles[key] as UserStorageFile;
			}
			finally
			{
				m_Lock.Exit("GetDirectorySize");
			}

			m_Cache.Add(usf);

			return usf.GetDirectorySize(filename);
		}
	}

	class DirecotryRecord
	{
		public String Path;
		public Int64 LastWriteTime;
		public Int64 Size;

		public DirecotryRecord(Hashtable values)
		{
			if (values != null)
			{
				Path = (values.ContainsKey("Path") && values["Path"].GetType() == typeof(string)) ? values["Path"] as string : "";
				Size = (values.ContainsKey("Size") && values["Size"].GetType() == typeof(Double)) ? (Int64)(Double)values["Size"] : 0;
				LastWriteTime = (values.ContainsKey("LastWriteTime") && values["LastWriteTime"].GetType() == typeof(Int64)) ? (Int64)values["LastWriteTime"] : 0;
			}
			else
			{
				Path = "";
				LastWriteTime = 0;
				Size = 0;
			}
		}
	}

	class UserStorageFile:ICache
	{
		Hashtable m_Config = null;
		String m_User, m_Root, m_RootKey;
		DirecotryRecord m_RootRecord = null;
		String m_CacheKey;

		Lock m_Lock = new Lock("UserStorageFile", 219);

		public UserStorageFile(string user)
		{
			m_CacheKey = user.ToUpper();
			m_User = user;
			m_RootKey = ("/" + user).ToUpper();
			m_Root = "/" + m_User;
			m_Config = null;
			m_RootRecord = null;
		}

		static string MakeStorageFilePath(string user)
		{
			return String.Format("/{0}/Config/storage.conf", user);
		}

		private Int64 GetLastWriteTime(string fileName)
		{
			if (!Directory.Exists(fileName)) return 0;
			else return new FileInfo(fileName).LastWriteTime.ToBinary();
		}

		private Int64 GetLocalDirectorySize(string localPath)
		{
			string key = localPath.ToUpper();

			if (SIO.Directory.Exists(localPath))
			{
				SIO.DirectoryInfo info = new System.IO.DirectoryInfo(localPath);

				DirecotryRecord record = new DirecotryRecord(m_Config[key] as Hashtable);

				if (record.Path != "" && record.LastWriteTime == info.LastWriteTime.ToBinary())
				{
					return (Int64)(Double)(m_Config[key] as Hashtable)["Size"];
				}
				else
				{
					Int64 Length = 0;

					SIO.FileSystemInfo[] items = info.GetFileSystemInfos();
					foreach (SIO.FileSystemInfo fi in items)
					{
						if ((fi.Attributes & SIO.FileAttributes.Directory) == SIO.FileAttributes.Directory)
						{
							Length += GetLocalDirectorySize(fi.FullName);
						}
						else
						{
							Length += (fi as SIO.FileInfo).Length;
						}
					}

					Hashtable newRecord = new Hashtable();
					newRecord.Add("Size", (Double)Length);
					newRecord.Add("Path", localPath);
					newRecord.Add("LastWriteTime", info.LastWriteTime.ToBinary());
					m_Config[key] = newRecord;

					return Length;
				}
			}
			else
			{
				return 0;
			}
		}

		private Int64 _GetDirectorySize(string path)
		{
			if (String.IsNullOrEmpty(path)) path = m_Root;

			string key = (path.StartsWith("/") ? path : String.Format("/{0}/{1}", m_User, path)).ToUpper();

			DirecotryRecord record = new DirecotryRecord(m_Config[key] as Hashtable);

			if (record.Path != "" && record.LastWriteTime == GetLastWriteTime(record.Path))
			{
				return record.Size;
			}
			else
			{
				FilePath mp = VirtualPathManagement.Instance.MapPath(path);
				if (mp.Type == FilePathType.Local)
				{
					Int64 size = GetLocalDirectorySize(mp.Path);
					if (key == m_RootKey) m_RootRecord = new DirecotryRecord(m_Config[mp.Path.ToUpper()] as Hashtable);
					return size;
				}
				else
				{
					return 0;
				}
			}
		}

		public bool IsOpened
		{
			get
			{
				m_Lock.Enter("IsOpen");
				try
				{
					return m_Config != null;
				}
				finally
				{
					m_Lock.Exit("IsOpen");
				}
			}
		}

		public String UserName
		{
			get { return m_User; }
		}

		public Int64 GetDirectorySize(string path)
		{
			m_Lock.Enter("GetDirectorySize");
			try
			{
				if ((String.IsNullOrEmpty(path) || path.ToUpper() == m_RootKey) &&
					m_RootRecord != null && m_RootRecord.LastWriteTime == GetLastWriteTime(m_Root))
				{
					return m_RootRecord.Size;
				}
				else
				{
					Open();
					Int64 size = _GetDirectorySize(path);
					return size;
				}
			}
			finally
			{
				m_Lock.Exit("GetDirectorySize");
			}
		}

		public void Open()
		{
			m_Lock.Enter("Open");
			try
			{
				if (!IsOpened)
				{
					Hashtable config = null;

					try
					{
						using (System.IO.Stream fs = File.Open(MakeStorageFilePath(m_User), true))
						{
							try
							{
								byte[] buffer = new byte[fs.Length];
								fs.Read(buffer, 0, buffer.Length);
								string content = Encoding.GetEncoding("utf-8").GetString(buffer);
								if (String.IsNullOrEmpty(content)) config = Utility.ParseJson(content) as Hashtable;
							}
							finally
							{
								fs.Close();
							}
						}
					}
					catch
					{
					}

					m_Config = (config ?? new Hashtable());
				}
			}
			finally
			{
				m_Lock.Exit("Open");
			}
		}

		public void Save()
		{
			m_Lock.Enter("Save");
			try
			{
				if (IsOpened)
				{
					try
					{
						using (System.IO.Stream fs = File.Open(MakeStorageFilePath(m_User), true))
						{
							try
							{
								StringBuilder builder = new StringBuilder();
								Utility.RenderJson(builder, m_Config, null);

								byte[] buffer = Encoding.UTF8.GetBytes(builder.ToString());
								fs.Write(buffer, 0, buffer.Length);
							}
							finally
							{
								fs.Close();
							}
						}
					}
					catch
					{
					}
				}
			}
			finally
			{
				m_Lock.Exit("Save");
			}
		}

		public void Close()
		{
			m_Lock.Enter("Close");
			try
			{
				if (IsOpened)
				{
					Save();
					m_Config.Clear();
					m_Config = null;
				}
			}
			finally
			{
				m_Lock.Enter("Close");
			}
		}

		void ICache.OnRemoved()
		{
			Close();
		}

		object ICache.CacheKey
		{
			get
			{
				m_Lock.Enter("CacheKey");
				try
				{
					return m_CacheKey;
				}
				finally
				{
					m_Lock.Exit("CacheKey");
				}
			}
		}
	}
}
