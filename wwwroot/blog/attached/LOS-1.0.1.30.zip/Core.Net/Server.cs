﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Configuration;
using System.Data.Odbc;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System.Reflection;

namespace Core
{
	public class Server
	{
		static Server m_Instance = new Server();

		public static Server Instance
		{
			get { return m_Instance; }
		}

		private Server()
		{
		}

		private string _baseDirectory = "";
		private string _userFileRoot = "";
		private string _publicRoot = "";
		private string _logRoot = "";
		private string _templateRoot = "";
		private string _connectionString = "";
		private string _filesRoot = "";
		private string _mysqlConnString = "";

		public string FilesRoot
		{
			get { return _filesRoot; }
		}

		public string PublicRoot
		{
			get { return _publicRoot; }
		}

		public string BaseDirectory
		{
			get { return _baseDirectory; }
		}

		public string TemplateDirectory
		{
			get { return _templateRoot; }
		}

		public string ConnectionString
		{
			get { return _connectionString; }
		}

		public string UserFileRoot
		{
			get { return _userFileRoot; }
		}

		public string LogRoot
		{
			get { return _logRoot; }
		}

		public String MySqlConnectionString 
		{
			get { return _mysqlConnString; }
		}

		public Version Version
		{
			get { return Assembly.GetExecutingAssembly().GetName().Version; }
		}
		public void Initialize(HttpServerUtility server)
		{
			_baseDirectory = server.MapPath("~");
			if (_baseDirectory.EndsWith("\\"))
			{
				_baseDirectory = _baseDirectory.Substring(0, _baseDirectory.Length - 1);
			}

			_filesRoot = System.IO.Path.GetDirectoryName(_baseDirectory) + "\\Files";
			_userFileRoot = System.IO.Path.GetDirectoryName(_baseDirectory) + "\\Files\\Users";
			_publicRoot = System.IO.Path.GetDirectoryName(_baseDirectory) + "\\Files\\Public";
			_logRoot = System.IO.Path.GetDirectoryName(_baseDirectory) + "\\Files\\Log";
			_templateRoot = System.IO.Path.GetDirectoryName(_baseDirectory) + "\\Files\\Template";
			_mysqlConnString = WebConfigurationManager.ConnectionStrings["LOS.LocalServer"].ConnectionString;

			_connectionString = string.Format(
				"Data Source=\"{0}\";Pooling=False",
				server.MapPath("~/App_Data/core.db")
			);

#if DEBUG
			m_LogFile = new LogFile(Server.Instance.BaseDirectory + "\\Server.log", 128);
#else
			m_LogFile = new LogFile(Server.Instance.BaseDirectory + "\\Server.log", 32 * 1024);
#endif

			WriteLog("Application Start");
		}

		public void Dispose()
		{
			WriteLog("Application End");
			m_LogFile.Flush();
		}

		LogFile m_LogFile = null;

		public void WriteLog(string log)
		{
			m_LogFile.WriteLine(
				String.Format("{0:yyyy-MM-dd HH:mm:ss}:{1}", DateTime.Now, log)
			);
		}
	}
}
