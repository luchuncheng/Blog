﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Core
{
	interface ICache
	{
		void OnRemoved();
		object CacheKey { get; }
	}

	class CacheManager
	{
		LinkedList<ICache> m_Objects = new LinkedList<ICache>();
		Hashtable m_Map = new Hashtable();
		int m_Capacity;

		public CacheManager(int capacity)
		{
			m_Capacity = (capacity < 4 ? 4 : capacity);
		}

		public void Add(ICache obj)
		{
			lock (this)
			{
				if (m_Map.ContainsKey(obj.CacheKey))
				{
					LinkedListNode<ICache> node = m_Map[obj.CacheKey] as LinkedListNode<ICache>;
					m_Objects.Remove(node);
					m_Objects.AddLast(node);
				}
				else
				{
					if (m_Map.Count == m_Capacity)
					{
						LinkedListNode<ICache> first = m_Objects.First;
						m_Objects.Remove(first);
						m_Map.Remove(first.Value.CacheKey);

						try
						{
							first.Value.OnRemoved();
						}
						catch
						{
						}
					}
					m_Map[obj.CacheKey] = m_Objects.AddLast(obj);
				}
			}
		}

		public void Clear()
		{
			lock (this)
			{
				foreach (ICache obj in m_Objects)
				{
					obj.OnRemoved();
				}

				m_Objects.Clear();
				m_Map.Clear();
			}
		}
	}
}
