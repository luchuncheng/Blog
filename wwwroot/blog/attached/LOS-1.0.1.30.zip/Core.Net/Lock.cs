﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Web;

namespace Core
{
	public class Lock
	{
		static private Hashtable _threadsLock = new Hashtable();

		static public List<LockRecord> GetLockers()
		{
			lock (_threadsLock)
			{
				List<LockRecord> lockers = new List<LockRecord>();
				foreach (DictionaryEntry ent in _threadsLock)
				{
					lockers.AddRange((ent.Value as Stack<LockRecord>).ToArray());
				}
				return lockers;
			}
		}

		Int32 m_Level;
		String m_Name;

		public Lock(String name, int level)
		{
			m_Name = name;
			m_Level = level;
		}

		public void Enter(String comment)
		{
			lock (_threadsLock)
			{
				if (!_threadsLock.ContainsKey(Thread.CurrentThread.ManagedThreadId)) _threadsLock.Add(Thread.CurrentThread.ManagedThreadId, new Stack<LockRecord>());
				Stack<LockRecord> locks = _threadsLock[Thread.CurrentThread.ManagedThreadId] as Stack<LockRecord>;

				LockRecord record = new LockRecord(m_Name, comment, Thread.CurrentThread.ManagedThreadId, this);

				if (locks.Count > 0)
				{
					LockRecord top = locks.Peek();
					if (top.Lock != this && top.Lock.m_Level <= m_Level)
					{
						throw new Exception("Dead Lock!");
					}
				}

				locks.Push(record);
			}

			Monitor.Enter(this);
		}

		public void Exit(String comment)
		{
			Monitor.Exit(this);

			lock (_threadsLock)
			{
				Stack<LockRecord> locks = _threadsLock[Thread.CurrentThread.ManagedThreadId] as Stack<LockRecord>;

				if (locks != null)
				{
					locks.Pop();
					if (locks.Count == 0) _threadsLock.Remove(Thread.CurrentThread.ManagedThreadId);
				}
			}
		}
	}

	public class LockRecord : IRenderJson
	{
		public String Name, Comment;
		public DateTime LockTime;
		public int ThreadID;
		public Lock Lock;

		public LockRecord(String name, String comment, int threadId, Lock _lock)
		{
			Name = name;
			Comment = comment;
			LockTime = DateTime.Now;
			ThreadID = threadId;
			Lock = _lock;
		}

		void IRenderJson.RenderJson(StringBuilder builder, HttpContext context)
		{
			builder.Append("{");
			builder.Append("\"Name\":");
			Utility.RenderJson(builder, Name, context);
			builder.Append(",\"Comment\":");
			Utility.RenderJson(builder, Comment, context);
			builder.Append(",\"LockTime\":");
			Utility.RenderJson(builder, LockTime, context);
			builder.Append("}");
		}
	}
}
