﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Core
{
	class LogFile
	{
		string m_FileName = null;
		int m_MaxSize = 4 * 1024;
		Lock m_Lock = new Lock("LogFile", 296);

		public LogFile(string fileName, int maxSize)
		{
			m_FileName = fileName;
			m_MaxSize = maxSize;
		}

		StringBuilder m_Writer = new StringBuilder();

		public void Write(string text)
		{
			m_Lock.Enter("Write");
			try
			{
				m_Writer.Append(text);
				if (m_Writer.Length > m_MaxSize)
				{
					Flush();
				}
			}
			finally
			{
				m_Lock.Exit("Write");
			}
		}

		public void WriteLine(string text)
		{
			m_Lock.Enter("WriteLine");
			try
			{
				m_Writer.AppendLine(text);
				if (m_Writer.Length > m_MaxSize)
				{
					Flush();
				}
			}
			finally
			{
				m_Lock.Exit("WriteLine");
			}
		}

		public void Flush()
		{
			m_Lock.Enter("Flush");
			try
			{
				FileStream stream = File.Open(m_FileName, System.IO.FileMode.Append, System.IO.FileAccess.Write, System.IO.FileShare.Read);
				try
				{
					StreamWriter writer = new StreamWriter(stream);
					try
					{
						writer.Write(m_Writer.ToString());
						m_Writer = new StringBuilder();
					}
					finally
					{
						writer.Close();
					}
				}
				finally
				{
					stream.Close();
				}
			}
			finally
			{
				m_Lock.Exit("Flush");
			}
		}
	}
}
