﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Core
{
	static public class Trace
	{
		static object _lock = new object();
		static List<String> _logs = new List<String>();

		static public void WriteLog(string log)
		{
			lock (_lock)
			{
				_logs.Add(String.Format("[{0:yyyy-MM-dd HH:mm:ss}] {1}", DateTime.Now, log));
			}
		}

		static public List<String> GetLogs()
		{
			lock (_lock)
			{
				List<String> logs = _logs;
				_logs = new List<string>();
				return logs;
			}
		}
	}
}
