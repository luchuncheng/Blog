﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Data.Odbc;
using System.Collections.Generic;
using System.Collections;
using System.Drawing;
using System.Drawing.Imaging;
using System.Xml;
using SIO = System.IO;
using LIO = Core.IO;

namespace Core
{
	public class ThumbnailManagement
	{

		static ThumbnailManagement m_Instance = new ThumbnailManagement();

		public static ThumbnailManagement Instance
		{
			get { return m_Instance; }
		}

		private ThumbnailManagement()
		{
			m_ImageExts.Add(".JPG", ".JPG");
			m_ImageExts.Add(".JPEG", ".JPEG");
			m_ImageExts.Add(".PNG", ".PNG");
			m_ImageExts.Add(".GIF", ".GIF");
			m_ImageExts.Add(".BMP", ".BMP");

		}

		Hashtable m_Cache = new Hashtable();
		Hashtable m_ImageExts = new Hashtable();

		public DirectoryThumbnailImageInfo CreateThumbnailImage(string path)
		{
			string user = LIO.Path.GetUser(path);
			bool isPublic = LIO.Path.IsPublicResource(path);
			string key = isPublic ? LIO.Path.GetRelativePath(path).ToUpper() : path.ToUpper();
			string thumbXmlPath = String.Format(
				isPublic ? "Public/Temp/{1}.xml" : "/{0}/Temp/{1}.xml",
				user, Utility.MD5(key)
			);

			DirectoryThumbnailImageInfo info = null;
			lock (this)
			{
				if (m_Cache.ContainsKey(key))
				{
					info = m_Cache[key] as DirectoryThumbnailImageInfo;
				}
				else
				{
					info = new DirectoryThumbnailImageInfo();
					info.Load(thumbXmlPath);
				}
			}

			lock (info)
			{
				LIO.FileSystemInfo dir = LIO.File.GetFileInfo(path);
				if (info.LastModifiedTime != dir.LastWriteTime || String.IsNullOrEmpty(info.ThumbnailImagePath) || !LIO.File.Exists(info.ThumbnailImagePath))
				{
					if (!String.IsNullOrEmpty(info.ThumbnailImagePath))
					{
						try
						{
							LIO.File.Delete(info.ThumbnailImagePath);
						}
						catch
						{
						}
					}
					info.ThumbnailImagePath = String.Format(
						isPublic ? "Public/Temp/{1}.jpg" : "/{0}/Temp/{1}.jpg",
						user, Utility.MD5(key)
					);

					info.ThumbnailImageInfos.Clear();
					info.LastModifiedTime = dir.LastWriteTime;

					LIO.FileSystemInfo[] files = LIO.Directory.GetFileSystemInfos(path);

					int count = 0;
					foreach (LIO.FileSystemInfo file in files)
					{
						if ((file.Attributes & LIO.FileAttributes.Directory) != LIO.FileAttributes.Directory &&
							m_ImageExts.ContainsKey(LIO.Path.GetExtension(file.Name).ToUpper())) count++;
					}
					if (count > 0)
					{
						Image thumbnail = new Bitmap(100, 100 * count);
						Graphics graphics = Graphics.FromImage(thumbnail);
						graphics.FillRectangle(Brushes.White, new Rectangle(0, 0, thumbnail.Width, thumbnail.Height));
						int x = 0, y = 0;
						foreach (LIO.FileSystemInfo file in files)
						{
							if ((file.Attributes & LIO.FileAttributes.Directory) != LIO.FileAttributes.Directory &&
								m_ImageExts.ContainsKey(LIO.Path.GetExtension(file.Name).ToUpper()))
							{
								using (SIO.Stream imageStream = LIO.File.Open(file.FullName, false))
								{
									using (Image image = new Bitmap(imageStream))
									{
										if (image.Width <= 100 && image.Height <= 100)
										{
											graphics.DrawImage(image, new Rectangle(x + (100 - image.Width) / 2, y + (100 - image.Height) / 2, image.Width, image.Height));
										}
										else
										{
											int width, height;
											if (image.Width > image.Height)
											{
												width = 100;
												height = width * image.Height / image.Width;
												graphics.DrawImage(image, new Rectangle(x, y + (100 - height) / 2, width, height));
											}
											else
											{
												height = 100;
												width = height * image.Width / image.Height;
												graphics.DrawImage(image, new Rectangle(x + (100 - width) / 2, y, width, height));
											}
										}
										ThumbnailImageInfo thumbInfo = new ThumbnailImageInfo();
										thumbInfo.Name = file.Name;
										thumbInfo.Path = isPublic ? LIO.Path.GetRelativePath(file.FullName) : file.FullName;
										thumbInfo.Position = new Rectangle(x, y, 100, 100);
										thumbInfo.Width = image.Width;
										thumbInfo.Height = image.Height;

										info.ThumbnailImageInfos.Add(thumbInfo);
									}
									imageStream.Close();
								}
								y += 100;
							}
						}
						using (SIO.Stream stream = LIO.File.Open(info.ThumbnailImagePath, true))
						{
							thumbnail.Save(stream, ImageFormat.Jpeg);
							stream.Close();
						}
					}
					info.Save(thumbXmlPath);
				}
				if (isPublic)
				{
					m_Cache[key] = info;
				}
				return info;
			}
		}
	}

	public class DirectoryThumbnailImageInfo : IRenderJson
	{
		public DateTime LastModifiedTime;
		public List<ThumbnailImageInfo> ThumbnailImageInfos = new List<ThumbnailImageInfo>();
		public String ThumbnailImagePath = "";

		void IRenderJson.RenderJson(StringBuilder builder, HttpContext context)
		{
			//builder.Append("{");
			//builder.Append("LastModifiedTime:");
			//Utility.RenderJson(builder, LastModifiedTime, context);
			//builder.Append(",ThumbnailImageInfos:");
			//Utility.RenderJson(builder, ThumbnailImageInfos, context);
			//builder.Append(",ThumbnailImagePath:");
			//Utility.RenderJson(builder, ThumbnailImagePath, context);
			//builder.Append("}");

			Utility.RenderHashJson(
				builder, context,
				"LastModifiedTime", LastModifiedTime,
				"ThumbnailImageInfos", ThumbnailImageInfos,
				"ThumbnailImagePath", ThumbnailImagePath
			);
		}

		public void RenderXML(StringBuilder builder)
		{
			builder.AppendFormat(
				"<Thumbnail LastModifiedTime=\"{0}\" ThumbnailImagePath=\"{1}\">",
				LastModifiedTime.ToBinary(), ThumbnailImagePath
			);

			foreach(ThumbnailImageInfo info in ThumbnailImageInfos)
			{
				info.RenderXML(builder);
			}

			builder.Append("</Thumbnail>");
		}

		public void LoadFromXml(XmlElement elem)
		{
			ThumbnailImagePath = elem.GetAttribute("ThumbnailImagePath");
			LastModifiedTime = DateTime.FromBinary(long.Parse(elem.GetAttribute("LastModifiedTime")));
			ThumbnailImageInfos = new List<ThumbnailImageInfo>();

			foreach (XmlElement se in elem.GetElementsByTagName("Image"))
			{
				ThumbnailImageInfo info = new ThumbnailImageInfo();
				info.LoadFromXml(se);
				ThumbnailImageInfos.Add(info);
			}
		}

		public void Save(string fileName)
		{
			using (SIO.Stream stream = LIO.File.Create(fileName))
			{
				try
				{
					StringBuilder builder = new StringBuilder();
					builder.Append("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\r\n");
					RenderXML(builder);
					byte[] buffer = Encoding.UTF8.GetBytes(builder.ToString());
					stream.Write(buffer, 0, buffer.Length);
				}
				finally
				{
					stream.Close();
				}
			}
		}

		public void Load(string fileName)
		{
			try
			{
				using (SIO.Stream stream = LIO.File.Open(fileName, false))
				{
					try
					{
						byte[] buffer = new byte[stream.Length];
						stream.Read(buffer, 0, buffer.Length);
						String content = Encoding.UTF8.GetString(buffer);
						XmlDocument doc = new XmlDocument();
						doc.LoadXml(content);
						LoadFromXml(doc.DocumentElement);
					}
					finally
					{
						stream.Close();
					}
				}
			}
			catch
			{
			}
		}
	}

	public class ThumbnailImageInfo : IRenderJson
	{
		public String Name;
		public String Path;
		public Rectangle Position;
		public int Width, Height;

		void IRenderJson.RenderJson(StringBuilder builder, HttpContext context)
		{
			//builder.Append("{");
			//builder.Append("Name:");
			//Utility.RenderJson(builder, Name, context);
			//builder.Append(",Path:");
			//Utility.RenderJson(builder, Path, context);
			//builder.Append(",Position:");
			//Utility.RenderJson(builder, Position, context);
			//builder.Append(",Width:");
			//Utility.RenderJson(builder, Width, context);
			//builder.Append(",Height:");
			//Utility.RenderJson(builder, Height, context);
			//builder.Append("}");

			Utility.RenderHashJson(
				builder, context,
				"Name", Name,
				"Path", Path,
				"Position", Position,
				"Width", Width,
				"Height", Height
			);
		}

		public void RenderXML(StringBuilder builder)
		{
			builder.AppendFormat(
				"<Image Name=\"{0}\" Path=\"{1}\" ThumbnailLeft=\"{2}\" ThumbnailTop=\"{3}\"  ThumbnailWidth=\"{4}\" ThumbnailHeight=\"{5}\" Width=\"{6}\" Height=\"{7}\"/>",
				Name, Path, Position.Left, Position.Top, Position.Width, Position.Height, Width, Height
			);
		}

		public void LoadFromXml(XmlElement elem)
		{
			Name = elem.GetAttribute("Name");
			Path = elem.GetAttribute("Path");

			Width = Int32.Parse(elem.GetAttribute("Width"));
			Height = Int32.Parse(elem.GetAttribute("Height"));

			Position = new Rectangle(
				Int32.Parse(elem.GetAttribute("ThumbnailLeft")),
				Int32.Parse(elem.GetAttribute("ThumbnailTop")),
				Int32.Parse(elem.GetAttribute("ThumbnailWidth")),
				Int32.Parse(elem.GetAttribute("ThumbnailHeight"))
			);
		}
	}
}
