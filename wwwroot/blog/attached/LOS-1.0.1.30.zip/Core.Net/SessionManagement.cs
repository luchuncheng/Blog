﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Core
{
	public class ResponsesWatcher : IAsyncResult
	{
		static int MaxID = 0;
		AsyncCallback m_AsyncCallback = null;
		object m_Data = null;
		bool m_IsCompleted = false;
		Int32 m_SN;
		int m_ID;
		String m_RequestID;

		Lock m_Lock = new Lock("ResponsesWatcher", 297);

		public ResponsesWatcher(String requestID, AsyncCallback callback, Object extraData, Int32 sn)
		{
			m_Lock.Enter("ResponsesWatcher");
			try
			{
				m_AsyncCallback = callback;
				m_IsCompleted = false;
				m_Data = extraData;
				m_SN = sn;
				m_ID = ++MaxID;
				m_RequestID = requestID;
			}
			finally
			{
				m_Lock.Exit("ResponsesWatcher");
			}
		}

		public Int32 ID { get { return m_ID; } }

		public Int32 SN { get { return m_SN; } }

		bool IAsyncResult.IsCompleted { get { return m_IsCompleted; } }

		bool IAsyncResult.CompletedSynchronously { get { return false; } }

		WaitHandle IAsyncResult.AsyncWaitHandle { get { return null; } }

		Object IAsyncResult.AsyncState { get { return m_Data; } }

		public String ResponseData { get { return m_Cache.ToString(); } }

		public String RequestID { get { return m_RequestID; } }

		public Int32 ResponseDataLength { get { return m_Cache.Length; } }

		public void Complete(object data)
		{
			m_Lock.Enter("Complete");
			try
			{
				if (!m_IsCompleted)
				{
					try
					{
						m_AsyncCallback(this);
						m_Data = null;
						m_IsCompleted = true;
					}
					catch
					{
					}
				}
			}
			finally
			{
				m_Lock.Exit("Complete");
			}
		}

		StringBuilder m_Cache = new StringBuilder();

		public void Write(String content)
		{
			m_Lock.Enter("Write");
			try
			{
				m_Cache.Append(content);
			}
			finally
			{
				m_Lock.Exit("Write");
			}
		}
	}

	public class Session
	{
		static DateTime BaseDate = new DateTime(2009, 1, 1);

		public DateTime LastAccessTime;

		private Lock m_Lock = new Lock("Session", 298);
		private String m_User = "";
		private Int32 m_SN;
		private DateTime m_CreatedTime;
		private LogFile  m_LogFile;
		private String   m_SessionID;
		private Boolean  m_IsShutdown;
		private ResponsesWatcher m_ResponseWatcher = null;
		private List<CommandResponse> m_Responses = new List<CommandResponse>();

		Hashtable m_ConfigFiles = null;

		public Session(string user, string id)
		{
			m_IsShutdown = true;
			m_LogFile = null;

			Reset(user, id);
		}

		public Session(string user)
		{
			m_IsShutdown = true;
			m_LogFile = null;

			Reset(user, String.Format("{0}{1:000000000000000}", Guid.NewGuid().ToString().ToUpper().Replace("-", ""), Math.Round((DateTime.Now - BaseDate).TotalMilliseconds)));
		}

		public DateTime CreatedTime
		{
			get
			{
				m_Lock.Enter("CreatedTime");
				try
				{
					return m_CreatedTime;
				}
				finally
				{
					m_Lock.Exit("CreatedTime");
				}
			}
		}

		private void ClearWatcher()
		{
			LastAccessTime = DateTime.Now;
			if (m_ResponseWatcher != null)
			{
				ResponsesWatcher watcher = m_ResponseWatcher;
				m_ResponseWatcher = null;

				watcher.Write(
					Utility.RenderHashJson(null, "IsSucceed", true, "Response", JsonText.EmptyArray)
				);
				try
				{
					ThreadPool.QueueUserWorkItem(new WaitCallback(watcher.Complete));
				}
				catch
				{
				}
			}
		}

		private String GetResponseData(int sn)
		{
			String data = "";
			try
			{
				List<CommandResponse> responses = new List<CommandResponse>();

				foreach (CommandResponse cr in m_Responses)
				{
					if (cr.SN > sn) responses.Add(cr);
				}

				data = Utility.RenderHashJson(
					null,
					"IsSucceed", true,
					"Response", responses
				);
			}
			catch (Exception error)
			{
				data = Utility.RenderHashJson(
					null,
					"IsSucceed", false,
					"Exception", error
				);
			}

			return data;
		}

		private void SendResponds()
		{
			if (m_ResponseWatcher != null && m_Responses.Count > 0)
			{
				String data = GetResponseData(m_ResponseWatcher.SN);

				m_ResponseWatcher.Write(data);
				WriteWatchLog(m_ResponseWatcher.RequestID, m_ResponseWatcher.SN, data);
				try
				{
					ThreadPool.QueueUserWorkItem(new WaitCallback(m_ResponseWatcher.Complete));
				}
				catch
				{
				}
				m_ResponseWatcher = null;
			}
		}

		private void ClearResponses(int sn)
		{
			int i = 0;
			for (i = 0; i < m_Responses.Count && m_Responses[i].SN <= sn; i++) ;
			m_Responses.RemoveRange(0, i);
		}

		public bool IsShutdown
		{
			get
			{
				m_Lock.Enter("IsShutdown");
				try
				{
					return m_IsShutdown;
				}
				finally
				{
					m_Lock.Exit("IsShutdown");
				}
			}
		}

		public void Shutdown()
		{
			m_Lock.Enter("Shutdown");
			try
			{
				if (!m_IsShutdown)
				{
					SaveConfig();
					ClearWatcher();
					m_Responses.Clear();
					m_LogFile.WriteLine("</Session>");
					m_LogFile.Flush();
					m_LogFile = null;
					m_IsShutdown = true;
				}
			}
			finally
			{
				m_Lock.Exit("Shutdown");
			}
		}

		public string SessionID
		{
			get
			{
				m_Lock.Enter("SessionID");
				try
				{
					return m_SessionID;
				}
				finally
				{
					m_Lock.Exit("SessionID");
				}
			}
		}

		private void LoadConfig(String user,String name)
		{
			try
			{
				String content = File.ReadAllText(String.Format(@"{0}\Users\{1}\Config\{2}.conf", Server.Instance.FilesRoot, user, name), Encoding.UTF8);
				m_ConfigFiles[name] = Utility.ParseJson(content);
			}
			catch
			{
				m_ConfigFiles[name] = new Hashtable();
			}
		}

		private void SaveConfig()
		{
			foreach (DictionaryEntry ent in m_ConfigFiles)
			{
				try
				{
					File.WriteAllText(
						String.Format(@"{0}\Users\{1}\Config\{2}.conf", Server.Instance.FilesRoot, m_User, ent.Key as string),
						Utility.RenderJson(ent.Value, null),
						Encoding.UTF8
					);
				}
				catch
				{
				}
			}
		}

		public object ReadConfig(String name)
		{
			m_Lock.Enter("ReadConfig");
			try
			{
				return m_ConfigFiles.ContainsKey(name) ? m_ConfigFiles[name] : null;
			}
			finally
			{
				m_Lock.Exit("ReadConfig");
			}
		}

		private void Reset(string user, string id)
		{
			if (!m_IsShutdown) Shutdown();

			m_ConfigFiles = new Hashtable();

			LoadConfig(user, "A553B162-F95F-4B13-BFCD-606DABFDD71F");
			LoadConfig(user, "951AABD2-4AAC-4382-A502-71A57FC7F90D");

			m_User = user;
			m_SN = 0;
			m_SessionID = id;
			m_CreatedTime = BaseDate.AddMilliseconds(Double.Parse(m_SessionID.Substring(33)));
			m_IsShutdown = false;
			LastAccessTime = DateTime.Now;
			m_Responses = new List<CommandResponse>();

			String path = String.Format("/{0}/Session/S{1}.log", user, m_SessionID);
			Core.IO.FilePath filePath = VirtualPathManagement.Instance.MapPath(path);
			if (!System.IO.File.Exists(filePath.Path))
			{
				try
				{
					FileStream stream = System.IO.File.Open(filePath.Path, System.IO.FileMode.CreateNew, System.IO.FileAccess.Write, System.IO.FileShare.Read);
					try
					{
						StreamWriter writer = new StreamWriter(stream);
						try
						{
							writer.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\" ?>");
							writer.WriteLine(String.Format("<Session User=\"{0}\" SessionID=\"{1}\" CreatedTime=\"{2}\">", user, m_SessionID, (DateTime.Now - BaseDate).TotalMilliseconds));
						}
						finally
						{
							writer.Close();
						}
					}
					finally
					{
						stream.Close();
					}
				}
				catch
				{
				}
			}
			m_LogFile = new LogFile(filePath.Path, 8 * 1024);
		}

		public void Reset(string user)
		{
			m_Lock.Enter("Reset");
			try
			{
				Reset(user, String.Format("{0}{1:000000000000000}", Guid.NewGuid().ToString().ToUpper().Replace("-", ""), Math.Round((DateTime.Now - BaseDate).TotalMilliseconds)));
			}
			finally
			{
				m_Lock.Exit("Reset");
			}
		}

		public void AddResponse(string msgId, string data)
		{
			m_Lock.Enter("AddResponse");
			try
			{
				if (m_IsShutdown) throw new SessionShutdownException();
				m_SN++;
				m_Responses.Add(new CommandResponse(msgId, data, m_SN));
				SendResponds();
			}
			finally
			{
				m_Lock.Exit("AddResponse");
			} 
		}

		public ResponsesWatcher WatchResponses(String rquestId,AsyncCallback callback, Object extraData, Int32 sn)
		{
			m_Lock.Enter("WatchResponses");
			try
			{
				if (m_SN < sn)
				{
					m_SN = sn;
					WriteWatchLog(rquestId, sn);
					ClearWatcher();
					ResponsesWatcher watcher = new ResponsesWatcher(rquestId, callback, extraData, sn);
					if (m_Responses.Count > 0)
					{
						String data = GetResponseData(0);
						watcher.Write(data);
						WriteWatchLog(watcher.RequestID, watcher.SN, data);
					}
					else
					{
						m_ResponseWatcher = watcher;
					}
					return watcher;
				}
				else
				{
					WriteWatchLog(rquestId, sn);
					ClearWatcher();
					ClearResponses(sn);
					ResponsesWatcher watcher = new ResponsesWatcher(rquestId, callback, extraData, sn);
					if (m_Responses.Count > 0)
					{
						String data = GetResponseData(watcher.SN);
						watcher.Write(data);
						WriteWatchLog(watcher.RequestID, watcher.SN, data);
					}
					else
					{
						m_ResponseWatcher = watcher;
					}
					return watcher;
				}
			}
			finally
			{
				m_Lock.Exit("WatchResponses");
			}
		}

		private void WriteWatchLog(string requestId, Int32 sn)
		{
			try
			{
				StringBuilder builder = new StringBuilder();
				builder.AppendLine(
					String.Format(
						"\t<WatchResponses ID=\"{0}\" SN=\"{2}\" Status=\"Watch\" Time=\"{1}\">",
						requestId, (DateTime.Now - BaseDate).TotalMilliseconds, sn
					)
				);
				builder.AppendLine(String.Format("\t</WatchResponses>"));
				m_LogFile.Write(builder.ToString());
			}
			catch
			{
			}
		}

		private void WriteWatchLog(string requestId, Int32 sn, String data)
		{
			try
			{
				StringBuilder builder = new StringBuilder();
				builder.AppendLine(
					String.Format(
						"\t<WatchResponses ID=\"{0}\" SN=\"{2}\" Status=\"Completed\" Time=\"{1}\">",
						requestId, (DateTime.Now - BaseDate).TotalMilliseconds, sn
					)
				);
				builder.AppendLine(data);
				builder.AppendLine(String.Format("\t</WatchResponses>"));
				m_LogFile.Write(builder.ToString());
			}
			catch
			{
			}
		}

		public void SendCommand(string id, string data)
		{
			m_Lock.Enter("SendCommand");
			try
			{
				if (!m_IsShutdown)
				{
					//"{" + String.Format("IsSucceed:true,Response:{0}", data) + "}"
					AddResponse(id, Utility.RenderHashJson(null, "IsSucceed", true, "Response", new JsonText(data)));
				}
			}
			catch
			{
			}
			finally
			{
				m_Lock.Exit("SendCommand");
			}
		}

		public void WriteLog(string id, string requestType, string status, string data)
		{
			m_Lock.Enter("WriteLog");
			try
			{
				if (!m_IsShutdown)
				{
					try
					{
						StringBuilder builder = new StringBuilder();
						builder.AppendLine(
							String.Format(
								"\t<{0} ID=\"{1}\" Status=\"{2}\" Time=\"{3}\">",
								requestType, id, status, (DateTime.Now - BaseDate).TotalMilliseconds
							)
						);
						if (!String.IsNullOrEmpty(data))
						{
							builder.Append(Utility.TransferCharForXML(data));
							builder.Append("\r\n");
						}
						builder.AppendLine(String.Format("\t</{0}>", requestType));
						m_LogFile.Write(builder.ToString());
					}
					catch
					{
					}
				}
			}
			finally
			{
				m_Lock.Exit("WriteLog");
			}
		}

		public void WriteLog(string id, string requestType, Exception error)
		{
			m_Lock.Enter("WriteLog");
			try
			{
				if (!m_IsShutdown)
				{
					try
					{
						StringBuilder builder = new StringBuilder();
						builder.AppendLine(
							String.Format(
								"\t<{0} ID=\"{1}\" Status=\"Error\" Time=\"{2}\">",
								requestType, id, (DateTime.Now - BaseDate).TotalMilliseconds
							)
						);

						builder.Append(Utility.TransferCharForXML(String.Format("Message:{0}\r\nStackTrace:{1}\r\n", error.Message, error.StackTrace)));

						builder.AppendLine(String.Format("\t</{0}>", requestType));
						m_LogFile.Write(builder.ToString());
					}
					catch
					{
					}
				}
			}
			finally
			{
				m_Lock.Exit("WriteLog");
			}
		}
	}

	public class SessionManagement
	{
		static SessionManagement m_Instance = new SessionManagement();

		public static SessionManagement Instance
		{
			get { return SessionManagement.m_Instance; }
		}

		Lock m_Lock = new Lock("SessionManager", 299);
		Hashtable m_Sessions = new Hashtable();

#		if DEBUG
		const int TIMER_PERIOD = 60 * 60 * 1000;
#		else
		const int TIMER_PERIOD = 60 * 60 * 1000;
#		endif

		Timer m_Timer = null;

		private void TimerProc(object state)
		{
			List<Session> sessions = new List<Session>();
			m_Lock.Enter("TimerProc");
			try
			{
				DateTime now = DateTime.Now;
				foreach (DictionaryEntry ent in m_Sessions)
				{
					Session session = ent.Value as Session;
					if (!session.IsShutdown && (now - session.LastAccessTime).TotalMilliseconds > TIMER_PERIOD)
					{
						sessions.Add(session);
					}
				}
			}
			finally
			{
				m_Lock.Exit("TimerProc");
			}

			foreach (Session session in sessions)
			{
				session.Shutdown();
			}
		}

		private SessionManagement()
		{
			m_Timer = new Timer(this.TimerProc);
			m_Timer.Change(0, TIMER_PERIOD);
		}

		public Session GetSession(string user, string sessionId)
		{
			m_Lock.Enter("GetSession");
			try
			{
				string key = user.ToUpper();
				if (!m_Sessions.ContainsKey(key))
				{
					//恢复连接,通常发生在服务器重启后
					m_Sessions.Add(key, new Session(user, sessionId));
					(m_Sessions[key] as Session).SendCommand("SystemCommand", Utility.RenderHashJson(null, "Command", "SessionRecover", "Data", JsonText.EmptyObject));
					Server.Instance.WriteLog(String.Format("Session {0} Recover", (m_Sessions[key] as Session).SessionID));
				}
				else
				{
					if ((m_Sessions[key] as Session).IsShutdown) throw new SessionShutdownException();
					if ((m_Sessions[key] as Session).SessionID != sessionId) throw new SessionAbandonException();
				}
				(m_Sessions[key] as Session).LastAccessTime = DateTime.Now;
				return m_Sessions[key] as Session;
			}
			finally
			{
				m_Lock.Exit("GetSession");
			}
		}

		public Session Login(string user)
		{
			m_Lock.Enter("Login");
			try
			{
				string key = user.ToUpper();
				Session newSession = null;
				if (m_Sessions.ContainsKey(key))
				{
					newSession=m_Sessions[key] as Session;
					newSession.Reset(user);
				}
				else
				{
					newSession = new Session(user);
					m_Sessions[key] = newSession;
				}

				Server.Instance.WriteLog(String.Format("Session {0} Login", newSession.SessionID));

				return newSession;
			}
			finally
			{
				m_Lock.Exit("Login");
			}
		}

		public void Logout(string user)
		{
			m_Lock.Enter("Logout");
			try
			{
				string key = user.ToUpper();
				if (m_Sessions.ContainsKey(key))
				{
					(m_Sessions[key] as Session).Shutdown();
				}

				Server.Instance.WriteLog(String.Format("Session {0} Logout", (m_Sessions[key] as Session).SessionID));
			}
			finally
			{
				m_Lock.Exit("Logout");
			}
		}

		public bool ExistSession(string user)
		{
			m_Lock.Enter("ExistSession");
			try
			{
				string key = user.ToUpper();
				return m_Sessions.ContainsKey(key) && !(m_Sessions[key] as Session).IsShutdown;
			}
			finally
			{
				m_Lock.Exit("ExistSession");
			}
		}

		public void ShutdownExistSession(string user)
		{
			m_Lock.Enter("ShutdownExistSession");
			try
			{
				(m_Sessions[user.ToUpper()] as Session).Shutdown();
			}
			finally
			{
				m_Lock.Exit("ShutdownExistSession");
			}
		}

		public void SendCommand(string user, string id, string data)
		{
			m_Lock.Enter("SendCommand");
			try
			{
				String key = user.ToUpper();
				if (!m_Sessions.ContainsKey(key)) return;
				Session session = m_Sessions[key] as Session;
				session.AddResponse(id, Utility.RenderHashJson(null, "IsSucceed", true, "Response", new JsonText(data)));
			}
			finally
			{
				m_Lock.Exit("SendCommand");
			}
		}

		public void Initialize()
		{
		}

		public void Dispose()
		{
			m_Lock.Enter("Dispose");
			try
			{
				foreach (DictionaryEntry ent in m_Sessions)
				{
					Session session = ent.Value as Session;
					session.Shutdown();
				}
			}
			finally
			{
				m_Lock.Exit("Dispose");
			}
		}
	}

	class CommandResponse : IRenderJson
	{
		public String CommandID;
		public String Response;
		public Int32 SN;

		public CommandResponse(String commandID, String response, Int32 sn)
		{
			CommandID = commandID;
			Response = response;
			SN = sn;
		}

		void IRenderJson.RenderJson(StringBuilder builder, HttpContext context)
		{
			Utility.RenderHashJson(
				builder, context,
				"ID", CommandID,
				"SN", SN,
				"Data", new JsonText(Response)
			);
		}
	}

	class SessionShutdownException : Exception
	{
	}

	class SessionAbandonException : Exception
	{
	}

	class NotAuthenticatedException : Exception
	{
	}
}
