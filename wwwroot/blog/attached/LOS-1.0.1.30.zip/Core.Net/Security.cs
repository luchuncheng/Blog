﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace Core
{
	using IO;
	public class Security
	{
		//根目录权限
		static IOPermission RootPermission = new IOPermission(DirectoryPermission.List);
		//群消息文件权限
		static IOPermission GroupItemPermission = new IOPermission(FilePermission.Read);


		//根目录下特殊目录权限
		static IOPermission SystemDirectoryPermission	= new IOPermission(DirectoryPermission.List);
		static IOPermission ThemesDirectoryPermission = new IOPermission(DirectoryPermission.List);
		static IOPermission PublicDirectoryPermission = new IOPermission(DirectoryPermission.List);
		static IOPermission ShareDirectoryPermission = new IOPermission(DirectoryPermission.List);

		static IOPermission SessionDirectoryPermission	= new IOPermission(DirectoryPermission.Create);
		static IOPermission MessageDirectoryPermission = new IOPermission(DirectoryPermission.Create | DirectoryPermission.List);
		static IOPermission ConfigDirectoryPermission	= new IOPermission(DirectoryPermission.Create);

		static IOPermission GroupsDirectoryPermission	= new IOPermission(DirectoryPermission.List);

		//根目录下特殊目录子文件(夹)权限
		static IOPermission SystemSubItemsPermission	= new IOPermission(DirectoryPermission.List | FilePermission.Read);
		static IOPermission ThemesSubItemsPermission = new IOPermission(DirectoryPermission.List | FilePermission.Read);
		static IOPermission PublicSubItemsPermission = new IOPermission(DirectoryPermission.List | FilePermission.Read);
		static IOPermission ShareSubItemsPermission		= new IOPermission(DirectoryPermission.List | FilePermission.Read);
		static IOPermission PubSubItemsPermission = new IOPermission(DirectoryPermission.List | FilePermission.Read);
		
		static IOPermission SessionSubItemsPermission	= new IOPermission(DirectoryPermission.Create | FilePermission.Read | FilePermission.Write);
		static IOPermission MessageSubItemsPermission = new IOPermission(IOPermission.All);
		static IOPermission ConfigSubItemsPermission	= new IOPermission(DirectoryPermission.Create | FilePermission.Read | FilePermission.Write);

		static IOPermission GroupSubItemsMemberPermission	= new IOPermission(DirectoryPermission.List | DirectoryPermission.Create | FilePermission.Read);
		static IOPermission GroupSubItemsManagerPermission	= new IOPermission(IOPermission.All);

		public static void CheckPermission(string path,HttpContext context,UInt64 action)
		{
			string user = Path.GetUser(path);
			string relativePath = Path.GetRelativePath(path);
			string relRoot = Path.GetRoot(relativePath);

			if (String.Compare(relRoot, "pub", true) == 0)
			{
				if (!(context.User.Identity.IsAuthenticated && String.Compare(context.User.Identity.Name, user, true) == 0) && 
					!(String.Compare(relRoot, relativePath, true) != 0 && PubSubItemsPermission.Allow(action))) throw new PermissionException();

				FileSystemInfo info = File.GetFileInfo(path);
				if (info != null && ((info.Attributes & FileAttributes.Directory) != FileAttributes.Directory) &&
					String.Compare(System.IO.Path.GetExtension(info.FullName), ".chm", true) != 0 &&
					((FileInfo)info).Length > 2 * 1024 * 1024)
				{
					throw new Exception("文件（CHM文件除外）大小不能超过2M");
				}
			}
			else
			{
				if (!context.User.Identity.IsAuthenticated) throw new PermissionException();

				if (String.IsNullOrEmpty(relativePath) && !RootPermission.Allow(action))
				{
					//用户根目录下不允许创建文件
					throw new PermissionException();
				}

				if (string.Compare(user, context.User.Identity.Name, true) != 0)
				{
					AccountInfo info = AccountManagement.Instance.GetUserInfo(user);
					if (info.Type != 1) throw new PermissionException();
					if (!info.ContainsMember(context.User.Identity.Name)) throw new PermissionException();
					if (!GroupItemPermission.Allow(action)) throw new PermissionException();
				}

				if (String.Compare(relRoot, relativePath, true) == 0)
				{
					switch (relRoot.ToUpper())
					{
					case "SHARE":
						if (!GroupsDirectoryPermission.Allow(action)) throw new PermissionException();
						break;
					case "THEMES":
						if (!ThemesDirectoryPermission.Allow(action)) throw new PermissionException();
						break;
					case "SYSTEM":
						if (!SystemDirectoryPermission.Allow(action)) throw new PermissionException();
						break;
					case "SESSION":
						if (!SessionDirectoryPermission.Allow(action)) throw new PermissionException();
						break;
					case "MESSAGE":
						if (!MessageDirectoryPermission.Allow(action)) throw new PermissionException();
						break;
					case "CONFIG":
						if (!ConfigDirectoryPermission.Allow(action)) throw new PermissionException();
						break;
					case "PUBLIC":
						if (!PublicDirectoryPermission.Allow(action)) throw new PermissionException();
						break;
					default:
						break;
					}
				}
				else
				{
					switch (relRoot.ToUpper())
					{
					case "SHARE":
						{
							string relGroupPath = Path.GetRelativePath("Share", relativePath);
							string groupName = Path.GetRoot(relGroupPath);
							AccountInfo info = AccountManagement.Instance.GetUserInfo(user);
							AccountInfo groupInfo = AccountManagement.Instance.GetUserInfo(groupName);

							if (!groupInfo.ContainsMember(user)) throw new PermissionException();

							if (groupInfo.IsManagedBy(user))
							{
								if (!GroupSubItemsManagerPermission.Allow(action)) throw new PermissionException();
							}
							else
							{
								if (!GroupSubItemsMemberPermission.Allow(action)) throw new PermissionException();
							}
							break;
						}
					case "THEMES":
						if (!ThemesSubItemsPermission.Allow(action)) throw new PermissionException();
						break;
					case "SYSTEM":
						if (!SystemSubItemsPermission.Allow(action)) throw new PermissionException();
						break;
					case "SESSION":
						if (!SessionSubItemsPermission.Allow(action)) throw new PermissionException();
						break;
					case "MESSAGE":
						if (!MessageSubItemsPermission.Allow(action)) throw new PermissionException();
						break;
					case "CONFIG":
						if (!ConfigSubItemsPermission.Allow(action)) throw new PermissionException();
						break;
					case "PUBLIC":
						if (!PublicSubItemsPermission.Allow(action)) throw new PermissionException();
						break;
					default:
						break;
					}
				}
			}
		}
	}

	public class PermissionException : Exception
	{
		public PermissionException()
			: base("权限不足")
		{
		}
	}

	public class FilePermission
	{
		public const UInt64 Read = 1 << 2;
		public const UInt64 Write = 1 << 3;
	}

	public class DirectoryPermission
	{
		public const UInt64 List = 1 << 4;
		public const UInt64 Create = 1 << 5;
	}

	public class IOPermission
	{
		public const UInt64 None = 0;
		public const UInt64 All = FilePermission.Read | FilePermission.Write | DirectoryPermission.List | DirectoryPermission.Create | Rename | Delete;
		
		public const UInt64 Rename = 1;
		public const UInt64 Delete = 1 << 1;
		
		private UInt64 m_AllowAction;

		public IOPermission(UInt64 allowAction)
		{
			m_AllowAction = allowAction;
		}

		public bool Allow(UInt64 action)
		{
			return (m_AllowAction & action) == action;
		}
	}
}
