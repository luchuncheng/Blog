﻿using System;
using System.Collections.Generic;
using System.Text;
using SIO = System.IO;
using LIO = Core.IO;
using System.Collections;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using System.Threading;
using System.Data;
using System.Data.SQLite;
using Microsoft.JScript;

namespace Core
{
	public class Message
	{
		public Int64 SenderID;
		public Int64 ReceiverID;
		public String Content;
		public Int64 Type;
		public DateTime CreatedTime;
		public Int64 Key;

		public Message(Hashtable vals)
		{
			Key = (Int64)vals["Key"];
			SenderID = (Int64)vals["Sender"];
			ReceiverID = (Int64)vals["Receiver"];
			Content = vals["Content"] as string;
			Type = (Int64)vals["Type"];
			CreatedTime = (DateTime)vals["CreatedTime"];
		}
	}

	static class MessageManagmentUtility
	{
		public static DateTime Now
		{
			get { return new DateTime((DateTime.Now.Ticks / 10000) * 10000); }
		}
	}

	public class MessageManagement
	{
		private static MessageManagement m_Instance = new MessageManagement();

		public static MessageManagement Instance
		{
			get { return m_Instance; }
		}

		Hashtable m_UserMessages = new Hashtable();

		private MessageManagement()
		{
			m_Timer = new Timer(this.TimerProc);
			m_Timer.Change(0, TIMER_PERIOD);
		}

		Lock m_Lock = new Lock("MessageManagement", 399);

		private MessageStorage GetUserMessageStorage(string user)
		{
			m_Lock.Enter("GetUserMessageStorage");
			try
			{
				String key = user.ToUpper();
				MessageStorage msgFile = null;
				if (!m_UserMessages.ContainsKey(key))
				{
					msgFile = new MessageStorage(AccountManagement.Instance.GetUserInfo(user));
					msgFile.Open();
					m_UserMessages.Add(key, msgFile);
				}
				else
				{
					msgFile = m_UserMessages[key] as MessageStorage;
				}

				return msgFile;
			}
			finally
			{
				m_Lock.Exit("GetUserMessageStorage");
			}
		}

		public String AddListener(String sessionId, String guid, String user, String owner, DateTime min, Int64 type, String handlerId)
		{
			return GetUserMessageStorage(owner).AddListener(sessionId, guid, user, type, min, handlerId);
		}

		public void RemoveListener(String owner,String guid)
		{
			GetUserMessageStorage(owner).RemoveListener(guid);
		}

		public List<Message> Find(String user,String receiver, String sender, Nullable<DateTime> min, Nullable<DateTime> max, Int64 type, int count)
		{
			AccountInfo userInfo = AccountManagement.Instance.GetUserInfo(user);
			AccountInfo receiverInfo = receiver == null ? null : AccountManagement.Instance.GetUserInfo(receiver);
			AccountInfo senderInfo = sender == null ? null : AccountManagement.Instance.GetUserInfo(sender);
			List<Hashtable> result = GetUserMessageStorage(user).Find(
				type,
				receiverInfo == null ? null : new Nullable<Int64>(receiverInfo.ID),
				senderInfo == null ? null : new Nullable<Int64>(senderInfo.ID),
				min, max, count
				);
			List<Message> msgs = new List<Message>();
			foreach (Hashtable msg in result)
			{
				msgs.Add(new Message(msg));
			}
			return msgs;
		}

		public List<Int64> GetAllSenders(String user)
		{
			AccountInfo userInfo = AccountManagement.Instance.GetUserInfo(user);
			return GetUserMessageStorage(user).GetAllSenders();
		}

		public List<String> GetMessageDate(String user, int type)
		{
			AccountInfo userInfo = AccountManagement.Instance.GetUserInfo(user);
			return GetUserMessageStorage(user).GetMessageDate(type);
		}

		public Message Add(string receviver, string sender, string content, Int64 type)
        {
			AccountInfo receiverInfo = AccountManagement.Instance.GetUserInfo(receviver);
			AccountInfo senderInfo = AccountManagement.Instance.GetUserInfo(sender);

			Hashtable msg = new Hashtable();
			msg["Receiver"] = (Int64)receiverInfo.ID;
			msg["Sender"] = (Int64)senderInfo.ID;
			msg["Content"] = content;
			msg["Type"] = (Int64)type;
			msg["CreatedTime"] = MessageManagmentUtility.Now;

			if (receiverInfo.Type == 0)
			{
				GetUserMessageStorage(receviver).Insert(msg);
				return GetUserMessageStorage(sender).Insert(msg);
			}
			else
			{
				return GetUserMessageStorage(receviver).Insert(msg);
			}
        }

		public void Close(string user)
		{
			m_Lock.Enter("Close");
			try
			{
				String key = user.ToUpper();
				if (m_UserMessages.ContainsKey(key))
				{
					MessageStorage msgFile = m_UserMessages[key] as MessageStorage;
					msgFile.Close();
				}
			}
			finally
			{
				m_Lock.Exit("Close");
			}
		}

		public void Delete(String user, int index)
		{
		}

		public void Flush(String user)
		{
			GetUserMessageStorage(user).Flush();
		}

		public void Initialize()
		{
		}

		public void Dispose()
		{
			m_Lock.Enter("Dispose");
			try
			{
				foreach (DictionaryEntry ent in m_UserMessages)
				{
					MessageStorage storage = ent.Value as MessageStorage;
					storage.Close();
				}
			}
			finally
			{
				m_Lock.Exit("Dispose");
			}
		}

#		if DEBUG
		const int TIMER_PERIOD = 1 * 60 * 1000;
#		else
		const int TIMER_PERIOD = 30 * 60 * 1000;
#		endif

		Timer m_Timer = null;

		private void TimerProc(object state)
		{
			List<MessageStorage> msgs = new List<MessageStorage>();

			m_Lock.Enter("TimerProc");
			try
			{
				foreach (DictionaryEntry ent in m_UserMessages)
				{
					MessageStorage ms = ent.Value as MessageStorage;
					if (!ms.IsClosed && (DateTime.Now - ms.LastAccessTime).TotalMilliseconds > TIMER_PERIOD)
					{
						msgs.Add(ms);
					}
				}
			}
			finally
			{
				m_Lock.Exit("TimerProc");
			}

			foreach (MessageStorage ms in msgs)
			{
				ms.Close();
			}
		}

	}

	class MessageStorage
	{

#if DEBUG
		const int MAX_CACHE_COUNT = 4;
#else
		const int MAX_CACHE_COUNT = 200;
#endif

		private Lock m_Lock = new Lock("MessageStorage", 398);
		private AccountInfo m_UserInfo = null;
		private MessageCache m_Cache = new MessageCache();
		private DateTime m_MaxCreatedTime;
		private Int64 m_MaxKey;
		private bool m_IsClosed;
		private DateTime m_LastAccessTime = DateTime.Now;

		public Boolean IsClosed
		{
			get { return m_IsClosed; }
		}

		public DateTime LastAccessTime
		{
			get { return m_LastAccessTime; }
		}

		public MessageStorage(AccountInfo user)
		{
			m_UserInfo = user;
			m_IsClosed = true;
		}

		public Message Insert(Hashtable msg)
		{
			m_Lock.Enter("Insert");
			try
			{
				Open();

				Hashtable newMsg = new Hashtable();

				newMsg["Key"] = ++m_MaxKey;
				newMsg["Sender"] = msg["Sender"];
				newMsg["Receiver"] = msg["Receiver"];
				newMsg["Type"] = msg["Type"];
				newMsg["CreatedTime"] = msg["CreatedTime"];
				MsgAccessoryEval eval = new MsgAccessoryEval(newMsg, (Int64)m_UserInfo.ID, (Int64)msg["Sender"]);
				Regex reg = new Regex("{Accessory [^\f\n\r\t\v<>]+}");
				newMsg["Content"] = reg.Replace(msg["Content"] as string, eval.Replace);

				m_Cache.Insert(newMsg);

				List<Message> msgs = new List<Message>();
				Message message = new Message(newMsg);
				msgs.Add(message);
				String json = MessageListener.RenderMsgsJson(msgs);

				List<String> deletedListeners = new List<string>();
				foreach (DictionaryEntry ent in m_Listeners)
				{
					MessageListener listener = ent.Value as MessageListener;
					try
					{
						if (listener.Type == (Int64)newMsg["Type"] && listener.Min < (DateTime)newMsg["CreatedTime"])
						{
							listener.Send(json, message.CreatedTime);
						}
					}
					catch
					{
						deletedListeners.Add(ent.Key as String);
					}
				}

				foreach (String key in deletedListeners)
				{
					m_Listeners.Remove(key);
				}

				if (m_Cache.Count >= MAX_CACHE_COUNT)
				{
					Flush();
				}

				return message;
			}
			finally
			{
				m_Lock.Exit("Insert");
			}
		}

		public void Open()
		{
			m_Lock.Enter("Open");
			try
			{
				if (m_IsClosed)
				{
					m_Cache.Clear();
					MessageDatabase db = new MessageDatabase(m_UserInfo);
					db.Open();
					try
					{
						m_MaxCreatedTime = db.MaxCreatedTime;
						m_MaxKey = db.MaxKey;
						m_IsClosed = false;
					}
					finally
					{
						db.Close();
					}
				}

				m_LastAccessTime = DateTime.Now;
			}
			finally
			{
				m_Lock.Exit("Open");
			}
		}

		public void Close()
		{
			m_Lock.Enter("Close");
			try
			{
				if (!m_IsClosed)
				{
					try
					{
						Flush();
					}
					catch
					{
					}
					m_IsClosed = true;
				}
			}
			finally
			{
				m_Lock.Exit("Close");
			}
		}

		public void Flush()
		{
			m_Lock.Enter("Flush");
			try
			{
				m_LastAccessTime = DateTime.Now;
				if (!m_IsClosed)
				{
					if (m_Cache.Count > 0)
					{
						MessageDatabase db = new MessageDatabase(m_UserInfo);
						db.Open();
						try
						{
							db.Insert(m_Cache.GetAll());
							m_Cache.Clear();
							m_MaxCreatedTime = db.MaxCreatedTime;
							m_MaxKey = db.MaxKey;
						}
						finally
						{
							db.Close();
						}
					}
				}
			}
			finally
			{
				m_Lock.Exit("Flush");
			}
		}

		public List<String> GetMessageDate(int type)
		{
			m_Lock.Enter("GetMessageDate");
			try
			{
				m_LastAccessTime = DateTime.Now;
				MessageDatabase db = new MessageDatabase(m_UserInfo);
				db.Open();
				try
				{
					return db.GetMessageDate(type);
				}
				finally
				{
					db.Close();
				}
			}
			finally
			{
				m_Lock.Exit("GetMessageDate");
			}
		}

		public List<Int64> GetAllSenders()
		{
			m_Lock.Enter("GetAllSenders");
			try
			{
				Open();
				Flush();
				MessageDatabase db = new MessageDatabase(m_UserInfo);
				db.Open();
				try
				{
					return db.GetAllSenders();
				}
				finally
				{
					db.Close();
				}
			}
			finally
			{
				m_Lock.Exit("GetAllSenders");
			}
		}

		public List<Hashtable> Find(Int64 type, Nullable<Int64> receiverId, Nullable<Int64> senderId, Nullable<DateTime> min, Nullable<DateTime> max, int count)
		{
			m_Lock.Enter("Find");
			try
			{
				Open();
				Flush();
				MessageDatabase db = new MessageDatabase(m_UserInfo);
				db.Open();
				try
				{
					return db.Find(type, receiverId, senderId, min, max, count);
				}
				finally
				{
					db.Close();
				}
			}
			finally
			{
				m_Lock.Exit("Find");
			}
		}
		
		public List<Hashtable> Find(Int64 type, DateTime min)
		{
			m_Lock.Enter("Find");
			try
			{
				Open();
				List<Hashtable> result=new List<Hashtable>();
				if (min < m_MaxCreatedTime)
				{
					MessageDatabase db = new MessageDatabase(m_UserInfo);
					db.Open();
					try
					{
						result.AddRange(db.Find(type, min));
					}
					finally
					{
						db.Close();
					}
				}

				result.AddRange(m_Cache.Find(type, min));

				return result;
			}
			finally
			{
				m_Lock.Exit("Find");
			}
		}

		Hashtable m_Listeners = new Hashtable();

		public String AddListener(String sessionId, String guid, String user, Int64 type, DateTime min, String handlerID)
		{
			m_Lock.Enter("AddListener");
			try
			{
				if (String.IsNullOrEmpty(guid))
				{
					guid = Guid.NewGuid().ToString().ToUpper();
				}

				MessageListener listener = new MessageListener(sessionId, guid, user, m_UserInfo.Name, type, min, handlerID);
				if (!m_Listeners.ContainsKey(guid))
				{
					Open();
					List<Hashtable> result = Find(listener.Type, listener.Min);
					if (result.Count > 0)
					{
						List<Message> msgs = new List<Message>();
						foreach (Hashtable msg in result)
						{
							msgs.Add(new Message(msg));
						}
						listener.Send(MessageListener.RenderMsgsJson(msgs), msgs[msgs.Count - 1].CreatedTime);
					}
					m_Listeners[guid] = listener;
				}
				return guid;
			}
			finally
			{
				m_Lock.Exit("AddListener");
			}
		}

		public void RemoveListener(String guid)
		{
			m_Lock.Enter("RemoveListener");
			try
			{
				m_Listeners.Remove(guid);
			}
			finally
			{
				m_Lock.Exit("RemoveListener");
			}
		}
	}

	class MessageCache
	{
		Lock m_Lock = new Lock("MessageCache", 397);

		List<Hashtable> m_Caches = new List<Hashtable>();

		public void Insert(Hashtable msg)
		{
			m_Lock.Enter("Insert");
			try
			{
				m_Caches.Add(msg);
			}
			finally
			{
				m_Lock.Exit("Insert");
			}
		}
		public List<Hashtable> Find(Int64 Type, DateTime min)
		{
			m_Lock.Enter("Find");
			try
			{
				List<Hashtable> msgs = new List<Hashtable>();
				for (int i = m_Caches.Count - 1; i >= 0; i--)
				{
					Hashtable msg = m_Caches[i];
					if (((Int64)msg["Type"]) == Type && ((DateTime)msg["CreatedTime"]) > min)
					{
						msgs.Add(msg);
					}
				}
				return msgs;
			}
			finally
			{
				m_Lock.Exit("Find");
			}
		}

		public List<Hashtable> GetAll()
		{
			m_Lock.Enter("GetAll");
			try
			{
				return m_Caches;
			}
			finally
			{
				m_Lock.Exit("GetAll");
			}
		}

		public void Clear()
		{
			m_Lock.Enter("Clear");
			try
			{
				m_Caches.Clear();
			}
			finally
			{
				m_Lock.Exit("Clear");
			}
		}

		public Int32 Count
		{
			get
			{
				m_Lock.Enter("Count");
				try
				{
					return m_Caches.Count;
				}
				finally
				{
					m_Lock.Exit("Count");
				}
			}
		}
	}

	class MessageDatabase
	{
		AccountInfo m_UserInfo = null;
		String m_DbPath = "";
		Int64 m_MaxKey = 0;
		DateTime m_MaxCreatedTime;

		SQLiteConnection m_DbConn = null;
		SQLiteCommand m_InsertCommand = null;
		SQLiteCommand m_SelectCommand1 = null;
		SQLiteCommand m_SelectCommand2 = null;
		SQLiteCommand m_SelectSenderCommand = null;

		public Int64 MaxKey { get { return m_MaxKey; } }
		public DateTime MaxCreatedTime { get { return m_MaxCreatedTime; } }

		Lock m_Lock = new Lock("MessageDatabase", 397);

		public MessageDatabase(AccountInfo user)
		{
			m_Lock.Enter("MessageDatabase");
			try
			{
				m_UserInfo = user;
				m_DbPath = VirtualPathManagement.Instance.MapPath(String.Format("/{0}/Message/message.db", m_UserInfo.Name)).Path;
			}
			finally
			{
				m_Lock.Exit("MessageDatabase");
			}
		}

		public void Open()
		{
			m_Lock.Enter("Open");
			try
			{
				if (m_DbConn == null)
				{
					if (!SIO.File.Exists(m_DbPath))
					{
						SIO.File.Copy(Server.Instance.TemplateDirectory + "\\msg_bk.db", m_DbPath);
					}

					m_DbConn = new SQLiteConnection(String.Format("Data Source=\"{0}\";Pooling=False", m_DbPath));

					try
					{

						m_InsertCommand = new SQLiteCommand(
							"insert into Message (Sender,Receiver,Type,Content,CreatedTime,Key) values (?,?,?,?,?,?)",
							m_DbConn
						);
						m_InsertCommand.Parameters.Add("Sender", DbType.Int64);
						m_InsertCommand.Parameters.Add("Receiver", DbType.Int64);
						m_InsertCommand.Parameters.Add("Type", DbType.Int64);
						m_InsertCommand.Parameters.Add("Content", DbType.String);
						m_InsertCommand.Parameters.Add("CreatedTime", DbType.DateTime);
						m_InsertCommand.Parameters.Add("Key", DbType.Int64);

						m_SelectCommand1 = new SQLiteCommand(
							"select * from Message where Key=?", m_DbConn
						);
						m_SelectCommand1.Parameters.Add("Key", DbType.Int64);

						m_SelectCommand2 = new SQLiteCommand(
							"select * from Message where Type=? and CreatedTime>? order by CreatedTime asc", m_DbConn
						);
						m_SelectCommand2.Parameters.Add("Type", DbType.Int64);
						m_SelectCommand2.Parameters.Add("CreatedTime", DbType.DateTime);

						m_SelectSenderCommand = new SQLiteCommand(
							"select distinct Sender from Message", m_DbConn
						);

						m_DbConn.Open();

						Stat();
					}
					catch
					{
						if (m_DbConn.State == ConnectionState.Open) m_DbConn.Close();
						m_DbConn = null;
						m_InsertCommand = null;
						throw;
					}
				}
			}
			finally
			{
				m_Lock.Exit("Open");
			}
		}

		private void Stat()
		{
			Open();
			SQLiteCommand maxCmd = new SQLiteCommand(
				"select max(Key) as MaxKey , max(CreatedTime) as MaxCreatedTime from Message", m_DbConn
			);
			SQLiteDataReader reader = maxCmd.ExecuteReader(CommandBehavior.SingleResult);
			if (reader.Read())
			{
				m_MaxKey = reader["MaxKey"] == DBNull.Value ? 0 : reader.GetInt64(0);
				m_MaxCreatedTime = reader["MaxCreatedTime"] == DBNull.Value ? new DateTime(2009, 1, 1) : reader.GetDateTime(1);
			}
			else
			{
				m_MaxKey = 0;
				m_MaxCreatedTime = new DateTime(2009, 1, 1);
			}
		}

		public void Close()
		{
			m_Lock.Enter("Close");
			try
			{
				if (m_DbConn != null && m_DbConn.State == ConnectionState.Open)
				{
					m_DbConn.Close();
					m_DbConn = null;
					m_InsertCommand = null;
				}
			}
			finally
			{
				m_Lock.Exit("Close");
			}
		}

		public void Insert(List<Hashtable> msgs)
		{
			m_Lock.Enter("Insert");
			try
			{
				Open();
				SQLiteTransaction trans = m_DbConn.BeginTransaction();

				try
				{
					foreach (Hashtable msg in msgs)
					{
						m_InsertCommand.Parameters[0].Value = msg["Sender"];
						m_InsertCommand.Parameters[1].Value = msg["Receiver"];
						m_InsertCommand.Parameters[2].Value = msg["Type"];
						m_InsertCommand.Parameters[3].Value = msg["Content"];
						m_InsertCommand.Parameters[4].Value = msg["CreatedTime"];
						m_InsertCommand.Parameters[5].Value = msg["Key"];

						m_InsertCommand.ExecuteNonQuery();
					}
					trans.Commit();
					Stat();
				}
				catch
				{
					trans.Rollback();
					throw;
				}
			}
			finally
			{
				m_Lock.Exit("Insert");
			}
		}

		public List<String> GetMessageDate(int type)
		{
			m_Lock.Enter("GetMessageDate");
			try
			{
				Open();
				SQLiteCommand cmd = new SQLiteCommand(
					String.Format("select date(CreatedTime) as CreatedDate from Message where Type={0} group by CreatedDate", type),
					m_DbConn
				);

				List<String> result=new List<string>();
				SQLiteDataReader reader = cmd.ExecuteReader(CommandBehavior.SingleResult);
				try
				{
					while (reader.Read()) result.Add(reader.GetString(0));
				}
				finally
				{
					reader.Close();
				}

				return result;
			}
			finally
			{
				m_Lock.Exit("GetMessageDate");
			}
		}

		public List<Hashtable> Find(Int64 type, Nullable<Int64> receiverId, Nullable<Int64> senderId, Nullable<DateTime> min, Nullable<DateTime> max, int count)
		{
			m_Lock.Enter("Find");
			try
			{
				Open();

				StringBuilder cmdText = new StringBuilder();
				cmdText.Append("select * from Message where Type=?");
				if (receiverId != null) cmdText.Append(" and Receiver=?");
				if (senderId != null) cmdText.Append(" and Sender=?");
				if (min != null) cmdText.Append(" and CreatedTime>=?");
				if (max != null) cmdText.Append(" and CreatedTime<=?");
				cmdText.Append(" order by CreatedTime desc");
				cmdText.Append(String.Format(" limit 0,{0}", count));

				SQLiteCommand cmd = null;
				cmd = new SQLiteCommand(cmdText.ToString(), m_DbConn);

				cmd.Parameters.Add("Type", DbType.Int64).Value = type;
				if (receiverId != null) cmd.Parameters.Add("Receiver", DbType.Int64).Value = receiverId.Value;
				if (senderId != null) cmd.Parameters.Add("Sender", DbType.Int64).Value = senderId.Value;
				if (min != null) cmd.Parameters.Add("From", DbType.DateTime).Value = min.Value;
				if (max != null) cmd.Parameters.Add("To", DbType.DateTime).Value = max.Value;

				SQLiteDataReader reader = cmd.ExecuteReader(CommandBehavior.SingleResult);
				try
				{
					List<Hashtable> rows = new List<Hashtable>();
					while (reader.Read())
					{
						Hashtable row = new Hashtable();
						row["Receiver"] = reader["Receiver"];
						row["Sender"] = reader["Sender"];
						row["CreatedTime"] = reader["CreatedTime"];
						row["Content"] = reader["Content"];
						row["Type"] = reader["Type"];
						row["Key"] = reader["Key"];
						rows.Add(row);
					}
					return rows;
				}
				finally
				{
					reader.Close();
				}
			}
			finally
			{
				m_Lock.Exit("Find");
			}
		}

		public Hashtable Find(Int64 key)
		{
			m_Lock.Enter("Find");
			try
			{
				Open();
				m_SelectCommand1.Parameters[0].Value = key;
				SQLiteDataReader reader = m_SelectCommand1.ExecuteReader(CommandBehavior.SingleResult);
				try
				{
					if (!reader.Read()) return null;
					Hashtable row = new Hashtable();
					row["Receiver"] = reader["Receiver"];
					row["Sender"] = reader["Sender"];
					row["CreatedTime"] = reader["CreatedTime"];
					row["Content"] = reader["Content"];
					row["Type"] = reader["Type"];
					row["Key"] = reader["Key"];
					return row;
				}
				finally
				{
					reader.Close();
				}
			}
			finally
			{
				m_Lock.Exit("Find");
			}
		}

		public List<Hashtable> Find(Int64 Type, DateTime min)
		{
			m_Lock.Enter("Find");
			try
			{
				Open();
				m_SelectCommand2.Parameters[0].Value = Type;
				m_SelectCommand2.Parameters[1].Value = min;
				SQLiteDataReader reader = m_SelectCommand2.ExecuteReader(CommandBehavior.SingleResult);
				List<Hashtable> rows = new List<Hashtable>();
				try
				{
					while (reader.Read())
					{
						Hashtable row = new Hashtable();
						row["Receiver"] = reader["Receiver"];
						row["Sender"] = reader["Sender"];
						row["CreatedTime"] = reader["CreatedTime"];
						row["Content"] = reader["Content"];
						row["Type"] = reader["Type"];
						row["Key"] = reader["Key"];
						rows.Add(row);
					}
				}
				finally
				{
					reader.Close();
				}
				return rows;
			}
			finally
			{
				m_Lock.Exit("Find");
			}
		}

		public List<Int64> GetAllSenders()
		{
			m_Lock.Enter("Find");
			try
			{
				Open();
				SQLiteDataReader reader = m_SelectSenderCommand.ExecuteReader(CommandBehavior.SingleResult);
				List<Int64> senders = new List<Int64>();
				try
				{
					while (reader.Read())
					{
						Int64 id = reader.GetInt64(0);
						senders.Add(id);
					}
				}
				finally
				{
					reader.Close();
				}
				return senders;
			}
			finally
			{
				m_Lock.Exit("Find");
			}
		}
	}

	internal class MsgAccessoryEval
	{
		string  m_MsgDir;
		Int64 m_User, m_Sender;
		AccountInfo m_UserInfo,m_SenderInfo;

		Int64 m_FileLimit, m_ImageLimit;

		public MsgAccessoryEval(Hashtable msg, Int64 user, Int64 sender)
		{
			m_User = user;
			m_Sender = sender;
			m_UserInfo = AccountManagement.Instance.GetUserInfo((Int32)user);
			m_SenderInfo = AccountManagement.Instance.GetUserInfo((Int32)sender);
			m_MsgDir = string.Format("/{0}/Message/MSG{1:00000000}", m_UserInfo.Name, msg["Key"]);

			m_FileLimit = m_UserInfo.MsgFileLimit;
			m_ImageLimit = m_UserInfo.MsgImageLimit;

			//图片不得超过100K
			if (m_ImageLimit > 200) m_ImageLimit = 200;
		}

		public string Replace(Match match)
		{
			XmlDocument xml = new XmlDocument();
			string value = match.Value;
			xml.LoadXml(string.Format("<{0} />", value.Substring(1, value.Length - 2)));

			string src = GlobalObject.unescape(xml.DocumentElement.GetAttribute("src")); 
			string type = xml.DocumentElement.GetAttribute("type").ToLower();
						
			bool isPublic = LIO.Path.IsPublicResource(src);

			if (isPublic)
			{
				//公共资源不拷贝
				return String.Format("/{0}/{1}", m_UserInfo.Name, LIO.Path.GetRelativePath(src));
			}
			else
			{
				if (!LIO.Directory.Exists(m_MsgDir)) LIO.Directory.CreateDirectory(m_MsgDir);

				string fileOwner = LIO.Path.GetUser(src);

				Core.IO.FileInfo info = new Core.IO.FileInfo(src);
				if (type == "file" && info.Length / 1024 > m_FileLimit)
				{
					throw new Exception(String.Format("附件不能超过 {0} KB！", m_FileLimit));
				}
				if (type != "file" && info.Length / 1024 > m_ImageLimit)
				{
					throw new Exception(String.Format("图片不能超过 {0} KB！", m_ImageLimit));
				}

				AccountInfo fileOwnerInfo = AccountManagement.Instance.GetUserInfo(fileOwner);
				if (!String.IsNullOrEmpty(fileOwner) &&
					(fileOwnerInfo.ID==m_SenderInfo.ID || fileOwnerInfo.Type == 1 && fileOwnerInfo.ContainsMember(m_SenderInfo.Name)))
				{
					Hashtable _files = new Hashtable();
					string fileName;
					if (!_files.ContainsKey(src))
					{
						fileName = LIO.Path.GetFileName(src);
						int i = 1;
						while (_files.ContainsValue(fileName))
						{
							fileName = string.Format("{0}({1}){2}", System.IO.Path.GetFileNameWithoutExtension(fileName), i.ToString(), System.IO.Path.GetExtension(fileName));
							i++;
						}

						_files.Add(src, fileName);

						try
						{
							LIO.File.Copy(src, m_MsgDir + "/" + fileName);
						}
						catch
						{
						}

					}
					else
						fileName = _files[src] as string;

					string newUrl = GlobalObject.escape(string.Format("{0}/{1}", m_MsgDir, fileName));

					return newUrl;
				}
				else
				{
					return match.Value;
				}
			}
		}
	}

	public interface IMessageWaitWatcherHandler
	{
		void Complete(Exception error,List<Message> msgs);
	}

	public class MessageListener
	{
		static Int64 MaxID = 0;

		Int64 m_ID;
		Int64 m_Type;
		DateTime m_Min;
		String m_HandlerID;
		String m_User;
		String m_Owner;
		String m_Guid;
		String m_SessionID;

		public Int64 ID { get { return m_ID; } }
		public Int64 Type { get { return m_Type; } }
		public DateTime Min { get { return m_Min; } }

		public MessageListener(String sessionId,String guid, String user, String owner, Int64 type, DateTime min, String handlerID)
		{
			m_ID = ++MaxID;
			m_Type = type;
			m_Min = min;
			m_HandlerID = handlerID;
			m_User = user;
			m_Owner = owner;
			m_Guid = guid;
			m_SessionID = sessionId;
		}

		public static String RenderMsgsJson(List<Message> msgs)
		{
			StringBuilder builder = new StringBuilder();
			builder.Append("[");
			for (int i = 0; i < msgs.Count; i++)
			{
				Message msg = msgs[i];
				if (i > 0) builder.Append(",");
				RenderMsgJson(builder, msg);
			}
			builder.Append("]");

			return builder.ToString();
		}

		public static void RenderMsgJson(StringBuilder builder, Message msg)
		{
			AccountInfo sender = AccountManagement.Instance.GetUserInfo((Int32)msg.SenderID);
			AccountInfo receiver = AccountManagement.Instance.GetUserInfo((Int32)msg.ReceiverID);

			Utility.RenderHashJson(
				builder, null,
				"Receiver", receiver.Name,
				"ReceiverNickname", receiver.NickName,
				"ReceiverID", receiver.ID,
				"Sender", sender.Name,
				"SenderNickname", sender.NickName,
				"SenderID", sender.ID,
				"Content", msg.Content,
				"CreatedTime", msg.CreatedTime,
				"ID", msg.Key
			);
		}

		public void Send(String msgJson, DateTime max)
		{
			Session current = SessionManagement.Instance.GetSession(m_User, m_SessionID);
			
			Hashtable config = null;
			if (m_Type == 0)
			{
				config = current.ReadConfig("A553B162-F95F-4B13-BFCD-606DABFDD71F") as Hashtable;
			}
			else if (m_Type == 1)
			{
				config = current.ReadConfig("951AABD2-4AAC-4382-A502-71A57FC7F90D") as Hashtable;
			}
			if (config != null)
			{
				lock (config)
				{
					if (config.ContainsKey(m_Owner.ToUpper()))
					{
						Hashtable uc = config[m_Owner.ToUpper()] as Hashtable;
						if (uc.ContainsKey("LastReceiveTime"))
						{
							if ((DateTime)uc["LastReceiveTime"] < max) uc["LastReceiveTime"] = max;
						}
						else
						{
							uc["LastReceiveTime"] = max;
						}
					}
					else
					{
						Hashtable uc = new Hashtable();
						uc["LastReceiveTime"] = max;
						config[m_Owner.ToUpper()] = uc;
					}
				}
			}
			StringBuilder messageBuilder = new StringBuilder();
			messageBuilder.Append("{");
			messageBuilder.AppendFormat("\"Owner\":\"{0}\"", m_Owner);
			messageBuilder.AppendFormat(",\"Listener\":\"{0}\"", m_Guid);
			messageBuilder.Append(",\"Messages\":");
			messageBuilder.Append(msgJson);
			messageBuilder.Append("}");
			current.SendCommand(m_HandlerID, messageBuilder.ToString());
		}
	}
}
