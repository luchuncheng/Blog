﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Xml;

namespace Core
{
	class RedirectModule : IHttpModule
	{
		public void Init(HttpApplication application)
		{
			application.BeginRequest+=new EventHandler(application_BeginRequest);
			application.PostMapRequestHandler+=new EventHandler(application_PostMapRequestHandler);
		}

		public void application_BeginRequest(Object sender, EventArgs e)
		{
			HttpApplication app = sender as HttpApplication;
#if _DEBUG
			string filePath=app.Server.MapPath("~\\log.txt");
			System.IO.FileStream fs = System.IO.File.Open(filePath, System.IO.FileMode.OpenOrCreate);
			fs.Seek(0, System.IO.SeekOrigin.End);
			System.IO.StreamWriter sw = new System.IO.StreamWriter(fs);

			sw.WriteLine("PRE:" + app.Request.AppRelativeCurrentExecutionFilePath);
#endif
			string[] pathNodes = app.Request.AppRelativeCurrentExecutionFilePath.Split('/');
			if (pathNodes.Length > 2 && pathNodes[0] == "~" && String.Compare(pathNodes[1], "users", true) == 0)
			{
				StringBuilder builder=new StringBuilder();
				for(int i=2;i<pathNodes.Length-1;i++)
				{
					builder.Append("/");
					builder.Append(pathNodes[i]);
				}
				builder.Append("/");
				string fileName = pathNodes[pathNodes.Length - 1];
				if(String.Compare(System.IO.Path.GetExtension(fileName),".res",true)==0)
					builder.Append(System.IO.Path.GetFileNameWithoutExtension(fileName));
				else
					builder.Append(fileName);
				app.Context.RewritePath(String.Format("download?FileName={0}", HttpUtility.UrlEncode(builder.ToString())));
#if _DEBUG
				sw.WriteLine("RED:" + String.Format("download?FileName={0}", HttpUtility.UrlEncode(builder.ToString())));
#endif
			}
#if _DEBUG
			sw.Close();
#endif
		}

		public void application_PostMapRequestHandler(Object sender, EventArgs e)
		{
		}

		public void Dispose()
		{
		}
	}
}
