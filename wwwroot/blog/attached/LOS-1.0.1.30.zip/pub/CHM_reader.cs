﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using Core.Com;
using Core;

public partial class CHM_reader : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		Hashtable data = new Hashtable();

		try
		{
			Core.Security.CheckPermission(Request.QueryString["file"], Context, FilePermission.Read);
		}
		catch
		{
			Response.Redirect(String.Format("{0}Login.aspx?Redirect=false&ReturnUrl={1}", Request.ApplicationPath.EndsWith("/") ? Request.ApplicationPath : Request.ApplicationPath + "/", HttpUtility.UrlEncode(Request.RawUrl)));
			return;
		}

		data["ApplicationPath"] = Request.ApplicationPath;

		String file = Request.QueryString["file"], path = "";
		Core.IO.StorageType st = Core.IO.Path.GetStorageType(file);

		if (st.Type == Core.IO.EmbedType.CHM)
		{
			path = VirtualPathManagement.Instance.MapPath(st.FilePath).Path;
			data["FileName"] = st.FilePath;
			data["Page"] = st.ResourcePath;
		}
		else
		{
			path = VirtualPathManagement.Instance.MapPath(file).Path;
			data["FileName"] = Request.QueryString["file"];
			data["Page"] = Request.QueryString["page"] ?? "";
		}

		Hashtable info = new Hashtable();

		using (Stream sys_stream = CHH.Find(path, "#SYSTEM"))
		{
			if (sys_stream != null)
			{
				try
				{
					byte[] buf = new byte[sys_stream.Length];
					sys_stream.Read(buf, 0, buf.Length);
					info = Utility.ParseJson(Encoding.UTF8.GetString(buf)) as Hashtable;
					data["Info"] = new JsonText(Encoding.UTF8.GetString(buf));
				}
				finally
				{
					sys_stream.Close();
				}
			}
			else
			{
				data["Info"] = new JsonText("null");
			}
		}

		this.Title = info["Title"] == null ? "" : info["Title"] as string;

		using (Stream sys_stream = Core.Com.CHH.Find(path, ".HHC"))
		{
			if (sys_stream != null)
			{
				try
				{
					byte[] buf = new byte[sys_stream.Length];
					sys_stream.Read(buf, 0, buf.Length);

					Encoding encoding = null;
					if (info.ContainsKey("Encoding")) encoding = Encoding.GetEncoding(info["Encoding"] as string);
					if (encoding == null) encoding = Encoding.UTF8;

					data["HHC"] = new JsonText(Utility.RenderJson(encoding.GetString(buf), null));
				}
				finally
				{
					sys_stream.Close();
				}
			}
			else
			{
				data["HHC"] = new JsonText("null");
			}
		}

		HtmlInputHidden hidden = Page.FindControl("chm_data") as HtmlInputHidden;

		hidden.Value = Utility.RenderJson(data, null);
	}

	String[] Split(String path)
	{
		int index = path.IndexOf(".CHM", StringComparison.CurrentCultureIgnoreCase);

		if ((path.Length >= index + 5 && path[index + 4] == '\\'))
		{
			String[] ps = new String[2];
			ps[0] = path.Substring(0, index + 4);
			ps[1] = path.Substring(index + 5);
			return ps;
		}
		else
		{
			return null;
		}
	}

#if	DEBUG
	protected bool DEBUG { get { return true; } }
#else
	protected bool DEBUG { get { return false; } }
#endif

}
